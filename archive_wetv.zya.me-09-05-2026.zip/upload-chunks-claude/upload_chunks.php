<?php
//source:https://claude.ai/chat/f50e2a57-e341-4150-a90a-1bc9bc98d02e
header('Content-Type: application/json');

// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Configuration
$uploadDir = 'uploads/';
$tempDir = $uploadDir . 'temp/';
$maxFileSize = 10 * 1024 * 1024 * 1024; // 10GB max file size

// Create directories if they don't exist
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}
if (!file_exists($tempDir)) {
    mkdir($tempDir, 0755, true);
}

try {
    // Validate request
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    if (!isset($_FILES['file'])) {
        throw new Exception('No file uploaded');
    }

    // Get parameters
    $chunkIndex = isset($_POST['chunkIndex']) ? intval($_POST['chunkIndex']) : 0;
    $totalChunks = isset($_POST['totalChunks']) ? intval($_POST['totalChunks']) : 0;
    $fileName = isset($_POST['fileName']) ? basename($_POST['fileName']) : '';
    $uniqueId = isset($_POST['uniqueId']) ? preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['uniqueId']) : '';

    if (empty($fileName) || empty($uniqueId)) {
        throw new Exception('Missing required parameters');
    }

    // Sanitize filename
    $fileName = preg_replace('/[^a-zA-Z0-9._-]/', '_', $fileName);
    
    // Create temp file path for this upload session
    $tempFilePath = $tempDir . $uniqueId . '_' . $fileName;
    
    // Handle chunk upload
    $chunk = $_FILES['file']['tmp_name'];
    
    if (!is_uploaded_file($chunk)) {
        throw new Exception('Invalid file upload');
    }

    // Append chunk to temp file
    $chunkData = file_get_contents($chunk);
    if ($chunkData === false) {
        throw new Exception('Failed to read chunk data');
    }

    $result = file_put_contents($tempFilePath, $chunkData, FILE_APPEND | LOCK_EX);
    if ($result === false) {
        throw new Exception('Failed to write chunk');
    }

    // Check if this is the last chunk
    $isComplete = ($chunkIndex + 1) >= $totalChunks;

    if ($isComplete) {
        // Move completed file to final location
        $finalFilePath = $uploadDir . $fileName;
        
        // If file exists, add timestamp to make it unique
        if (file_exists($finalFilePath)) {
            $pathInfo = pathinfo($fileName);
            $fileName = $pathInfo['filename'] . '_' . time() . '.' . $pathInfo['extension'];
            $finalFilePath = $uploadDir . $fileName;
        }

        if (!rename($tempFilePath, $finalFilePath)) {
            throw new Exception('Failed to move file to final location');
        }

        // Set proper permissions
        chmod($finalFilePath, 0644);

        // Clean up any other temp files for this upload session
        $tempFiles = glob($tempDir . $uniqueId . '_*');
        foreach ($tempFiles as $tempFile) {
            if ($tempFile !== $finalFilePath) {
                @unlink($tempFile);
            }
        }

        echo json_encode([
            'success' => true,
            'complete' => true,
            'message' => 'File uploaded successfully',
            'fileName' => $fileName,
            'filePath' => $uploadDir . $fileName,
            'fileSize' => filesize($finalFilePath)
        ]);
    } else {
        // Chunk uploaded successfully, but not complete yet
        echo json_encode([
            'success' => true,
            'complete' => false,
            'message' => 'Chunk uploaded successfully',
            'chunkIndex' => $chunkIndex,
            'totalChunks' => $totalChunks
        ]);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

// Clean up old temp files (older than 1 hour)
$tempFiles = glob($tempDir . '*');
$now = time();
foreach ($tempFiles as $tempFile) {
    if (is_file($tempFile) && ($now - filemtime($tempFile)) > 3600) {
        @unlink($tempFile);
    }
}
?>