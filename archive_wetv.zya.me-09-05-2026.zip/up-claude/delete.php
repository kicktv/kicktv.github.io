<?php
// Enable error reporting for debugging (remove in production)
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

// Response function
function sendResponse($success, $message) {
    echo json_encode([
        'success' => $success,
        'message' => $message
    ]);
    exit;
}

// Check if MD5 hash is provided
if (!isset($_POST['md5']) || empty($_POST['md5'])) {
    sendResponse(false, 'No file identifier provided.');
}

$md5 = $_POST['md5'];

// Get file information
$storageFile = 'files.json';
if (!file_exists($storageFile)) {
    sendResponse(false, 'File information storage not found.');
}

$data = file_get_contents($storageFile);
$files = json_decode($data, true) ?: [];

// Check if file exists in storage
if (!isset($files[$md5])) {
    sendResponse(false, 'File not found.');
}

$fileInfo = $files[$md5];
$filePath = $fileInfo['url'];

// Delete the file
if (file_exists($filePath)) {