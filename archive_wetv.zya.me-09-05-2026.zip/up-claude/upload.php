<?php
// Enable error reporting for debugging (remove in production)
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

// Set upload directory
$uploadDir = 'uploads/';

// Create directory if it doesn't exist
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Create a temporary directory for remote uploads
$tempDir = 'temp/';
if (!file_exists($tempDir)) {
    mkdir($tempDir, 0755, true);
}

// Set maximum file size (50MB)
$maxFileSize = 50 * 1024 * 1024;

// Set allowed file types
$allowedTypes = ['mp4', 'mp3', 'png', 'jpeg', 'jpg', 'gif', 'txt', 'pdf'];

// Function to generate a unique filename
function generateUniqueFilename($filename) {
    $extension = pathinfo($filename, PATHINFO_EXTENSION);
    $basename = pathinfo($filename, PATHINFO_FILENAME);
    $basename = preg_replace('/[^a-zA-Z0-9_-]/', '', $basename);
    
    return uniqid() . '-' . $basename . '.' . $extension;
}

// Function to get file type
function getFileType($filename) {
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    switch ($extension) {
        case 'mp4':
            return 'video';
        case 'mp3':
            return 'audio';
        case 'png':
        case 'jpeg':
        case 'jpg':
        case 'gif':
            return 'image';
        case 'txt':
            return 'text';
        case 'pdf':
            return 'document';
        default:
            return 'unknown';
    }
}

// Response function
function sendResponse($success, $message, $file = null) {
    $response = [
        'success' => $success,
        'message' => $message
    ];
    
    if ($file) {
        $response['file'] = $file;
    }
    
    echo json_encode($response);
    exit;
}

// Handle local file upload
if (isset($_POST['upload_type']) && $_POST['upload_type'] === 'local') {
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        $errorMessage = 'Upload failed: ';
        
        if (isset($_FILES['file'])) {
            switch ($_FILES['file']['error']) {
                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    $errorMessage .= 'File size exceeds the limit.';
                    break;
                case UPLOAD_ERR_PARTIAL:
                    $errorMessage .= 'The file was only partially uploaded.';
                    break;
                case UPLOAD_ERR_NO_FILE:
                    $errorMessage .= 'No file was uploaded.';
                    break;
                default:
                    $errorMessage .= 'Unknown error.';
            }
        }
        
        sendResponse(false, $errorMessage);
    }
    
    $file = $_FILES['file'];
    $filename = $file['name'];
    $filesize = $file['size'];
    $tmp_name = $file['tmp_name'];
    
    // Validate file size
    if ($filesize > $maxFileSize) {
        sendResponse(false, 'File size exceeds the limit (50MB).');
    }
    
    // Validate file extension
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    if (!in_array($extension, $allowedTypes)) {
        sendResponse(false, 'Invalid file type. Allowed types: mp4, mp3, png, jpeg, jpg, gif, txt, pdf.');
    }
    
    // Generate unique filename
    $newFilename = generateUniqueFilename($filename);
    $destination = $uploadDir . $newFilename;
    
    // Move uploaded file
    if (move_uploaded_file($tmp_name, $destination)) {
        // Calculate MD5 hash
        $md5 = md5_file($destination);
        
        // Prepare file info
        $fileInfo = [
            'name' => $filename,
            'url' => $destination,
            'size' => $filesize,
            'type' => getFileType($filename),
            'md5' => $md5
        ];
        
        // Store file info in a database or file
        if (storeFileInfo($fileInfo)) {
            sendResponse(true, 'File uploaded successfully', $fileInfo);
        } else {
            sendResponse(false, 'Failed to store file information.');
        }
    } else {
        sendResponse(false, 'Failed to move uploaded file.');
    }
}

// Handle remote URL upload
if (isset($_POST['upload_type']) && $_POST['upload_type'] === 'remote' && isset($_POST['file_url'])) {
    $fileUrl = $_POST['file_url'];
    
    // Check if URL is valid
    if (!filter_var($fileUrl, FILTER_VALIDATE_URL)) {
        sendResponse(false, 'Invalid URL.');
    }
    
    // Create a progress file for this URL
    $progressId = md5($fileUrl);
    $progressFile = $tempDir . $progressId . '.progress';
    file_put_contents($progressFile, json_encode(['percent' => 0]));
    
    // Get file info from URL
    $headers = get_headers($fileUrl, 1);
    if (!$headers || strpos($headers[0], '200') === false) {
        sendResponse(false, 'Unable to access the URL or file not found.');
    }
    
    // Try to get filename from URL
    $filename = basename(parse_url($fileUrl, PHP_URL_PATH));
    if (empty($filename) || $filename === '/' || strpos($filename, '.') === false) {
        // If no filename found, use a default name based on content type
        $contentType = isset($headers['Content-Type']) ? $headers['Content-Type'] : '';
        if (is_array($contentType)) {
            $contentType = end($contentType);
        }
        
        switch ($contentType) {
            case 'image/jpeg':
                $filename = 'image.jpg';
                break;
            case 'image/png':
                $filename = 'image.png';
                break;
            case 'image/gif':
                $filename = 'image.gif';
                break;
            case 'video/mp4':
                $filename = 'video.mp4';
                break;
            case 'audio/mpeg':
                $filename = 'audio.mp3';
                break;
            case 'application/pdf':
                $filename = 'document.pdf';
                break;
            case 'text/plain':
                $filename = 'document.txt';
                break;
            default:
                $filename = 'file.' . rand(1000, 9999);
        }
    }
    
    // Validate file extension
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    if (!in_array($extension, $allowedTypes)) {
        sendResponse(false, 'Invalid file type. Allowed types: mp4, mp3, png, jpeg, jpg, gif, txt, pdf.');
    }
    
    // Check Content-Length if available
    $filesize = isset($headers['Content-Length']) ? (int)$headers['Content-Length'] : 0;
    if ($filesize > 0 && $filesize > $maxFileSize) {
        sendResponse(false, 'File size exceeds the limit (50MB).');
    }
    
    // Generate unique filename
    $newFilename = generateUniqueFilename($filename);
    $destination = $uploadDir . $newFilename;
    
    // Download file with progress tracking
    $result = downloadFileWithProgress($fileUrl, $destination, $progressFile);
    
    if ($result) {
        // Get actual filesize
        $actualSize = filesize($destination);
        
        // Calculate MD5 hash
        $md5 = md5_file($destination);
        
        // Prepare file info
        $fileInfo = [
            'name' => $filename,
            'url' => $destination,
            'size' => $actualSize,
            'type' => getFileType($filename),
            'md5' => $md5
        ];
        
        // Store file info in a database or file
        if (storeFileInfo($fileInfo)) {
            // Remove progress file
            @unlink($progressFile);
            
            sendResponse(true, 'File uploaded successfully', $fileInfo);
        } else {
            sendResponse(false, 'Failed to store file information.');
        }
    } else {
        sendResponse(false, 'Failed to download file from URL.');
    }
}

// Function to download file with progress tracking
function downloadFileWithProgress($url, $destination, $progressFile) {
    $fp = fopen($destination, 'w+');
    $ch = curl_init($url);
    
    curl_setopt($ch, CURLOPT_TIMEOUT, 600); // 10 minute timeout
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    
    // Track download progress
    curl_setopt($ch, CURLOPT_NOPROGRESS, false);
    curl_setopt($ch, CURLOPT_PROGRESSFUNCTION, function($resource, $downloadSize, $downloaded) use ($progressFile) {
        if ($downloadSize > 0) {
            $percent = min(100, round(($downloaded / $downloadSize) * 100));
            file_put_contents($progressFile, json_encode(['percent' => $percent]));
        }
    });
    
    $result = curl_exec($ch);
    curl_close($ch);
    fclose($fp);
    
    return $result !== false;
}

// Function to store file information
function storeFileInfo($fileInfo) {
    // This is a simple file-based storage
    // In a real application, you would use a database
    
    $storageFile = 'files.json';
    
    // Read existing data
    $files = [];
    if (file_exists($storageFile)) {
        $data = file_get_contents($storageFile);
        if ($data) {
            $files = json_decode($data, true) ?: [];
        }
    }
    
    // Add new file
    $files[$fileInfo['md5']] = $fileInfo;
    
    // Save updated data
    return file_put_contents($storageFile, json_encode($files)) !== false;
}
?>