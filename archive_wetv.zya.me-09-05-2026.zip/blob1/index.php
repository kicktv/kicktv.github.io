<?php
session_start();

// **لا تغيّر هذا السطر** — المسار المطلق لمجلد الفيديوهات المحمي
//$protected_files_dir = '/home/vol9_7/hstn.me/mseet_36219567/protected_videos/';

$protected_files_dir = dirname(__DIR__) . '/../protected_videos/';

// اسم الملف داخل protected_videos
$real_filename = 'video.mp4';

// إنشاء توكن مؤقت لكل زائر
function generate_token($len = 32) {
    return bin2hex(random_bytes($len/2));
}

$token = generate_token();
$_SESSION['video_tokens'][$token] = [
    'file' => $real_filename,
    'expires_at' => time() + 300, // صالح 5 دقائق
    'used' => false
];
?>
<!doctype html>
<html lang="ar">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>فيديو محمي - تشغيل تلقائي</title>
  <style>
    body{font-family:sans-serif;background:#f6f6f6;padding:30px;text-align:center}
    video{width:90%;max-width:900px;background:#000;border-radius:8px}
  </style>
</head>
<body>
  <h2>فيديو محمي (تشغيل تلقائي)</h2>
  <video id="video" controls autoplay muted></video>

  <script>
    const token = "<?php echo $token; ?>";
    const videoEl = document.getElementById('video');
    let blobUrl = null;

    async function playVideo() {
      try {
        const res = await fetch('video.php?token=' + encodeURIComponent(token), { credentials: 'same-origin' });
        if (!res.ok) throw new Error('فشل جلب الفيديو: ' + res.status);
        const blob = await res.blob();
        if (blobUrl) URL.revokeObjectURL(blobUrl);
        blobUrl = URL.createObjectURL(blob);
        videoEl.src = blobUrl;
        await videoEl.play().catch(()=>{ /* التشغيل التلقائي قد يُمنع إذا الصوت مفعل */ });
      } catch (err) {
        console.error(err);
        alert('خطأ أثناء تشغيل الفيديو: ' + err.message);
      }
    }

    window.addEventListener('load', playVideo);
    window.addEventListener('beforeunload', () => { if (blobUrl) URL.revokeObjectURL(blobUrl); });
  </script>
</body>
</html>
