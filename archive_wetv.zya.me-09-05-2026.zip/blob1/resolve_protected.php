<?php
// resolve_protected.php - استعمل هذه الوظيفة في أعلى video.php أو index.php

function resolve_protected_videos_dir() {
    $dir = __DIR__;            // e.g. /home/.../htdocs/blob
    $d1  = dirname(__DIR__);  // e.g. /home/.../htdocs

    $candidates = [
        $dir . '/../../protected_videos',
        $dir . '/../protected_videos',
        $d1  . '/../protected_videos',
        $d1  . '/protected_videos',
        '/home/vol9_7/hstn.me/mseet_36219567/protected_videos' // مسارك المطلق كخيار أخير
    ];

    foreach ($candidates as $c) {
        $rp = @realpath($c);
        if ($rp !== false && is_dir($rp) && is_readable($rp)) {
            // أعد المسار مع Slash نهائي
            return rtrim($rp, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
        }
    }
    // لا شيء نجح
    return false;
}

// مثال استخدام:
$protected_files_dir = resolve_protected_videos_dir();
if ($protected_files_dir === false) {
    // طبع رسالة مفيدة للمطوّر — احذف أو غيّرها في الإنتاج
    header('Content-Type: text/plain; charset=utf-8');
    echo "لم يتم العثور على مجلد protected_videos. جرب المسارات التالية يدوياً.\n";
    echo "Candidates tried relative to __DIR__ (debug via debug_paths.php recommended).\n";
    exit;
}

// الآن $protected_files_dir جاهز ويمكن استخدامه
// مثال: $file = $protected_files_dir . 'video.mp4';
