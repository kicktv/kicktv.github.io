<?php
// get_home.php
// يحاول تحديد مسار home على الخادم باستخدام عدة طرق.
// اطبع النتائج للتشخيص.

function try_methods() {
    $results = [];

    // 1) getenv('HOME') أو $_SERVER['HOME']
    $env_home = getenv('HOME') ?: (isset($_SERVER['HOME']) ? $_SERVER['HOME'] : false);
    if ($env_home) $results['env_HOME'] = $env_home;

    // 2) دوال POSIX (إن كانت متاحة)
    if (function_exists('posix_getpwuid') && function_exists('posix_geteuid')) {
        $pw = @posix_getpwuid(posix_geteuid());
        if (!empty($pw['dir'])) $results['posix'] = $pw['dir'];
    }

    // 3) اعتمادًا على DOCUMENT_ROOT: عادة /home/username/public_html أو /home/username/www
    if (!empty($_SERVER['DOCUMENT_ROOT'])) {
        $docroot = realpath($_SERVER['DOCUMENT_ROOT']);
        if ($docroot) {
            // نأمل أن يكون الشكل /home/username/public_html → نأخذ والدين إلى أعلى للحصول على /home/username
            $parent1 = dirname($docroot);        // .. -> e.g. /home/username
            $parent2 = dirname($parent1);        // .. one more up (just for info)
            $results['document_root'] = $docroot;
            $results['document_root_parent'] = $parent1;
            $results['document_root_parent_parent'] = $parent2;
        }
    }

    // 4) محاولة realpath صعود مستويين من __DIR__ (مفيد إذا الملف داخل public_html/blob)
    $maybe_home = realpath(__DIR__ . '/../../');
    if ($maybe_home) {
        $results['realpath_from_dir_../../'] = $maybe_home;
    }

    // 5) محاولة العثور على مسار يحتوي على "home" (فقط كحل احترازي)
    if (isset($parent1)) {
        if (stripos($parent1, DIRECTORY_SEPARATOR . 'home' . DIRECTORY_SEPARATOR) !== false) {
            $results['detected_home_like'] = $parent1;
        }
    }

    return $results;
}

$res = try_methods();

// طباعة النتائج
header('Content-Type: text/plain; charset=utf-8');
if (empty($res)) {
    echo "لم يتم العثور على مسار home تلقائياً. جرب تعيينه يدوياً.\n";
    echo "مثال للتعيين اليدوي في كودك:\n";
    echo "\$protected_files_dir = '/home/username/protected_videos/';\n";
    exit;
}

echo "نتائج محاولات اكتشاف مسار HOME:\n\n";
foreach ($res as $k => $v) {
    if (is_string($v)) {
        echo "[$k] => $v\n";
    } else {
        // إذا كان مصفوفة (غير متوقع هنا) حاول طباعتها بشكل آمن
        echo "[$k] => " . var_export($v, true) . "\n";
    }
}

// اقتراح: اختر أحد المسارات الأكثر منطقية (على سبيل المثال document_root_parent)
// ويمكنك التعليق أو إلغاء التعليق أدناه لاستخدامه:
echo "\n\n----\nاقتراح: استخدم أحد هذه المسارات كـ base لمجلداتك المحمية.\n";
if (isset($res['document_root_parent'])) {
    echo "مثال: \$protected_files_dir = '" . $res['document_root_parent'] . "/protected_videos/';\n";
} elseif (isset($res['env_HOME'])) {
    echo "مثال: \$protected_files_dir = '" . $res['env_HOME'] . "/protected_videos/';\n";
} elseif (isset($res['realpath_from_dir_../../'])) {
    echo "مثال: \$protected_files_dir = '" . $res['realpath_from_dir_../../'] . "/protected_videos/';\n";
} else {
    echo "لو لم ينجح شيء، ضع المسار المطلق يدوياً كما في المثال أعلاه.\n";
}
