<?php
session_start();

// **ضع هنا نفس المسار المطلق** الذي أعطيته
//$protected_files_dir = '/home/vol9_7/hstn.me/mseet_36219567/protected_videos/';

$protected_files_dir = dirname(__DIR__) . '/../protected_videos/';

if (!isset($_GET['token'])) {
    http_response_code(400);
    exit('Missing token');
}

$token = $_GET['token'];

if (!isset($_SESSION['video_tokens'][$token])) {
    http_response_code(403);
    exit('Invalid or expired token');
}

$info = &$_SESSION['video_tokens'][$token];

// تحقق من انتهاء الصلاحية
if ($info['expires_at'] < time()) {
    unset($_SESSION['video_tokens'][$token]);
    http_response_code(403);
    exit('Token expired');
}

// اجعل التوكن single-use
if ($info['used']) {
    http_response_code(403);
    exit('Token already used');
}

// المسار الكامل إلى الملف
$file = $protected_files_dir . $info['file'];

// فحوص تشخيصية سريعة — حذف أو إخفاء هذه الرسائل في الإنتاج
if (!file_exists($file)) {
    http_response_code(404);
    exit('File not found: ' . htmlspecialchars($file));
}
if (!is_readable($file)) {
    http_response_code(500);
    exit('File not readable (check permissions): ' . htmlspecialchars($file));
}

// علم أن التوكن استُخدم
$info['used'] = true;

// استخرج نوع الميم والارسال
$mime = @mime_content_type($file) ?: 'application/octet-stream';
$size = filesize($file);

header('Content-Type: ' . $mime);
header('Content-Length: ' . $size);
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

// إرسال الملف (للفيديوهات الصغيرة والمتوسطة)
// ملاحظة: هذا يرسل الملف كله. إذا احتجت دعم seek/Range سأزودك بكود إضافي.
$fp = fopen($file, 'rb');
if ($fp === false) {
    http_response_code(500);
    exit('Cannot open file');
}
while (!feof($fp)) {
    echo fread($fp, 8192);
    flush();
}
fclose($fp);
exit;
