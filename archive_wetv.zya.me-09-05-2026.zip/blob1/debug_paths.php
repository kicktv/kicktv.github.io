<?php
// debug_paths.php - ضع هذا في /htdocs/blob/

header('Content-Type: text/plain; charset=utf-8');

echo "=== DEBUG PATHS ===\n\n";

// __DIR__ الحالي (مجلد هذا الملف)
$dir = __DIR__;
echo "__DIR__: $dir\n";

// dirname(__DIR__)
$d1 = dirname(__DIR__);
echo "dirname(__DIR__): $d1\n";

// حسابات مسارات مرشحة
$candidates = [
    $dir . '/../../protected_videos',
    $dir . '/../protected_videos',
    $d1 . '/../protected_videos',
    $d1 . '/protected_videos',
    '/home/vol9_7/hstn.me/mseet_36219567/protected_videos', // المسار الذي أعطيته سابقًا - اختباري
];

// طبع المرشحين و realpath لكل منهم
foreach ($candidates as $cand) {
    $rp = @realpath($cand);
    echo "\nCandidate: $cand\n";
    echo "  realpath => " . ($rp === false ? 'false' : $rp) . "\n";
    echo "  file_exists => " . (file_exists($cand) ? 'yes' : 'no') . "\n";
    echo "  is_dir => " . (is_dir($cand) ? 'yes' : 'no') . "\n";
    echo "  is_readable => " . (is_readable($cand) ? 'yes' : 'no') . "\n";
}

// عرض open_basedir و disabled_functions
echo "\n\nPHP ini settings:\n";
echo "open_basedir = " . ini_get('open_basedir') . "\n";
echo "disable_functions = " . ini_get('disable_functions') . "\n";

// عرض معلومات المستخدم الذي يشغل PHP إن أمكن
if (function_exists('posix_getpwuid')) {
    $pw = posix_getpwuid(posix_geteuid());
    echo "\nEffective UID/GID info:\n";
    print_r($pw);
} else {
    echo "\nposix_getpwuid not available on this server.\n";
}

echo "\n\nEnd of debug.\n";
