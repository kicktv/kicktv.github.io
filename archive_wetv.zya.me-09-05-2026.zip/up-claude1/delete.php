<?php
// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Configuration
$targetDir = "uploads/";
$response = array('success' => false, 'message' => '');

// Check if file ID is provided
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $fileId = $_GET['id'];
    
    // Validate the MD5 hash format
    if (!preg_match('/^[a-f0-9]{32}$/', $fileId)) {
        $response['message'] = "Invalid file ID format.";
        echo json_encode($response);
        exit;
    }
    
    // Find the file with the given MD5 hash
    $foundFile = false;
    $files = scandir($targetDir);
    foreach ($files as $file) {
        if ($file !== '.' && $file !== '..') {
            $fileParts = explode('.', $file);
            $fileMD5 = $fileParts[0];
            
            if ($fileMD5 === $fileId) {
                $filePath = $targetDir . $file;
                
                // Delete the file
                if (unlink($filePath)) {
                    $foundFile = true;
                    $response['success'] = true;
                    $response['message'] = "File deleted successfully.";
                } else {
                    $response['message'] = "Error deleting file.";
                }
                
                break;
            }
        }
    }
    
    if (!$foundFile) {
        $response['message'] = "File not found.";
    }
} else {
    $response['message'] = "File ID not provided.";
}

// Return JSON response
echo json_encode($response);
exit;
?>