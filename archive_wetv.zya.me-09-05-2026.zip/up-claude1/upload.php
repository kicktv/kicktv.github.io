<?php
// Set error reporting and session
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Configuration
$targetDir = "uploads/";
if (!file_exists($targetDir)) {
    mkdir($targetDir, 0777, true);
}

// Allowed file extensions
$allowedExtensions = array('mp4', 'mp3', 'png', 'jpeg', 'jpg', 'gif', 'txt', 'pdf');

// Handle the upload process
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = array('success' => false, 'message' => '', 'file_info' => null);
    
    // Check if it's a local file upload or remote URL
    if (isset($_FILES['file']) && !empty($_FILES['file']['name'])) {
        // Local file upload
        $fileName = basename($_FILES['file']['name']);
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        
        // Check if file extension is allowed
        if (!in_array($fileExt, $allowedExtensions)) {
            $response['message'] = "Error: Only mp4, mp3, png, jpeg, jpg, gif, txt, pdf files are allowed.";
            echo json_encode($response);
            exit;
        }
        
        // Generate MD5 hash of file content for unique ID
        $fileMD5 = md5_file($_FILES['file']['tmp_name']);
        $newFileName = $fileMD5 . '.' . $fileExt;
        $targetFilePath = $targetDir . $newFileName;
        
        // Check if file already exists
        if (file_exists($targetFilePath)) {
            $response['success'] = true;
            $response['message'] = "File already exists. Using existing file.";
        } else {
            // Upload file
            if (move_uploaded_file($_FILES['file']['tmp_name'], $targetFilePath)) {
                $response['success'] = true;
                $response['message'] = "File uploaded successfully.";
            } else {
                $response['message'] = "Error uploading file.";
                echo json_encode($response);
                exit;
            }
        }
        
        // File information
        $fileSize = filesize($targetFilePath);
        $response['file_info'] = array(
            'name' => $fileName,
            'size' => formatFileSize($fileSize),
            'type' => $_FILES['file']['type'],
            'md5' => $fileMD5,
            'path' => $targetFilePath,
            'url' => getFileUrl($targetFilePath),
            'delete_url' => "delete.php?id=" . $fileMD5
        );
        
    } elseif (isset($_POST['remote_url']) && !empty($_POST['remote_url'])) {
        // Remote URL upload
        $remoteUrl = $_POST['remote_url'];
        
        // Validate URL
        if (!filter_var($remoteUrl, FILTER_VALIDATE_URL)) {
            $response['message'] = "Invalid URL format.";
            echo json_encode($response);
            exit;
        }
        
        // Get file info from URL
        $urlInfo = pathinfo($remoteUrl);
        $fileExt = isset($urlInfo['extension']) ? strtolower($urlInfo['extension']) : '';
        
        // If extension isn't in the URL, try to get it from content type
        if (empty($fileExt) || !in_array($fileExt, $allowedExtensions)) {
            $headers = get_headers($remoteUrl, 1);
            if (isset($headers['Content-Type'])) {
                $contentType = $headers['Content-Type'];
                $extMap = array(
                    'video/mp4' => 'mp4',
                    'audio/mpeg' => 'mp3',
                    'image/png' => 'png',
                    'image/jpeg' => 'jpg',
                    'image/gif' => 'gif',
                    'text/plain' => 'txt',
                    'application/pdf' => 'pdf'
                );
                
                if (isset($extMap[$contentType])) {
                    $fileExt = $extMap[$contentType];
                }
            }
        }
        
        // Check if file extension is allowed
        if (empty($fileExt) || !in_array($fileExt, $allowedExtensions)) {
            $response['message'] = "Error: Only mp4, mp3, png, jpeg, jpg, gif, txt, pdf files are allowed.";
            echo json_encode($response);
            exit;
        }
        
        // Get file content
        $fileContent = file_get_contents($remoteUrl);
        if ($fileContent === false) {
            $response['message'] = "Error: Could not download file from URL.";
            echo json_encode($response);
            exit;
        }
        
        // Generate MD5 hash and filename
        $fileMD5 = md5($fileContent);
        $fileName = basename($remoteUrl);
        $newFileName = $fileMD5 . '.' . $fileExt;
        $targetFilePath = $targetDir . $newFileName;
        
        // Check if file already exists
        if (file_exists($targetFilePath)) {
            $response['success'] = true;
            $response['message'] = "File already exists. Using existing file.";
        } else {
            // Save file
            if (file_put_contents($targetFilePath, $fileContent)) {
                $response['success'] = true;
                $response['message'] = "File downloaded successfully.";
            } else {
                $response['message'] = "Error saving file.";
                echo json_encode($response);
                exit;
            }
        }
        
        // File information
        $fileSize = filesize($targetFilePath);
        $response['file_info'] = array(
            'name' => $fileName,
            'size' => formatFileSize($fileSize),
            'type' => mime_content_type($targetFilePath),
            'md5' => $fileMD5,
            'path' => $targetFilePath,
            'url' => getFileUrl($targetFilePath),
            'delete_url' => "delete.php?id=" . $fileMD5
        );
    } else {
        $response['message'] = "No file or URL provided.";
    }
    
    echo json_encode($response);
    exit;
}

// Helper function to format file size
function formatFileSize($bytes) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    $i = 0;
    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 2) . ' ' . $units[$i];
}

// Helper function to get file URL
function getFileUrl($path) {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'];
    $relativePath = str_replace($_SERVER['DOCUMENT_ROOT'], '', realpath($path));
    return $protocol . $host . $relativePath;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload System</title>
    <style>
/* Reset and base styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    line-height: 1.6;
    color: #333;
    background-color: #f9f9f9;
    padding: 20px;
}

.container {
    max-width: 900px;
    margin: 0 auto;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    padding: 30px;
}

h1 {
    text-align: center;
    margin-bottom: 30px;
    color: #2c3e50;
}

h2 {
    margin-bottom: 20px;
    color: #3498db;
    font-size: 1.5rem;
}

/* Upload container styles */
.upload-container {
    margin-bottom: 40px;
    padding: 20px;
    background-color: #f8f9fa;
    border-radius: 6px;
}

/* Custom file upload button */
.custom-file-upload {
    display: flex;
    align-items: center;
    margin-bottom: 15px;
    flex-wrap: wrap;
}

.file-input {
    width: 0.1px;
    height: 0.1px;
    opacity: 0;
    overflow: hidden;
    position: absolute;
    z-index: -1;
}

.file-label {
    cursor: pointer;
    padding: 10px 15px;
    background-color: #3498db;
    color: white;
    border-radius: 4px;
    font-weight: 600;
    transition: background-color 0.3s;
    display: inline-block;
    margin-right: 15px;
}

.file-label:hover {
    background-color: #2980b9;
}

#fileSelected {
    color: #555;
    font-style: italic;
}

/* Button styles */
.btn {
    cursor: pointer;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    font-weight: 600;
    transition: background-color 0.3s, opacity 0.3s;
}

.upload-btn {
    background-color: #2ecc71;
    color: white;
}

.upload-btn:hover {
    background-color: #27ae60;
}

.upload-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

.fetch-btn {
    background-color: #9b59b6;
    color: white;
}

.fetch-btn:hover {
    background-color: #8e44ad;
}

/* Input group for remote URL */
.input-group {
    display: flex;
    margin-bottom: 15px;
}

.url-input {
    flex: 1;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px 0 0 4px;
    outline: none;
}

.url-input:focus {
    border-color: #3498db;
}

.input-group .fetch-btn {
    border-radius: 0 4px 4px 0;
}

/* Progress bar styles */
.progress-container {
    height: 20px;
    background-color: #eee;
    border-radius: 10px;
    margin-top: 15px;
    position: relative;
    overflow: hidden;
}

.progress-bar {
    height: 100%;
    background-color: #3498db;
    width: 0%;
    transition: width 0.3s ease;
}

.progress-text {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    text-align: center;
    line-height: 20px;
    color: white;
    font-weight: 600;
    font-size: 0.8rem;
    text-shadow: 0 0 2px rgba(0, 0, 0, 0.5);
}

/* File list styles */
.file-list {
    margin-top: 20px;
}

.file-item {
    display: flex;
    padding: 15px;
    background-color: #f8f9fa;
    border-radius: 6px;
    margin-bottom: 10px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s;
}

.file-item:hover {
    transform: translateY(-2px);
}

.file-icon {
    font-size: 2rem;
    margin-right: 15px;
    display: flex;
    align-items: center;
}

.file-details {
    flex: 1;
}

.file-name {
    font-weight: 600;
    margin-bottom: 5px;
    word-break: break-all;
}

.file-meta, .file-id {
    font-size: 0.85rem;
    color: #666;
    margin-bottom: 5px;
}

.file-links {
    margin-top: 8px;
}

.file-links a {
    display: inline-block;
    margin-right: 15px;
    text-decoration: none;
    font-weight: 600;
    font-size: 0.9rem;
}

.view-link {
    color: #3498db;
}

.delete-link {
    color: #e74c3c;
}

.view-link:hover, .delete-link:hover {
    text-decoration: underline;
}

/* Message styles */
.message {
    padding: 10px 15px;
    margin-bottom: 20px;
    border-radius: 4px;
    font-weight: 500;
}

.success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

/* Responsive styles */
@media (max-width: 768px) {
    .container {
        padding: 20px;
    }
    
    .custom-file-upload {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .file-label {
        margin-bottom: 10px;
        margin-right: 0;
    }
    
    .input-group {
        flex-direction: column;
    }
    
    .url-input {
        border-radius: 4px;
        margin-bottom: 10px;
    }
    
    .input-group .fetch-btn {
        border-radius: 4px;
    }
    
    .file-item {
        flex-direction: column;
    }
    
    .file-icon {
        margin-right: 0;
        margin-bottom: 10px;
    }
}
</style>
</head>
<body>
    <div class="container">
        <h1>File Upload System</h1>
        
        <div class="upload-container">
            <h2>Local File Upload</h2>
            <div class="custom-file-upload">
                <input type="file" id="fileInput" class="file-input">
                <label for="fileInput" class="file-label">Choose File</label>
                <span id="fileSelected">No file selected</span>
            </div>
            <button id="uploadBtn" class="btn upload-btn" disabled>Upload File</button>
            <div class="progress-container" id="localProgressContainer">
                <div class="progress-bar" id="localProgressBar"></div>
                <div class="progress-text" id="localProgressText">0%</div>
            </div>
        </div>
        
        <div class="upload-container">
            <h2>Remote URL Upload</h2>
            <div class="input-group">
                <input type="text" id="remoteUrlInput" placeholder="Enter file URL" class="url-input">
                <button id="fetchBtn" class="btn fetch-btn">Fetch File</button>
            </div>
            <div class="progress-container" id="remoteProgressContainer">
                <div class="progress-bar" id="remoteProgressBar"></div>
                <div class="progress-text" id="remoteProgressText">0%</div>
            </div>
        </div>
        
        <div class="result-container" id="resultContainer">
            <h2>Uploaded Files</h2>
            <div id="fileList" class="file-list"></div>
        </div>
    </div>
    
    <script>
document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const fileInput = document.getElementById('fileInput');
    const fileSelected = document.getElementById('fileSelected');
    const uploadBtn = document.getElementById('uploadBtn');
    const remoteUrlInput = document.getElementById('remoteUrlInput');
    const fetchBtn = document.getElementById('fetchBtn');
    const localProgressBar = document.getElementById('localProgressBar');
    const localProgressText = document.getElementById('localProgressText');
    const remoteProgressBar = document.getElementById('remoteProgressBar');
    const remoteProgressText = document.getElementById('remoteProgressText');
    const resultContainer = document.getElementById('resultContainer');
    const fileList = document.getElementById('fileList');
    
    // Show file name when selected
    fileInput.addEventListener('change', function() {
        if (this.files && this.files[0]) {
            fileSelected.textContent = this.files[0].name;
            uploadBtn.disabled = false;
        } else {
            fileSelected.textContent = "No file selected";
            uploadBtn.disabled = true;
        }
    });
    
    // Local file upload
    uploadBtn.addEventListener('click', function() {
        if (!fileInput.files[0]) return;
        
        const file = fileInput.files[0];
        const formData = new FormData();
        formData.append('file', file);
        
        // Reset progress bar
        localProgressBar.style.width = '0%';
        localProgressText.textContent = '0%';
        
        // Create AJAX request
        const xhr = new XMLHttpRequest();
        
        // Setup progress event
        xhr.upload.addEventListener('progress', function(event) {
            if (event.lengthComputable) {
                const percentComplete = Math.round((event.loaded / event.total) * 100);
                localProgressBar.style.width = percentComplete + '%';
                localProgressText.textContent = percentComplete + '%';
            }
        });
        
        // Setup complete event
        xhr.addEventListener('load', function() {
            if (xhr.status === 200) {
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        displayFileInfo(response.file_info);
                        
                        // Reset form
                        fileInput.value = '';
                        fileSelected.textContent = "No file selected";
                        uploadBtn.disabled = true;
                        
                        // Show success message
                        showMessage('success', response.message);
                    } else {
                        showMessage('error', response.message);
                    }
                } catch (e) {
                    showMessage('error', 'Error parsing response from server.');
                }
            } else {
                showMessage('error', 'Server error: ' + xhr.status);
            }
        });
        
        // Setup error event
        xhr.addEventListener('error', function() {
            showMessage('error', 'Upload failed. Please try again.');
        });
        
        // Send request
        xhr.open('POST', 'upload.php', true);
        xhr.send(formData);
    });
    
    // Remote URL upload
    fetchBtn.addEventListener('click', function() {
        const remoteUrl = remoteUrlInput.value.trim();
        if (!remoteUrl) {
            showMessage('error', 'Please enter a valid URL.');
            return;
        }
        
        // Reset progress bar
        remoteProgressBar.style.width = '0%';
        remoteProgressText.textContent = '0%';
        
        // Create FormData
        const formData = new FormData();
        formData.append('remote_url', remoteUrl);
        
        // Create AJAX request
        const xhr = new XMLHttpRequest();
        
        // Setup load start event (show indeterminate progress)
        xhr.addEventListener('loadstart', function() {
            remoteProgressBar.style.width = '10%';
            remoteProgressText.textContent = 'Downloading...';
        });
        
        // Setup complete event
        xhr.addEventListener('load', function() {
            if (xhr.status === 200) {
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        // Show 100% completion
                        remoteProgressBar.style.width = '100%';
                        remoteProgressText.textContent = '100%';
                        
                        displayFileInfo(response.file_info);
                        
                        // Reset form
                        remoteUrlInput.value = '';
                        
                        // Show success message
                        showMessage('success', response.message);
                    } else {
                        showMessage('error', response.message);
                    }
                } catch (e) {
                    showMessage('error', 'Error parsing response from server.');
                }
            } else {
                showMessage('error', 'Server error: ' + xhr.status);
            }
        });
        
        // Setup error event
        xhr.addEventListener('error', function() {
            showMessage('error', 'Download failed. Please try again.');
        });
        
        // Send request
        xhr.open('POST', 'upload.php', true);
        xhr.send(formData);
    });
    
    // Display file information
    function displayFileInfo(fileInfo) {
        if (!fileInfo) return;
        
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        fileItem.id = 'file-' + fileInfo.md5;
        
        // Determine file icon based on type
        let fileIcon = '';
        if (fileInfo.type.includes('image')) {
            fileIcon = '<span class="file-icon">🖼️</span>';
        } else if (fileInfo.type.includes('video')) {
            fileIcon = '<span class="file-icon">🎬</span>';
        } else if (fileInfo.type.includes('audio')) {
            fileIcon = '<span class="file-icon">🎵</span>';
        } else if (fileInfo.type.includes('pdf')) {
            fileIcon = '<span class="file-icon">📄</span>';
        } else if (fileInfo.type.includes('text')) {
            fileIcon = '<span class="file-icon">📝</span>';
        } else {
            fileIcon = '<span class="file-icon">📁</span>';
        }
        
        fileItem.innerHTML = `
            ${fileIcon}
            <div class="file-details">
                <div class="file-name">${fileInfo.name}</div>
                <div class="file-meta">Size: ${fileInfo.size} | Type: ${fileInfo.type}</div>
                <div class="file-id">ID: ${fileInfo.md5}</div>
                <div class="file-links">
                    <a href="${fileInfo.url}" target="_blank" class="view-link">View File</a>
                     <a href="http://wetv.zya.me/up-claude1/delete.php?id=${fileInfo.md5}" target="_blank" class="delete-link">Link Delete</a>
                    <a href="javascript:void(0);" class="delete-link" data-id="${fileInfo.md5}">Delete File</a>
                </div>
            </div>
        `;
        
        // Add to file list
        fileList.prepend(fileItem);
        
        // Add event listener for delete link
        const deleteLink = fileItem.querySelector('.delete-link');
        deleteLink.addEventListener('click', function() {
            deleteFile(this.getAttribute('data-id'));
        });
    }
    
    // Delete file
    function deleteFile(fileId) {
        if (!confirm('Are you sure you want to delete this file?')) {
            return;
        }
        
        // Create AJAX request
        const xhr = new XMLHttpRequest();
        
        // Setup complete event
        xhr.addEventListener('load', function() {
            if (xhr.status === 200) {
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        // Remove file item from list
                        const fileItem = document.getElementById('file-' + fileId);
                        if (fileItem) {
                            fileItem.remove();
                        }
                        
                        // Show success message
                        showMessage('success', response.message);
                    } else {
                        showMessage('error', response.message);
                    }
                } catch (e) {
                    showMessage('error', 'Error parsing response from server.');
                }
            } else {
                showMessage('error', 'Server error: ' + xhr.status);
            }
        });
        
        // Setup error event
        xhr.addEventListener('error', function() {
            showMessage('error', 'Delete operation failed. Please try again.');
        });
        
        // Send request
        xhr.open('GET', 'delete.php?id=' + fileId, true);
        xhr.send();
    }
    
    // Show message function
    function showMessage(type, message) {
        const messageContainer = document.createElement('div');
        messageContainer.className = 'message ' + type;
        messageContainer.textContent = message;
        
        document.querySelector('.container').prepend(messageContainer);
        
        // Auto-remove message after 5 seconds
        setTimeout(function() {
            messageContainer.remove();
        }, 5000);
    }
    
    // Check for existing files
    function loadExistingFiles() {
        // This would typically involve an AJAX call to a server endpoint
        // that returns the list of uploaded files
        // For this example, we'll leave it as a placeholder
    }
    
    // Load existing files on page load
    loadExistingFiles();
});
</script>
</body>
</html>