<?php
// source:https://grok.com/c/a5d424eb-59c4-4743-bc1c-86b85686db68
// upload_chunks.php

$uploadDir = 'uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

if (isset($_POST['finalize'])) {
    $fileName = $_POST['fileName'];
    $totalChunks = intval($_POST['totalChunks']);
    $tempFile = $uploadDir . $fileName . '.part';

    // Verify all chunks are present
    $isComplete = true;
    for ($i = 1; $i <= $totalChunks; $i++) {
        if (!file_exists($uploadDir . $fileName . '.chunk' . $i)) {
            $isComplete = false;
            break;
        }
    }

    if ($isComplete) {
        $finalFile = $uploadDir . $fileName;
        $fp = fopen($tempFile, 'wb');
        for ($i = 1; $i <= $totalChunks; $i++) {
            $chunkFile = $uploadDir . $fileName . '.chunk' . $i;
            $chunk = fopen($chunkFile, 'rb');
            stream_copy_to_stream($chunk, $fp);
            fclose($chunk);
            unlink($chunkFile);
        }
        fclose($fp);
        rename($tempFile, $finalFile);

        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
    exit;
}

if (isset($_FILES['chunk'])) {
    $fileName = $_POST['fileName'];
    $chunkNumber = intval($_POST['chunkNumber']);

    $chunkFile = $uploadDir . $fileName . '.chunk' . $chunkNumber;

    if (move_uploaded_file($_FILES['chunk']['tmp_name'], $chunkFile)) {
        echo 'Chunk uploaded';
    } else {
        echo 'Error uploading chunk';
    }
}