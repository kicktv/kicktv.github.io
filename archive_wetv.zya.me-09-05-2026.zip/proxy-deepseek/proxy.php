<?php
// proxy.php

// Get the URL to fetch from the query string
$remoteUrl = $_GET['url'] ?? '';

if (empty($remoteUrl)) {
    die('URL parameter is missing.');
}

// Fetch the content from the remote URL
$content = file_get_contents($remoteUrl);

if ($content === false) {
    die('Failed to fetch content from the remote URL.');
}

// Modify the links in the content
$content = preg_replace_callback('/<a\s+(?:[^>]*?\s+)?href=(["\'])(.*?)\1/', function($matches) {
    $originalUrl = $matches[2];
    // Modify the URL as needed (e.g., prepend a proxy prefix)
    $newUrl = 'proxy.php?url=' . urlencode($originalUrl);
    return str_replace($originalUrl, $newUrl, $matches[0]);
}, $content);

// Output the modified content
echo $content;
?>