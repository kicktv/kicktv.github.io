<?php
// Ensure the uploads directory exists
$uploadDir = __DIR__ . '/uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['file'])) {
        $file = $_FILES['file'];
        $fileName = basename($file['name']);
        $filePath = $uploadDir . $fileName;

        // Generate MD5-encrypted ID
        $fileId = md5(uniqid($fileName, true));

        // Move uploaded file to the uploads directory
        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            // Generate download and delete links
            $downloadLink = "http://" . $_SERVER['HTTP_HOST'] . "/up-qwen/uploads/$fileName";
            $deleteLink = "http://" . $_SERVER['HTTP_HOST'] . "/up-qwen/delete.php?id=$fileId";

            // Store file metadata in a JSON file or database (optional)
            file_put_contents("$uploadDir/$fileId.json", json_encode([
                'id' => $fileId,
                'filename' => $fileName,
                'path' => $filePath
            ]));

            echo json_encode([
                'success' => true,
                'message' => '<center><h3>File uploaded successfully!.',
                'downloadLink' => $downloadLink,
                'deleteLink' => $deleteLink
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to upload file.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'No file uploaded.']);
    }
}
?>