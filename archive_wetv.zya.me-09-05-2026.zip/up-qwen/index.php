<!--
Create a script upload files with progress bar showing direct download link with delete link with md5 encrypted id 
using code php ajax html css JavaScript responsive
source=https://chat.qwenlm.ai/c/d5d451ae-a099-4e56-9566-de926dfddc3f
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload with Progress Bar</title>
    <style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background-color: #f4f4f9;
}

.container {
    text-align: center;
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.progress-bar {
    width: 100%;
    height: 20px;
    background: #e0e0e0;
    border-radius: 10px;
    overflow: hidden;
    margin: 20px 0;
}

.progress {
    height: 100%;
    width: 0;
    background: #4caf50;
    transition: width 0.3s ease;
}

#result {
    margin-top: 20px;
    text-align: left;
}

#result a {
    display: block;
    margin: 5px 0;
    color: #007bff;
    text-decoration: none;
}

#result a:hover {
    text-decoration: underline;
}
</style>
</head>
<body>
    <div class="container">
        <h1>Upload File</h1>
        <form id="uploadForm" enctype="multipart/form-data">
            <input type="file" name="file" id="fileInput" required>
            <button type="submit">Upload</button>
        </form>
        <div class="progress-bar">
            <div id="progress" class="progress"></div>
        </div>
        <div id="result"></div>
    </div>
    <script>
document.getElementById('uploadForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const fileInput = document.getElementById('fileInput');
    const formData = new FormData();
    formData.append('file', fileInput.files[0]);

    const xhr = new XMLHttpRequest();
    const progressBar = document.getElementById('progress');

    xhr.upload.addEventListener('progress', function (event) {
        if (event.lengthComputable) {
            const percentComplete = (event.loaded / event.total) * 100;
            progressBar.style.width = percentComplete + '%';
        }
    });

    xhr.addEventListener('load', function () {
        const response = JSON.parse(xhr.responseText);
        const resultDiv = document.getElementById('result');

        if (response.success) {
            resultDiv.innerHTML = `
                <p>${response.message}</p>
                <a href="${response.downloadLink}" target="_blank">Download File</a>
                <a href="${response.deleteLink}" onclick="return confirm('Are you sure?')">Delete File</a>
            `;
        } else {
            resultDiv.innerHTML = `<p style="color: red;">${response.message}</p>`;
        }

        progressBar.style.width = '0%'; // Reset progress bar
    });

    xhr.open('POST', 'upload.php', true);
    xhr.send(formData);
});
</script>
</body>
</html>