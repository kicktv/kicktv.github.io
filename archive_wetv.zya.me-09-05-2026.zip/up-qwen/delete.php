<?php
$uploadDir = __DIR__ . '/uploads/';

if (isset($_GET['id'])) {
    $fileId = $_GET['id'];
    $metadataFile = "$uploadDir/$fileId.json";

    if (file_exists($metadataFile)) {
        $metadata = json_decode(file_get_contents($metadataFile), true);

        // Delete the file and its metadata
        if (unlink($metadata['path']) && unlink($metadataFile)) {
            echo json_encode(['success' => true, 'message' => '<center><h1>File deleted successfully.']);
        } else {
            echo json_encode(['success' => false, 'message' => '<center><h1>Failed to delete file.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => '<center><h1>File not found.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => '<center><h1>Invalid request.']);
}
?>