<?php
//https://chatgpt.com/c/682f67b8-64f4-800e-b12c-9ebe30d295ae

$uploadDir = "uploads/";
$maxSize = 15 * 1024 * 1024;
$allowedExtensions = [
  'jpg', 'jpeg', 'png', 'gif',
  'mp4', 'avi', 'mkv',
  'mp3', 'wav',
  'txt', 'pdf'
];

function sanitizeFileName($name) {
  return preg_replace("/[^a-zA-Z0-9_\.-]/", "_", basename($name));
}

// Handle delete request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
  $filename = basename($_POST['delete']);
  $filepath = $uploadDir . $filename;
  if (file_exists($filepath)) {
    unlink($filepath);
    echo json_encode(["status" => "success", "message" => "File deleted."]);
  } else {
    echo json_encode(["status" => "error", "message" => "File not found."]);
  }
  exit;
}

// Handle upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_FILES['file'])) {
    $file = $_FILES['file'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
      exit(json_encode(["status" => "error", "message" => "Upload error."]));
    }
    if ($file['size'] > $maxSize) {
      exit(json_encode(["status" => "error", "message" => "File exceeds 15MB."]));
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExtensions)) {
      exit(json_encode(["status" => "error", "message" => "Unsupported file type."]));
    }

    $safeName = uniqid() . "_" . sanitizeFileName($file['name']);
    move_uploaded_file($file['tmp_name'], $uploadDir . $safeName);

    echo json_encode([
      "status" => "success",
      "message" => "Upload successful.",
      "file" => $uploadDir . $safeName,
      "delete" => "upload.php"
    ]);
    exit;

  } elseif (!empty($_POST['remote_url'])) {
    $url = filter_var($_POST['remote_url'], FILTER_SANITIZE_URL);
    $data = file_get_contents($url);
    if ($data === false) {
      exit(json_encode(["status" => "error", "message" => "Download failed."]));
    }

    $ext = strtolower(pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExtensions)) {
      exit(json_encode(["status" => "error", "message" => "Unsupported remote file type."]));
    }

    if (strlen($data) > $maxSize) {
      exit(json_encode(["status" => "error", "message" => "Remote file too large."]));
    }

    $safeName = uniqid() . "_" . sanitizeFileName(basename($url));
    file_put_contents($uploadDir . $safeName, $data);

    echo json_encode([
      "status" => "success",
      "message" => "Remote upload successful.",
      "file" => $uploadDir . $safeName,
      "delete" => "upload.php"
    ]);
    exit;
  }

  exit(json_encode(["status" => "error", "message" => "No file or URL provided."]));
}
