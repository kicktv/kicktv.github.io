<?php

header('Content-Type: application/json');
$allowed_extensions = ['mp4', 'mp3', 'png', 'jpeg', 'jpg', 'gif', 'txt', 'pdf'];

if (isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);

    if (!in_array($extension, $allowed_extensions)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid file type']);
        exit;
    }

    $filename = md5(uniqid()) . '.' . $extension;
    move_uploaded_file($file['tmp_name'], 'uploads/' . $filename);

    echo json_encode([
        'direct_link' => '/uploads/' . $filename,
        'delete_link' => '/delete.php?id=' . md5($filename),
    ]);
} elseif (isset($_POST['url']) && !empty($_POST['url'])) {
    $url = $_POST['url'];
    $extension = pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION);

    if (!in_array($extension, $allowed_extensions)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid URL file type']);
        exit;
    }

    $content = file_get_contents($url);
    if ($content === false) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid URL']);
        exit;
    }

    $filename = md5(uniqid()) . '.' . $extension;
    file_put_contents('uploads/' . $filename, $content);

    echo json_encode([
        'direct_link' => '/up-copilot.microsoft/uploads/' . $filename,
        'delete_link' => '/up-copilot.microsoft/delete.php?id=' . md5($filename),
    ]);
} else {
    http_response_code(400);
    echo json_encode(['error' => 'No file or URL provided']);
    exit;
}
?>
