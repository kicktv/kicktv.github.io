<?php
// upload.php

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $allowed_extensions = ['mp4', 'mp3', 'png', 'jpeg', 'jpg', 'gif', 'txt', 'pdf'];
    $file = $_FILES['file'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];

    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    if (in_array($file_ext, $allowed_extensions)) {
        if ($file_error === 0) {
            if ($file_size <= 20000000) { // 20 MB limit
                $file_name_new = uniqid('', true) . '.' . $file_ext;
                $file_destination = 'uploads/' . $file_name_new;

                if (move_uploaded_file($file_tmp, $file_destination)) {
                    $file_md5 = md5_file($file_destination);

                    $response = [
                        'success' => true,
                        'message' => 'File uploaded successfully!',
                        'file_url' => $file_destination,
                        'file_md5' => $file_md5,
                    ];
                    echo json_encode($response);
                } else {
                    $response = ['success' => false, 'message' => 'Failed to move file.'];
                    echo json_encode($response);
                }
            } else {
                $response = ['success' => false, 'message' => 'File size too large.'];
                echo json_encode($response);
            }
        } else {
            $response = ['success' => false, 'message' => 'Error uploading file.'];
            echo json_encode($response);
        }
    } else {
        $response = ['success' => false, 'message' => 'Invalid file type. Allowed types: ' . implode(', ', $allowed_extensions)];
        echo json_encode($response);
    }
}else if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_md5'])){
    $md5_to_delete = $_POST['delete_md5'];
    $files = glob('uploads/*');
    foreach($files as $file){
        if(md5_file($file) === $md5_to_delete){
            unlink($file);
            $response = ['success' => true, 'message' => 'File deleted successfully!'];
            echo json_encode($response);
            return;
        }
    }
    $response = ['success' => false, 'message' => 'File not found.'];
    echo json_encode($response);
}
else {
    $response = ['success' => false, 'message' => 'Invalid request.'];
    echo json_encode($response);
}
?>