<?php
//https://chatgpt.com/c/68ccaa97-0db8-8324-84fe-6a030bec75f1

session_start();

/* CONFIGURATION */
$PASSWORD = "admin123"; // Set your password
$ROOT_DIR =  '../';   //__DIR__; // Root folder
$ALLOWED_EXT = ['jpg','jpeg','png','gif','txt','pdf','zip','mp3','mp4','html','css','js','php'];

/* LOGIN */
if(isset($_POST['password'])){
    if($_POST['password'] === $PASSWORD) $_SESSION['logged_in'] = true;
    else $error = "Incorrect password!";
}
if(isset($_GET['logout'])){ session_destroy(); header("Location: file-manager.php"); exit; }
if(!isset($_SESSION['logged_in'])){
    ?>
    <!DOCTYPE html>
    <html><head><title>Login</title>
    <style>
    body{font-family:sans-serif;display:flex;justify-content:center;align-items:center;height:100vh;background:#f0f0f0;}
    form{background:#fff;padding:20px;border-radius:8px;box-shadow:0 0 10px rgba(0,0,0,0.2);}
    input[type=password]{padding:10px;width:200px;margin-bottom:10px;}
    input[type=submit]{padding:10px 20px;}
    .error{color:red;margin-bottom:10px;}
    </style></head>
    <body>
        <form method="post">
            <h2>Login</h2>
            <?php if(isset($error)) echo "<div class='error'>$error</div>"; ?>
            <input type="password" name="password" placeholder="Password" required><br>
            <input type="submit" value="Login">
        </form>
    </body></html>
    <?php exit;
}

/* HELPER FUNCTIONS */
function sanitize($name){ return basename($name); }
$current_dir = isset($_GET['dir']) ? sanitize($_GET['dir']) : '';
$full_path = realpath($ROOT_DIR.'/'.$current_dir);
if(strpos($full_path,$ROOT_DIR)!==0) $full_path=$ROOT_DIR;

/* FILE OPERATIONS */
// Upload local
if(isset($_FILES['file_upload'])){
    $file=$_FILES['file_upload'];
    $filename=sanitize($file['name']);
    $ext=strtolower(pathinfo($filename,PATHINFO_EXTENSION));
    if(in_array($ext,$ALLOWED_EXT)){
        move_uploaded_file($file['tmp_name'], "$full_path/$filename");
        $msg="File uploaded!";
    }else $msg="File type not allowed!";
}

// Remote upload
if(isset($_POST['remote_url'])){
    $url=$_POST['remote_url'];
    $filename=basename(parse_url($url,PHP_URL_PATH));
    $ext=strtolower(pathinfo($filename,PATHINFO_EXTENSION));
    if(in_array($ext,$ALLOWED_EXT)){
        $content=@file_get_contents($url);
        if($content){ file_put_contents("$full_path/$filename",$content); $msg="Remote file uploaded!"; }
        else $msg="Failed to fetch remote file!";
    }else $msg="Remote file type not allowed!";
}

// Create folder
if(isset($_POST['new_folder'])){
    $folder=sanitize($_POST['new_folder']);
    $path="$full_path/$folder";
    if(!is_dir($path)){ mkdir($path,0777,true); $msg="Folder created!"; }
    else $msg="Folder already exists!";
}

// Create new file
if(isset($_POST['new_file'])){
    $file=sanitize($_POST['new_file']);
    $path="$full_path/$file";
    if(!file_exists($path)){ file_put_contents($path,""); $msg="File created!"; }
    else $msg="File already exists!";
}

// Delete
if(isset($_GET['delete'])){
    $target=sanitize($_GET['delete']);
    $path="$full_path/$target";
    if(is_file($path)) unlink($path);
    elseif(is_dir($path)) rmdir($path);
    header("Location: file-manager.php?dir=$current_dir"); exit;
}

// Rename (modal)
if(isset($_POST['rename_old']) && isset($_POST['rename_new'])){
    $old=sanitize($_POST['rename_old']);
    $new=sanitize($_POST['rename_new']);
    $old_path="$full_path/$old";
    $new_path="$full_path/$new";
    if(file_exists($old_path) && !file_exists($new_path)){ rename($old_path,$new_path); $msg="Renamed successfully!"; }
    else $msg="Rename failed!";
}

// Edit text
if(isset($_GET['edit'])){
    $edit_file=sanitize($_GET['edit']);
    $edit_path="$full_path/$edit_file";
    if(isset($_POST['edit_content'])){ file_put_contents($edit_path,$_POST['edit_content']); $msg="File saved!"; }
    $content=htmlspecialchars(file_get_contents($edit_path));
    ?>
    <!DOCTYPE html>
    <html>
    <head><title>Edit <?php echo $edit_file;?></title>
        <style>body{font-family:sans-serif;padding:20px;} textarea{width:100%;height:400px;} input[type=submit]{padding:10px 20px;margin-top:10px;}</style>
    </head>
    <body>
        <h2>Editing: <?php echo $edit_file;?></h2>
        <?php if(isset($msg)) echo "<div style='color:green;'>$msg</div>"; ?>
        <form method="post">
            <textarea name="edit_content"><?php echo $content;?></textarea><br>
            <input type="submit" value="Save">
        </form>
        <a href="file-manager.php?dir=<?php echo urlencode($current_dir);?>">Back</a>
    </body></html>
    <?php exit;
}

// Copy file
if(isset($_GET['copy'])){
    $copy_file=sanitize($_GET['copy']);
    $source="$full_path/$copy_file";
    $dest="$full_path/copy_$copy_file";
    if(file_exists($source)){ copy($source,$dest); $msg="File copied!"; }
    header("Location: file-manager.php?dir=$current_dir"); exit;
}

// Zip
if(isset($_GET['zip'])){
    $zip_file=sanitize($_GET['zip']);
    $zip_path="$full_path/$zip_file.zip";
    $zip = new ZipArchive();
    if($zip->open($zip_path, ZipArchive::CREATE)===TRUE){
        if(is_dir("$full_path/$zip_file")){
            $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator("$full_path/$zip_file"));
            foreach($files as $file){
                if(!$file->isDir()){
                    $zip->addFile($file->getRealPath(), substr($file->getRealPath(), strlen($full_path)+1));
                }
            }
        }elseif(is_file("$full_path/$zip_file")) $zip->addFile("$full_path/$zip_file", $zip_file);
        $zip->close(); $msg="Zipped successfully!";
    }else $msg="Zip failed!";
    header("Location: file-manager.php?dir=$current_dir"); exit;
}

// Unzip
if(isset($_GET['unzip'])){
    $unzip_file=sanitize($_GET['unzip']);
    $zip_path="$full_path/$unzip_file";
    $zip = new ZipArchive();
    if($zip->open($zip_path)===TRUE){ $zip->extractTo($full_path); $zip->close(); $msg="Unzipped successfully!"; }
    else $msg="Unzip failed!";
    header("Location: file-manager.php?dir=$current_dir"); exit;
}

/* SEARCH & SORT */
$search = isset($_GET['search']) ? $_GET['search'] : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'name';
function scan_dir_recursive($dir,$search=''){
    $result=[];
    $items=scandir($dir);
    foreach($items as $item){
        if($item=='.' || $item=='..') continue;
        $path="$dir/$item";
        if($search=='' || stripos($item,$search)!==false) $result[]=$path;
        if(is_dir($path)) $result=array_merge($result, scan_dir_recursive($path,$search));
    }
    return $result;
}
$files = scan_dir_recursive($full_path, $search);
usort($files, function($a,$b) use ($sort){
    switch($sort){
        case 'size': return filesize($a)<=>filesize($b);
        case 'type': return (is_dir($a)?0:1)<=> (is_dir($b)?0:1);
        case 'modified': return filemtime($a)<=>filemtime($b);
        default: return strtolower(basename($a))<=>strtolower(basename($b));
    }
});
?>

<!DOCTYPE html>
<html>
<head>
<title>PHP File Manager</title>
<style>
body{font-family:sans-serif;margin:0;padding:0;background:#f7f7f7;}
header{background:#333;color:#fff;padding:10px;}
header a{color:#fff;margin-left:20px;text-decoration:none;}
main{padding:20px;}
table{width:100%;border-collapse:collapse;}
th, td{padding:10px;text-align:left;border-bottom:1px solid #ccc;}
th{background:#eee;}
a.button{padding:5px 10px;background:#007BFF;color:#fff;text-decoration:none;border-radius:4px;margin-right:3px;}
a.button:hover{background:#0056b3;}
form.inline{display:inline;}
input.rename-input{width:100px;padding:3px;margin-right:3px;}
input[type=text], input[type=file]{padding:5px;}
.msg{padding:10px;background:#d4edda;color:#155724;margin-bottom:10px;border-radius:4px;}
#drop_area{border:2px dashed #007BFF;padding:20px;text-align:center;margin-bottom:20px;color:#007BFF;}
img.thumb{width:50px;height:50px;object-fit:cover;border-radius:4px;margin-right:5px;}
.modal{display:none;position:fixed;z-index:1000;left:0;top:0;width:100%;height:100%;overflow:auto;background:rgba(0,0,0,0.5);}
.modal-content{background:#fff;margin:15% auto;padding:20px;border-radius:8px;width:300px;}
.close{color:#aaa;float:right;font-size:28px;font-weight:bold;cursor:pointer;}
.close:hover{color:#000;}
</style>
</head>
<body>
<header>
<strong>PHP File Manager</strong>
<a href="file-manager.php?logout=1">Logout</a>
</header>
<main>
<?php if(isset($msg)) echo "<div class='msg'>$msg</div>"; ?>

<!-- Drag & Drop Upload -->
<div id="drop_area">Drag & Drop Files Here</div>

<!-- Upload Forms -->
<form method="post" enctype="multipart/form-data">
<input type="file" name="file_upload" required>
<input type="submit" value="Upload">
</form>

<form method="post">
<input type="text" name="remote_url" placeholder="Remote file URL" required style="width:300px;">
<input type="submit" value="Upload Remote">
</form>

<!-- Create New Folder -->
<form method="post">
<input type="text" name="new_folder" placeholder="New Folder Name" required style="width:200px;">
<input type="submit" value="Create Folder">
</form>

<!-- Create New File -->
<form method="post">
<input type="text" name="new_file" placeholder="New File Name" required style="width:200px;">
<input type="submit" value="Create File">
</form>

<!-- Search & Sort -->
<form method="get">
<input type="text" name="search" placeholder="Search files/folders" value="<?php echo htmlspecialchars($search); ?>">
<select name="sort">
<option value="name" <?php if($sort=='name') echo 'selected';?>>Name</option>
<option value="size" <?php if($sort=='size') echo 'selected';?>>Size</option>
<option value="type" <?php if($sort=='type') echo 'selected';?>>Type</option>
<option value="modified" <?php if($sort=='modified') echo 'selected';?>>Modified</option>
</select>
<input type="hidden" name="dir" value="<?php echo htmlspecialchars($current_dir);?>">
<input type="submit" value="Search & Sort">
</form>

<table>
<tr><th>Name</th><th>Size</th><th>Type</th><th>Modified</th><th>Actions</th></tr>

<?php
foreach($files as $file_path){
    $file = basename($file_path);
    $rel_path = str_replace($ROOT_DIR.'/', '', $file_path);
    $size = is_file($file_path)?filesize($file_path):'-';
    $type = is_dir($file_path)?'Folder':'File';
    $modified = date("Y-m-d H:i:s", filemtime($file_path));

    // File Icons
    $ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));
    $icon='';
    if(in_array($ext,['html','php'])) $icon='📄';
    elseif($ext=='txt') $icon='📝';
    elseif($ext=='css') $icon='🎨';
    elseif($ext=='js') $icon='⚙️';
    elseif($ext=='mp4') $icon='🎬';
    elseif($ext=='mp3') $icon='🎵';
    elseif(in_array($ext,['jpg','jpeg','png','gif'])) $icon='🖼️';
    else $icon='📁';

    echo "<tr><td>$icon ";
    if(is_dir($file_path)) echo "<a href='file-manager.php?dir=".urlencode($rel_path)."'>$file</a>";
    else echo "$file";
    echo "</td><td>$size</td><td>$type</td><td>$modified</td><td>";
    echo "<a class='button' href='file-manager.php?dir=$current_dir&delete=$file' onclick=\"return confirm('Delete?')\">Delete</a>";
    if(is_file($file_path)) echo "<a class='button' href='$rel_path' download>Download</a>";
    echo "<a class='button' href='#' onclick=\"openRenameModal('$file')\">Rename</a>";
    if(is_file($file_path) && in_array($ext,['txt','html','php','css','js'])) echo "<a class='button' href='file-manager.php?dir=$current_dir&edit=$file'>Edit</a>";
    echo "<a class='button' href='file-manager.php?dir=$current_dir&copy=$file'>Copy</a>";
    echo "<a class='button' href='file-manager.php?dir=$current_dir&zip=$file'>Zip</a>";
    if($ext=='zip') echo "<a class='button' href='file-manager.php?dir=$current_dir&unzip=$file'>Unzip</a>";
    echo "</td></tr>";
}
?>
</table>

<!-- Rename Modal -->
<div id="renameModal" class="modal">
<div class="modal-content">
<span class="close" onclick="closeRenameModal()">&times;</span>
<h3>Rename File</h3>
<form method="post">
<input type="hidden" name="rename_old" id="rename_old">
<input type="text" name="rename_new" id="rename_new" placeholder="New name" required>
<input type="submit" class="button" value="Rename">
</form>
</div>
</div>

<script>
// Drag & Drop
let dropArea = document.getElementById('drop_area');
dropArea.addEventListener('dragover', e=>{ e.preventDefault(); dropArea.style.background='#cce5ff'; });
dropArea.addEventListener('dragleave', e=>{ e.preventDefault(); dropArea.style.background='#007BFF'; });
dropArea.addEventListener('drop', e=>{
    e.preventDefault();
    let files=e.dataTransfer.files;
    let formData=new FormData();
    for(let i=0;i<files.length;i++) formData.append('file_upload',files[i]);
    fetch('file-manager.php?dir=<?php echo urlencode($current_dir);?>',{method:'POST',body:formData})
    .then(()=>location.reload());
});

// Rename Modal
function openRenameModal(filename){
    document.getElementById('rename_old').value=filename;
    document.getElementById('rename_new').value=filename;
    document.getElementById('renameModal').style.display='block';
}
function closeRenameModal(){ document.getElementById('renameModal').style.display='none'; }
window.onclick=function(event){ if(event.target==document.getElementById('renameModal')) closeRenameModal(); }
</script>

</main>
</body>
</html>
