<?php


// Simple AI-like Code Generator (Rule Based)

// Get user prompt
$prompt = isset($_POST['prompt']) ? strtolower(trim($_POST['prompt'])) : '';

$result = '';

function generateCode($prompt) {

    // LOGIN PAGE
    if (strpos($prompt, 'login') !== false) {
        return '
<!-- Login Page -->
<form method="POST" action="login.php">
  <input type="text" name="username" placeholder="Username" required>
  <input type="password" name="password" placeholder="Password" required>
  <button type="submit">Login</button>
</form>
<style>
form { width:300px;margin:auto;padding:20px;border:1px solid #ccc; }
input,button { width:100%;margin:5px 0;padding:10px; }
</style>
        ';
    }

    // CONTACT FORM
    if (strpos($prompt, 'contact') !== false) {
        return '
<form method="POST" action="send.php">
  <input type="text" name="name" placeholder="Name">
  <input type="email" name="email" placeholder="Email">
  <textarea name="message" placeholder="Message"></textarea>
  <button type="submit">Send</button>
</form>
        ';
    }

    // NAVBAR
    if (strpos($prompt, 'navbar') !== false) {
        return '
<nav style="background:#333;padding:10px;">
  <a href="#" style="color:white;margin-right:10px;">Home</a>
  <a href="#" style="color:white;margin-right:10px;">About</a>
  <a href="#" style="color:white;">Contact</a>
</nav>
        ';
    }

    // UPLOAD SYSTEM PHP
    if (strpos($prompt, 'upload') !== false) {
        return '
<form method="POST" enctype="multipart/form-data">
  <input type="file" name="file">
  <button type="submit">Upload</button>
</form>

<?php
if($_FILES){
    move_uploaded_file($_FILES["file"]["tmp_name"], "uploads/" . $_FILES["file"]["name"]);
    echo "File uploaded!";
}
?>
        ';
    }

    return "❌ لا يوجد قالب مناسب لهذا الطلب.";
}

// Generate result
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = generateCode($prompt);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>AI Code Generator (PHP)</title>
</head>
<body>

<h2>AI Code Generator (PHP Only)</h2>

<form method="POST">
    <input type="text" name="prompt" placeholder="مثال: login page or navbar" style="width:300px;padding:10px;">
    <button type="submit">Generate</button>
</form>

<pre style="background:#111;color:#0f0;padding:15px;margin-top:20px;">
<?= htmlspecialchars($result) ?>
</pre>

</body>
</html>