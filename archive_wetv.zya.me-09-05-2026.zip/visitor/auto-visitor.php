<?php
// Source:https://chatgpt.com/c/68e9813f-8bb0-8331-86e1-f97438a88ba8

function randomUserAgent() {
    $agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_2) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:115.0) Gecko/20100101 Firefox/115.0",
        "Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 16_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile Safari/604.1",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ];
    return $agents[array_rand($agents)];
}

function randomReferer() {
    $referrers = [
        "https://www.google.com",
        "https://www.facebook.com",
        "https://www.youtube.com",
        "https://www.bing.com",
        "https://yandex.com",
        "https://search.yahoo.com",
        "https://twitter.com"
    ];
    return $referrers[array_rand($referrers)];
}

function visitURL($url, $proxy = null) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, randomUserAgent());
    curl_setopt($ch, CURLOPT_REFERER, randomReferer());
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);

    if (!empty($proxy)) {
        curl_setopt($ch, CURLOPT_PROXY, $proxy);
    }

    $result = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return $status;
}

$resultLog = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $url = trim($_POST['url']);
    $visits = intval($_POST['quantity']);
    $proxy = trim($_POST['proxy']);

    if (filter_var($url, FILTER_VALIDATE_URL)) {
        $success = 0;
        $failed = 0;
        $resultLog .= "<div class='log-title'>Visiting <b>$url</b> ($visits times)</div>";

        for ($i = 1; $i <= $visits; $i++) {
            $status = visitURL($url, $proxy);
            if ($status >= 200 && $status < 400) {
                $resultLog .= "<div class='success'>[$i] ✅ Success (HTTP $status)</div>";
                $success++;
            } else {
                $resultLog .= "<div class='error'>[$i] ❌ Failed (HTTP $status)</div>";
                $failed++;
            }
            usleep(200000); // delay 0.2s between visits
            ob_flush();
            flush();
        }

        $resultLog .= "<div class='summary'>✅ Success: $success | ❌ Failed: $failed</div>";
    } else {
        $resultLog = "<div class='error'>Invalid URL format!</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Auto Visitor Web</title>
<style>
body {
    font-family: Arial, sans-serif;
background: #666;
    //background: linear-gradient(145deg, #0f2027, #203a43, #2c5364);
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    margin: 0;
}
.container {
background: #222;
   // background: rgba(255, 255, 255, 0.1);
    padding: 25px;
    border-radius: 15px;
    width: 90%;
    max-width: 480px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    text-align: center;
}
h1 {
    font-size: 26px;
    margin-bottom: 15px;
}
input, select {
    width: 100%;
    padding: 10px;
    margin: 8px 0;
    border: none;
    border-radius: 6px;
    outline: none;
}
input[type="text"], input[type="url"], select {
    //background: rgba(255, 255, 255, 0.2);
    background: rgba(70, 67, 67, 0.62);
    color: #fff;
}
input::placeholder {
    color: #ddd;
}
button {
    background: #1e90ff;
    color: #fff;
    padding: 12px;
    border: none;
    border-radius: 6px;
    width: 100%;
    cursor: pointer;
    font-size: 16px;
    margin-top: 10px;
}
button:hover {
    background: #0078e7;
}
.log {
    text-align: left;
    margin-top: 15px;
    background: rgba(0,0,0,0.3);
    padding: 10px;
    border-radius: 8px;
    height: 260px;
    overflow-y: auto;
    font-size: 14px;
}
.success { color: #00ff9d; }
.error { color: #ff6060; }
.summary {
    margin-top: 10px;
    font-weight: bold;
}
.log-title {
    text-align: center;
    font-weight: bold;
    color: #00c3ff;
    margin-bottom: 8px;
}
</style>
</head>
<body>
<div class="container">
    <h1>Auto Visitor Web</h1>
    <form method="post">
        <input type="url" name="url" placeholder="Enter website URL (https://...)" required>
        <select name="quantity" required>
             <option value="50">50 Visits</option>
            <option value="100">100 Visits</option>
            <option value="200">200 Visits</option>
            <option value="300">300 Visits</option>
            <option value="500">500 Visits</option>
            <option value="800">800 Visits</option>
            <option value="1000">1000 Visits</option>
            <option value="1300">1300 Visits</option>
            <option value="2000">2000 Visits</option>
            <option value="4000">4000 Visits</option>
            <option value="5000">5000 Visits</option>
        </select>
        <input type="text" name="proxy" placeholder="Optional Proxy (IP:PORT)">
        <button type="submit">Get Visitor Now</button>
    </form>

    <?php if(!empty($resultLog)) echo "<div class='log'>$resultLog</div>"; ?>
</div>
</body>
</html>
