<!-- https://claude.ai/chat/a28d49d9-07b5-476d-95fc-6e679738efaa -->
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Auto Visitor Web</title>
<style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            padding: 40px;
            max-width: 600px;
            width: 100%;
        }

        h1 {
            text-align: center;
            color: #667eea;
            margin-bottom: 30px;
            font-size: 2em;
        }

        .form-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }

        input[type="url"],
        input[type="text"],
        select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }

        input[type="url"]:focus,
        input[type="text"]:focus,
        select:focus {
            outline: none;
            border-color: #667eea;
            background: white;
        }

        .optional {
            color: #999;
            font-size: 12px;
            font-weight: normal;
        }

        button {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            margin-top: 10px;
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }

        button:active {
            transform: translateY(0);
        }

        .result {
            margin-top: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
            border-left: 4px solid #667eea;
            display: none;
        }

        .result.show {
            display: block;
        }

        .result h3 {
            color: #667eea;
            margin-bottom: 15px;
        }

        .result-item {
            padding: 10px;
            background: white;
            margin-bottom: 8px;
            border-radius: 5px;
            font-size: 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .success {
            color: #28a745;
            font-weight: bold;
        }

        .failed {
            color: #dc3545;
            font-weight: bold;
        }

        .loading {
            text-align: center;
            color: #667eea;
            padding: 20px;
            font-weight: bold;
        }

        @media (max-width: 768px) {
            .container {
                padding: 25px;
            }

            h1 {
                font-size: 1.5em;
            }

            button {
                font-size: 16px;
            }
        }
    </style>
</head><body>
<div class="container">
<h1>Auto Visitor Web</h1>
<form method="POST" action="">
<div class="form-group">
<label for="url">Target URL</label>
<input type="url" id="url" name="url" placeholder="https://example.com" required>
</div>

            <div class="form-group">
                <label for="quantity">Visit Quantity</label>
                <select id="quantity" name="quantity" required>
                     <option value="50">50 Visits</option>
                    <option value="100">100 Visits</option>
                    <option value="200">200 Visits</option>
                    <option value="300">300 Visits</option>
                    <option value="500">500 Visits</option>
                    <option value="800">800 Visits</option>
                    <option value="1000">1000 Visits</option>
                    <option value="1300">1300 Visits</option>
                    <option value="2000">2000 Visits</option>
                    <option value="4000">4000 Visits</option>
                    <option value="5000">5000 Visits</option>
                </select>
            </div>

            <div class="form-group">
                <label for="proxy">Proxy <span class="optional">(Optional)</span></label>
                <input type="text" id="proxy" name="proxy" placeholder="ip:port or http://ip:port">
            </div>

            <button type="submit" name="submit">Get Visitor Now</button>
        </form>

        <?php
        if (isset($_POST['submit'])) {
            $url = filter_var($_POST['url'], FILTER_VALIDATE_URL);
            $quantity = intval($_POST['quantity']);
            $proxy = !empty($_POST['proxy']) ? $_POST['proxy'] : null;
            
            if (!$url) {
                echo '<div class="result show"><h3>Error</h3><div class="result-item failed">Invalid URL provided</div></div>';
                exit;
            }

            $userAgents = [
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/120.0.0.0',
                'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15',
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0'
            ];

            $referers = [
                'https://www.google.com/search?q=' . urlencode(parse_url($url, PHP_URL_HOST)),
                'https://www.facebook.com/',
                'https://www.youtube.com/',
                'https://www.bing.com/search?q=' . urlencode(parse_url($url, PHP_URL_HOST)),
                'https://yandex.com/search/?text=' . urlencode(parse_url($url, PHP_URL_HOST)),
                'https://search.yahoo.com/search?p=' . urlencode(parse_url($url, PHP_URL_HOST)),
                'https://twitter.com/'
            ];

            echo '<div class="result show">';
            echo '<h3>Visitor Results</h3>';
            
            $success = 0;
            $failed = 0;
            
            for ($i = 0; $i < $quantity; $i++) {
                $ch = curl_init();
                
                $randomUserAgent = $userAgents[array_rand($userAgents)];
                $randomReferer = $referers[array_rand($referers)];
                
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
                curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                curl_setopt($ch, CURLOPT_USERAGENT, $randomUserAgent);
                curl_setopt($ch, CURLOPT_REFERER, $randomReferer);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
                
                if ($proxy) {
                    curl_setopt($ch, CURLOPT_PROXY, $proxy);
                }
                
                $result = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                
                if ($result !== false && $httpCode >= 200 && $httpCode < 400) {
                    $success++;
                    $status = '<span class="success">✓ Success</span>';
                } else {
                    $failed++;
                    $status = '<span class="failed">✗ Failed</span>';
                }
                
                echo '<div class="result-item">Visit #' . ($i + 1) . ' ' . $status . '</div>';
                
                if ($i % 10 == 0) {
                    flush();
                    ob_flush();
                }
                
                usleep(100000); // 0.1 second delay
            }
            
            echo '<div style="margin-top: 20px; padding: 15px; background: white; border-radius: 5px;">';
            echo '<strong>Summary:</strong><br>';
            echo '<span class="success">Successful: ' . $success . '</span><br>';
            echo '<span class="failed">Failed: ' . $failed . '</span><br>';
            echo '<strong>Total: ' . $quantity . '</strong>';
            echo '</div>';
            
            echo '</div>';
        }
        ?>
    </div>
</body>
</html>