<?php
// https://wetv.zya.me/blob/media.php?id=vid1
// https://wetv.zya.me/blob/media.php?id=img2
// media.php - Serves media files as blob data
session_start();

// Security: Add authentication check if needed
// if (!isset($_SESSION['user_id'])) {
//     http_response_code(403);
//     exit('Unauthorized');
// }

// Get the requested file ID
$fileId = $_GET['id'] ?? '';

if (empty($fileId)) {
    http_response_code(400);
    exit('Invalid request');
}

// Map file IDs to actual file paths (keep this mapping secure and hidden)
$fileMap = [
    'img1' => 'uploads/images/photo1.jpg',
    'img2' => 'uploads/images/photo2.png',
    'vid1' => 'uploads/videos/video1.mp4',
    'vid2' => 'uploads/videos/video2.webm',
    // Add more mappings as needed
];

// Check if file ID exists in mapping
if (!isset($fileMap[$fileId])) {
    http_response_code(404);
    exit('File not found');
}

$filePath = $fileMap[$fileId];

// Verify file exists and is within allowed directory
$realPath = realpath($filePath);
$allowedDir = realpath('uploads/');

if (!$realPath || strpos($realPath, $allowedDir) !== 0 || !file_exists($realPath)) {
    http_response_code(404);
    exit('File not found');
}

// Get file info
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $realPath);
finfo_close($finfo);

$fileSize = filesize($realPath);

// Support range requests for video streaming
$rangeHeader = $_SERVER['HTTP_RANGE'] ?? '';

if ($rangeHeader) {
    // Parse range header
    preg_match('/bytes=(\d+)-(\d+)?/', $rangeHeader, $matches);
    $start = intval($matches[1]);
    $end = isset($matches[2]) && $matches[2] !== '' ? intval($matches[2]) : $fileSize - 1;
    
    $length = $end - $start + 1;
    
    // Set headers for partial content
    http_response_code(206);
    header("Content-Type: $mimeType");
    header("Content-Length: $length");
    header("Content-Range: bytes $start-$end/$fileSize");
    header('Accept-Ranges: bytes');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    // Read and output the requested range
    $file = fopen($realPath, 'rb');
    fseek($file, $start);
    echo fread($file, $length);
    fclose($file);
} else {
    // Send entire file
    header("Content-Type: $mimeType");
    header("Content-Length: $fileSize");
    header('Accept-Ranges: bytes');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    readfile($realPath);
}

exit;
?>