<?php
session_start();
$protected_files_dir =  'videos/'; // نفس المسار المستخدم في index.php

if (!isset($_GET['token'])) {
    http_response_code(400);
    echo "Missing token";
    exit;
}

$token = $_GET['token'];

if (!isset($_SESSION['video_tokens'][$token])) {
    http_response_code(403);
    echo "Invalid or expired token";
    exit;
}

$info = &$_SESSION['video_tokens'][$token];

// تحقق من انتهاء الصلاحية
if ($info['expires_at'] < time()) {
    unset($_SESSION['video_tokens'][$token]);
    http_response_code(403);
    echo "Token expired";
    exit;
}

// خيار: اجعل التوكن single-use
$single_use = true;
if ($single_use && $info['used']) {
    http_response_code(403);
    echo "Token already used";
    exit;
}

// الملف الحقيقي
$filename = $info['file'];
$fullpath = realpath($protected_files_dir . $filename);

// تحقق من وجود الملف ومن أنه داخل المجلد المقصود (حماية من path traversal)
if (!$fullpath || strpos($fullpath, realpath($protected_files_dir)) !== 0 || !is_file($fullpath)) {
    http_response_code(404);
    echo "File not found";
    exit;
}

// علم أننا سنستخدمه
$info['used'] = true;

// إرسال الملف كمحتوى خام (سنرسل رؤوس مناسبة)
$filesize = filesize($fullpath);
$mime = mime_content_type($fullpath) ?: 'application/octet-stream';

header('Content-Type: ' . $mime);
header('Content-Length: ' . $filesize);
header('Content-Disposition: inline; filename="' . basename($filename) . '"');
// امنع التخزين المؤقت على الكاش للسلامة
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

// الآن نقرأ الملف ونرسله
// ملاحظة: هذه الطريقة تقرأ الملف كاملاً — جيدة للملفات المتوسطة.
// إذا أردت دعم seek/range للـ video (حتى لا تُحمّل كامل الملف قبل التشغيل)، يلزم دعم Range headers.
// لكن بما أننا نستخدم fetch->blob (تحميل كامل الملف) هذا يكفي.
$fp = fopen($fullpath, 'rb');
if ($fp === false) {
    http_response_code(500);
    echo "Cannot open file";
    exit;
}
while (!feof($fp)) {
    echo fread($fp, 8192);
    flush();
}
fclose($fp);
exit;
