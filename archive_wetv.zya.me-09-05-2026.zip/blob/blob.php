<?php
session_start();

// المسار إلى مجلد الفيديو داخل blob
$protected_files_dir = __DIR__ . '/videos/';
$real_filename = 'video.mp4';

function generate_token($len = 32) {
    return bin2hex(random_bytes($len / 2));
}

$token = generate_token();
$_SESSION['video_tokens'][$token] = [
    'file' => $real_filename,
    'expires_at' => time() + 300, // صالح 5 دقائق
    'used' => false
];
?>
<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>فيديو محمي باستخدام Blob</title>
<style>
body{background:#f6f6f6;font-family:sans-serif;text-align:center;padding:40px}
video{width:90%;max-width:700px;background:#000;border-radius:8px}
</style>
</head>
<body>
<h2>تشغيل فيديو برابط Blob تلقائياً</h2>
<video id="video" controls autoplay muted></video>
<script>
const token = "<?php echo $token; ?>";
const videoEl = document.getElementById("video");
let blobUrl = null;

async function playVideo() {
  try {
    const res = await fetch("video.php?token=" + token);
    if (!res.ok) throw new Error("فشل التحميل: " + res.status);
    const blob = await res.blob();
    blobUrl = URL.createObjectURL(blob);
    videoEl.src = blobUrl;
    await videoEl.play().catch(()=>{console.log("Autoplay قد يُمنع في المتصفح");});
  } catch(e) {
    console.error(e);
    alert("حدث خطأ أثناء تشغيل الفيديو: " + e.message);
  }
}

// تشغيل الفيديو فور تحميل الصفحة
window.addEventListener('load', playVideo);

// إلغاء blob URL عند مغادرة الصفحة
window.addEventListener('beforeunload', () => {
  if(blobUrl) URL.revokeObjectURL(blobUrl);
});
</script>
</body>
</html>
