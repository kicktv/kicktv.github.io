<?php
session_start();

// اسم الملف الحقيقي على السيرفر (وضعه خارج webroot)
$protected_files_dir = 'videos/'; // مثال: مجلد محمي خارج public
$real_filename = 'video.mp4'; // مثال؛ استبدل بالاسم الفعلي

// مولد رمز مؤقت (short-lived)
function generate_token($len = 32) {
    return bin2hex(random_bytes($len/2));
}

// أنشئ توكن جديد وخزن معلوماته في الجلسة مع وقت انتهاء
$token = generate_token(32);
$expire_seconds = 60 * 5; // صالح 5 دقائق فقط
$_SESSION['video_tokens'][$token] = [
    'file' => $real_filename,
    'expires_at' => time() + $expire_seconds,
    'used' => false
];
?>
<!doctype html>
<html lang="ar">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>تشغيل فيديو مخفي الرابط</title>
<style>
  body{font-family:sans-serif;background:#f6f6f6;padding:20px}
  .player{max-width:800px;margin:0 auto;background:#fff;padding:12px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,.08)}
  video{width:100%;height:auto;background:#000}
  button{margin-top:8px;padding:8px 12px;border:none;background:#007bff;color:#fff;border-radius:6px;cursor:pointer}
</style>
</head>
<body>
<div class="player">
  <h3>فيديو محمي (يُستخدم blob URL)</h3>
  <video id="video" controls></video>
  <div>
    <button id="loadBtn">تحميل و تشغيل (باستخدام fetch → blob)</button>
    <button id="revokeBtn">إلغاء الـ blob URL</button>
  </div>
  <small>ملاحظة: التوكن صالح لـ <?php echo ($expire_seconds/60); ?> دقائق.</small>
</div>

<script>
const token = "<?php echo $token; ?>"; // حقن التوكن الذي ولّدته في السيرفر
const loadBtn = document.getElementById('loadBtn');
const revokeBtn = document.getElementById('revokeBtn');
const videoEl = document.getElementById('video');
let blobUrl = null;

loadBtn.addEventListener('click', async () => {
  try {
    loadBtn.disabled = true;
    loadBtn.textContent = 'جاري التحميل...';
    // نطلب الملف كـ blob من endpoint يحوي التوكن
    const res = await fetch(`video.php?token=${encodeURIComponent(token)}`, {
      method: 'GET',
      credentials: 'same-origin'
    });
    if (!res.ok) throw new Error('فشل الحصول على الملف: ' + res.status);
    const blob = await res.blob();
    // أنشئ رابط blob مخفي عن الروابط الحقيقية
    if (blobUrl) URL.revokeObjectURL(blobUrl);
    blobUrl = URL.createObjectURL(blob);
    videoEl.src = blobUrl;
    videoEl.play().catch(()=>{/* التشغيل التلقائي قد يُمنع */});
    loadBtn.textContent = 'تم التحميل';
  } catch (err) {
    alert(err.message);
    console.error(err);
    loadBtn.textContent = 'تحميل و تشغيل';
  } finally {
    loadBtn.disabled = false;
  }
});

// إلغاء رابط الـ blob لتحرير الذاكرة
revokeBtn.addEventListener('click', () => {
  if (blobUrl) {
    URL.revokeObjectURL(blobUrl);
    blobUrl = null;
    videoEl.removeAttribute('src');
    videoEl.load();
    alert('تم إلغاء blob URL');
  }
});

// إلغاء عند مغادرة الصفحة
window.addEventListener('beforeunload', () => {
  if (blobUrl) URL.revokeObjectURL(blobUrl);
});
</script>
</body>
</html>
