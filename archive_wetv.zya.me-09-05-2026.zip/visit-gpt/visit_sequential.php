<?php
// visit_sequential.php
// Usage: php visit_sequential.php https://example.com 50 50
// WARNING: Only run this against servers you own or have permission to test.

if ($argc < 4) {
    echo "Usage: php {$argv[0]} <url> <total_visits> <rate_per_minute>\n";
    exit(1);
}

$url = $argv[1];
$total = (int)$argv[2];
$rate_per_min = (int)$argv[3];

if ($total <= 0 || $rate_per_min <= 0) {
    echo "total_visits and rate_per_minute must be > 0\n";
    exit(1);
}

$ms_between = round(60000 / $rate_per_min); // milliseconds between hits
echo "Target: $url\nTotal visits: $total\nRate: {$rate_per_min}/min (~{$ms_between} ms between)\n\n";

$userAgents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X)',
    'Mozilla/5.0 (Linux; Android 11; SM-G991B)',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)'
];

$success = 0;
$fail = 0;
$start = microtime(true);

for ($i = 1; $i <= $total; $i++) {
    $ch = curl_init();
    $ua = $userAgents[array_rand($userAgents)];
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => $ua,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_HEADER => false,
    ]);

    $res = curl_exec($ch);
    $err = curl_error($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $t = date('H:i:s');
    if ($res !== false && $http_code >= 200 && $http_code < 400) {
        $success++;
        echo "[$t] #$i OK (HTTP $http_code) — UA: $ua\n";
    } else {
        $fail++;
        echo "[$t] #$i FAIL (HTTP $http_code) — err: " . ($err ?: 'unknown') . "\n";
    }

    // sleep between hits (in microseconds)
    if ($i < $total) {
        usleep($ms_between * 1000);
    }
}

$elapsed = microtime(true) - $start;
echo "\nDone. Success: $success  Fail: $fail  Elapsed: " . round($elapsed,2) . "s\n";
