<!-- 
https://claude.ai/chat/9d7fc4c0-3e0c-4ea0-b742-a3a8c0c8fabd
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Visit Simulator</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            padding: 40px;
            max-width: 800px;
            width: 100%;
            backdrop-filter: blur(10px);
        }

        h1 {
            color: #667eea;
            text-align: center;
            margin-bottom: 10px;
            font-size: 2.5em;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
            font-size: 0.9em;
        }

        .input-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 0.95em;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: white;
        }

        input[type="text"]:focus,
        input[type="number"]:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .controls {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 25px;
        }

        button {
            padding: 15px 30px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .btn-start {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-start:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }

        .btn-start:disabled {
            background: #ccc;
            cursor: not-allowed;
            transform: none;
        }

        .btn-stop {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
        }

        .btn-stop:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(245, 87, 108, 0.4);
        }

        .stats {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            border-radius: 15px;
            padding: 25px;
            margin-top: 25px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
        }

        .stat-item {
            text-align: center;
            padding: 15px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .stat-value {
            font-size: 2em;
            font-weight: bold;
            color: #667eea;
            display: block;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #666;
            font-size: 0.85em;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .log {
            background: #1e1e1e;
            border-radius: 10px;
            padding: 20px;
            margin-top: 25px;
            max-height: 300px;
            overflow-y: auto;
            font-family: 'Courier New', monospace;
            font-size: 0.85em;
        }

        .log-entry {
            color: #4af;
            margin-bottom: 8px;
            padding: 5px;
            border-left: 3px solid #667eea;
            padding-left: 10px;
        }

        .log-entry.success {
            color: #4caf50;
            border-left-color: #4caf50;
        }

        .log-entry.error {
            color: #f44336;
            border-left-color: #f44336;
        }

        .status {
            text-align: center;
            padding: 15px;
            border-radius: 10px;
            margin-top: 20px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .status.idle {
            background: #e3f2fd;
            color: #1976d2;
        }

        .status.running {
            background: #c8e6c9;
            color: #388e3c;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }

        @media (max-width: 600px) {
            .container {
                padding: 25px;
            }

            h1 {
                font-size: 1.8em;
            }

            .controls {
                grid-template-columns: 1fr;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }
        }

        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #2a2a2a;
            border-radius: 5px;
        }

        ::-webkit-scrollbar-thumb {
            background: #667eea;
            border-radius: 5px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #764ba2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🌐 Web Visit Simulator</h1>
        <p class="subtitle">Simulate website visits for testing purposes</p>

        <div class="input-group">
            <label for="url">Target URL</label>
            <input type="text" id="url" placeholder="https://example.com" value="https://example.com">
        </div>

        <div class="input-group">
            <label for="visitsPerMinute">Visits Per Minute</label>
            <input type="number" id="visitsPerMinute" min="1" max="1000" value="50">
        </div>

        <div class="controls">
            <button class="btn-start" id="startBtn" onclick="startSimulation()">Start Simulation</button>
            <button class="btn-stop" id="stopBtn" onclick="stopSimulation()" disabled>Stop Simulation</button>
        </div>

        <div class="status idle" id="status">Status: Idle</div>

        <div class="stats">
            <div class="stats-grid">
                <div class="stat-item">
                    <span class="stat-value" id="totalVisits">0</span>
                    <span class="stat-label">Total Visits</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value" id="successCount">0</span>
                    <span class="stat-label">Successful</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value" id="currentRate">0</span>
                    <span class="stat-label">Rate (per min)</span>
                </div>
                <div class="stat-item">
                    <span class="stat-value" id="elapsed">00:00</span>
                    <span class="stat-label">Elapsed Time</span>
                </div>
            </div>
        </div>

        <div class="log" id="log"></div>
    </div>

    <script>
        let isRunning = false;
        let intervalId = null;
        let totalVisits = 0;
        let successCount = 0;
        let startTime = null;
        let elapsedTimer = null;

        function addLog(message, type = 'info') {
            const log = document.getElementById('log');
            const entry = document.createElement('div');
            entry.className = `log-entry ${type}`;
            const timestamp = new Date().toLocaleTimeString();
            entry.textContent = `[${timestamp}] ${message}`;
            log.insertBefore(entry, log.firstChild);
            
            // Keep only last 50 entries
            while (log.children.length > 50) {
                log.removeChild(log.lastChild);
            }
        }

        function updateStats() {
            document.getElementById('totalVisits').textContent = totalVisits;
            document.getElementById('successCount').textContent = successCount;
        }

        function updateElapsedTime() {
            if (startTime) {
                const elapsed = Math.floor((Date.now() - startTime) / 1000);
                const minutes = Math.floor(elapsed / 60).toString().padStart(2, '0');
                const seconds = (elapsed % 60).toString().padStart(2, '0');
                document.getElementById('elapsed').textContent = `${minutes}:${seconds}`;
            }
        }

        function simulateVisit(url) {
            // Simulate a visit - in reality, this would make an actual request
            // For demo purposes, we're just simulating the action
            totalVisits++;
            
            // Simulate 95% success rate
            const success = Math.random() < 0.95;
            
            if (success) {
                successCount++;
                addLog(`Visit #${totalVisits} to ${url} - Success`, 'success');
            } else {
                addLog(`Visit #${totalVisits} to ${url} - Failed`, 'error');
            }
            
            updateStats();
        }

        function startSimulation() {
            const url = document.getElementById('url').value;
            const visitsPerMinute = parseInt(document.getElementById('visitsPerMinute').value);

            if (!url) {
                addLog('Please enter a valid URL', 'error');
                return;
            }

            if (visitsPerMinute < 1 || visitsPerMinute > 1000) {
                addLog('Visits per minute must be between 1 and 1000', 'error');
                return;
            }

            isRunning = true;
            startTime = Date.now();
            totalVisits = 0;
            successCount = 0;

            document.getElementById('startBtn').disabled = true;
            document.getElementById('stopBtn').disabled = false;
            document.getElementById('status').className = 'status running';
            document.getElementById('status').textContent = 'Status: Running';
            document.getElementById('currentRate').textContent = visitsPerMinute;

            addLog(`Starting simulation: ${visitsPerMinute} visits/minute to ${url}`, 'success');

            // Calculate interval in milliseconds
            const interval = (60 * 1000) / visitsPerMinute;

            intervalId = setInterval(() => {
                simulateVisit(url);
            }, interval);

            elapsedTimer = setInterval(updateElapsedTime, 1000);
        }

        function stopSimulation() {
            isRunning = false;
            
            if (intervalId) {
                clearInterval(intervalId);
                intervalId = null;
            }

            if (elapsedTimer) {
                clearInterval(elapsedTimer);
                elapsedTimer = null;
            }

            document.getElementById('startBtn').disabled = false;
            document.getElementById('stopBtn').disabled = true;
            document.getElementById('status').className = 'status idle';
            document.getElementById('status').textContent = 'Status: Stopped';
            document.getElementById('currentRate').textContent = '0';

            addLog('Simulation stopped', 'error');
        }

        // Initialize
        addLog('Web Visit Simulator initialized', 'info');
    </script>
</body>
</html>