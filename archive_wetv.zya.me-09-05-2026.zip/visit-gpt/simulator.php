<?php
// Source:https://chatgpt.com/c/68e7a4cc-3240-8329-953d-985701d312bd
// simulator.php — safe local simulation (does not call external URLs)
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Visit Simulator — Demo</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
  :root{--bg:#0f1724;--card:#0b1220;--accent:#06b6d4;--muted:#94a3b8;color-scheme:dark}
  *{box-sizing:border-box;font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,"Helvetica Neue",Arial}
  body{margin:0;background:linear-gradient(180deg,#071024 0%,#081024 100%);color:#e6eef7;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
  .card{width:100%;max-width:980px;background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));border-radius:12px;padding:20px;box-shadow:0 6px 24px rgba(3,7,18,0.6);border:1px solid rgba(255,255,255,0.03)}
  .row{display:flex;gap:12px;flex-wrap:wrap}
  .col{flex:1 1 320px}
  h1{margin:0 0 8px;font-size:20px}
  label{display:block;font-size:13px;color:var(--muted);margin-bottom:6px}
  input[type="text"],select{width:100%;padding:10px;border-radius:8px;border:1px solid rgba(255,255,255,0.04);background:#071226;color:inherit}
  button{background:var(--accent);border:0;padding:10px 14px;border-radius:8px;color:#022;cursor:pointer;font-weight:600}
  .stats{display:flex;gap:12px;flex-wrap:wrap;margin-top:12px}
  .stat{background:rgba(255,255,255,0.02);padding:12px;border-radius:10px;flex:1;min-width:140px;text-align:center}
  .log{margin-top:12px;background:#031023;padding:12px;border-radius:8px;max-height:260px;overflow:auto;font-size:13px;color:var(--muted)}
  .progress{height:10px;background:rgba(255,255,255,0.03);border-radius:6px;overflow:hidden}
  .progress > b{display:block;height:100%;background:linear-gradient(90deg,var(--accent),#8b5cf6);width:0%}
  footer{margin-top:12px;color:var(--muted);font-size:13px}
  @media (max-width:640px){.row{flex-direction:column}}
</style>
</head>
<body>
  <div class="card" role="main" aria-label="Visit Simulator">
    <div class="row">
      <div class="col">
        <h1>Visit Simulator — Safe Demo</h1>
        <p style="margin:0;color:var(--muted)">This simulates visitor activity locally — it does not send requests to external sites.</p>
        <div style="margin-top:12px">
          <label for="url">URL (for display only)</label>
          <input id="url" type="text" placeholder="https://example.com/page" value="https://example.com/">
        </div>
        <div style="display:flex;gap:8px;margin-top:12px">
          <div style="flex:1">
            <label for="count">Visits</label>
            <input id="count" type="text" value="50">
          </div>
          <div style="flex:1">
            <label for="rate">Rate (visits/min)</label>
            <select id="rate">
              <option>10</option><option selected>50</option><option>100</option><option>200</option>
            </select>
          </div>
        </div>
        <div style="display:flex;gap:8px;margin-top:12px">
          <button id="start">Start Simulation</button>
          <button id="stop" style="background:#334155">Stop</button>
        </div>

        <div class="stats" style="margin-top:14px">
          <div class="stat">
            <div style="font-size:20px" id="done">0</div>
            <div style="color:var(--muted);margin-top:6px">Completed</div>
          </div>
          <div class="stat">
            <div style="font-size:20px" id="remaining">0</div>
            <div style="color:var(--muted);margin-top:6px">Remaining</div>
          </div>
          <div class="stat">
            <div style="font-size:20px" id="avg">0</div>
            <div style="color:var(--muted);margin-top:6px">Avg. Interval (s)</div>
          </div>
        </div>

        <div style="margin-top:12px">
          <label>Progress</label>
          <div class="progress" aria-hidden="true"><b id="bar"></b></div>
        </div>
      </div>

      <div class="col" style="flex:0 0 340px">
        <h1 style="font-size:16px;margin-bottom:8px">Activity Log</h1>
        <div class="log" id="log" aria-live="polite"></div>
        <footer>Demo only — no network requests are made.</footer>
      </div>
    </div>
  </div>

<script>
  const startBtn = document.getElementById('start');
  const stopBtn = document.getElementById('stop');
  const logEl = document.getElementById('log');
  const doneEl = document.getElementById('done');
  const remEl = document.getElementById('remaining');
  const avgEl = document.getElementById('avg');
  const bar = document.getElementById('bar');

  let timer = null;
  let stats = {total:0, done:0, intervals:[]};

  function randChoice(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
  const userAgents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X)',
    'Mozilla/5.0 (Linux; Android 11; SM-G991B)',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)'
  ];
  const referrers = ['https://google.com','https://bing.com','https://twitter.com','https://facebook.com','direct'];

  function appendLog(text){
    const el = document.createElement('div');
    el.textContent = text;
    logEl.prepend(el);
    if (logEl.childElementCount > 200) logEl.removeChild(logEl.lastChild);
  }

  function startSimulation(){
    const total = parseInt(document.getElementById('count').value) || 0;
    const rate = parseInt(document.getElementById('rate').value) || 50; // per minute
    if (total <= 0) return alert('Set visits > 0');

    clearInterval(timer);
    stats = {total: total, done: 0, intervals: []};
    doneEl.textContent = '0';
    remEl.textContent = total;
    avgEl.textContent = '0';
    bar.style.width = '0%';
    logEl.textContent = '';

    // compute interval between visits (ms) to match rate per minute
    const msBetween = Math.round((60 * 1000) / rate);

    appendLog(`Simulation started — ${total} visits at ~${rate}/min (every ${msBetween}ms)`);

    let lastTime = performance.now();
    timer = setInterval(() => {
      if (stats.done >= stats.total){ stopSimulation(); return; }

      // simulate a visit (no network)
      const ua = randChoice(userAgents);
      const ref = randChoice(referrers);
      const t = new Date().toLocaleTimeString();
      stats.done++;
      stats.intervals.push((performance.now() - lastTime)/1000);
      lastTime = performance.now();

      appendLog(`${t} — simulated hit #${stats.done} — UA: ${ua} — Ref: ${ref}`);
      doneEl.textContent = stats.done;
      remEl.textContent = Math.max(0, stats.total - stats.done);
      const avg = (stats.intervals.reduce((a,b)=>a+b,0)/stats.intervals.length) || 0;
      avgEl.textContent = avg.toFixed(2);
      const pct = Math.round((stats.done / stats.total) * 100);
      bar.style.width = pct + '%';

      if (stats.done >= stats.total) stopSimulation();

    }, msBetween);
  }

  function stopSimulation(){
    clearInterval(timer);
    timer = null;
    appendLog('Simulation stopped.');
  }

  startBtn.addEventListener('click', startSimulation);
  stopBtn.addEventListener('click', stopSimulation);
</script>
</body>
</html>
