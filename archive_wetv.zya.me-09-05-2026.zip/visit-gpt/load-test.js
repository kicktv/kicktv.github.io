import http from 'k6/http';
import { sleep } from 'k6';

export let options = {
  scenarios: {
    constant_rate: {
      executor: 'constant-arrival-rate',
      rate: 50,            // 50 iterations per timeUnit
      timeUnit: '1m',      // time unit = 1 minute
      duration: '5m',      // total test duration (adjust as needed)
      preAllocatedVUs: 10, // VUs to pre-allocate
      maxVUs: 50,
    },
  },
  thresholds: {
    'http_req_duration': ['p(95)<2000'], // example: 95% of requests < 2000ms
  },
};

export default function () {
  const url = __ENV.TARGET_URL || 'https://wetv.zya.me/';
  // optional: set headers or randomize UA here
  http.get(url);
  // k6 will pace requests according to the scenario; sleep not required
}
