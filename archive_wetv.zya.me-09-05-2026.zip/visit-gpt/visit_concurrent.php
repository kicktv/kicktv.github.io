<?php
// visit_concurrent.php
// Usage: php visit_concurrent.php https://example.com 500 200 10
// WARNING: Only run this against servers you own or have permission to test.

if ($argc < 5) {
    echo "Usage: php {$argv[0]} <url> <total> <rate_per_min> <concurrency>\n";
    exit(1);
}

$url = $argv[1];
$total = (int)$argv[2];
$rate = (int)$argv[3];
$concurrency = max(1, (int)$argv[4]);

$ms_between = round(60000 / max(1, $rate)); // ms between starting new requests
echo "Target: $url\nTotal: $total  Rate: $rate/min (~{$ms_between}ms start interval)  Concurrency: $concurrency\n\n";

$userAgents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X)',
    'Mozilla/5.0 (Linux; Android 11; SM-G991B)',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)'
];

$mh = curl_multi_init();
$handles = [];
$inflight = 0;
$sent = 0;
$success = 0;
$fail = 0;
$start = microtime(true);

function start_new_request(&$mh, &$handles, $url, $userAgents, &$sent) {
    $ch = curl_init();
    $ua = $userAgents[array_rand($userAgents)];
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => $ua,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_HEADER => false,
    ]);
    curl_multi_add_handle($mh, $ch);
    $handles[(int)$ch] = ['ch'=>$ch,'ua'=>$ua];
    $sent++;
    $t = date('H:i:s');
    echo "[$t] Started #$sent UA: $ua\n";
}

while (($sent < $total) || $inflight > 0) {
    // start requests up to concurrency and according to rate
    while ($inflight < $concurrency && $sent < $total) {
        start_new_request($mh, $handles, $url, $userAgents, $sent);
        $inflight++;
        // respect start interval
        usleep($ms_between * 1000);
    }

    // run the multi-handle
    do {
        $status = curl_multi_exec($mh, $active);
    } while ($status === CURLM_CALL_MULTI_PERFORM);

    // read finished handles
    while ($info = curl_multi_info_read($mh)) {
        $ch = $info['handle'];
        $key = (int)$ch;
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        $ua = $handles[$key]['ua'] ?? 'UA';
        $t = date('H:i:s');

        if ($info['result'] === CURLE_OK && $http_code >= 200 && $http_code < 400) {
            $success++;
            echo "[$t] DONE OK (HTTP $http_code) UA: $ua\n";
        } else {
            $fail++;
            echo "[$t] DONE FAIL (HTTP $http_code) err: " . ($err ?: 'unknown') . " UA: $ua\n";
        }

        curl_multi_remove_handle($mh, $ch);
        curl_close($ch);
        unset($handles[$key]);
        $inflight--;
    }

    // brief sleep to avoid tight loop
    if ($active) {
        curl_multi_select($mh, 0.5);
    } else {
        usleep(100000);
    }
}

curl_multi_close($mh);
$elapsed = microtime(true) - $start;
echo "\nFinished. Sent: $sent  Success: $success  Fail: $fail  Elapsed: " . round($elapsed,2) . "s\n";
