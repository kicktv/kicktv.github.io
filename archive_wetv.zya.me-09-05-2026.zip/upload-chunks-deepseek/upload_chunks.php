<?php
//https://chat.deepseek.com/a/chat/s/637c2ec2-8039-4d25-b9b2-16e07abf60bf
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Create uploads directory if it doesn't exist
if (!file_exists('uploads')) {
    mkdir('uploads', 0777, true);
}

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

try {
    // Check if this is a finalize request
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (isset($data['action']) && $data['action'] === 'finalize') {
        handleFinalize($data);
        exit;
    }

    // Handle chunk upload
    handleChunkUpload();

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

function handleChunkUpload() {
    // Validate required parameters
    if (!isset($_POST['chunkIndex']) || !isset($_POST['totalChunks']) || !isset($_POST['fileName'])) {
        throw new Exception('Missing required parameters');
    }

    $chunkIndex = (int)$_POST['chunkIndex'];
    $totalChunks = (int)$_POST['totalChunks'];
    $fileName = sanitizeFileName($_POST['fileName']);
    
    // Validate file name
    if (empty($fileName)) {
        throw new Exception('Invalid file name');
    }

    // Check if chunk was uploaded
    if (!isset($_FILES['chunk']) || $_FILES['chunk']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Chunk upload failed');
    }

    $tempDir = 'uploads/temp_' . md5($fileName);
    $chunkPath = $tempDir . '/' . $fileName . '.part' . $chunkIndex;

    // Create temp directory if it doesn't exist
    if (!file_exists($tempDir)) {
        mkdir($tempDir, 0777, true);
    }

    // Move uploaded chunk to temp directory
    if (!move_uploaded_file($_FILES['chunk']['tmp_name'], $chunkPath)) {
        throw new Exception('Failed to save chunk');
    }

    // Check if all chunks are uploaded
    $uploadedChunks = count(glob($tempDir . '/' . $fileName . '.part*'));
    
    echo json_encode([
        'success' => true,
        'chunkIndex' => $chunkIndex,
        'uploadedChunks' => $uploadedChunks,
        'totalChunks' => $totalChunks,
        'message' => 'Chunk uploaded successfully'
    ]);
}

function handleFinalize($data) {
    $fileName = sanitizeFileName($data['fileName']);
    $totalChunks = (int)$data['totalChunks'];
    
    if (empty($fileName)) {
        throw new Exception('Invalid file name');
    }

    $tempDir = 'uploads/temp_' . md5($fileName);
    $finalPath = 'uploads/' . $fileName;

    // Check if all chunks are present
    $uploadedChunks = count(glob($tempDir . '/' . $fileName . '.part*'));
    
    if ($uploadedChunks !== $totalChunks) {
        throw new Exception('Not all chunks have been uploaded. Expected: ' . $totalChunks . ', Found: ' . $uploadedChunks);
    }

    // Open final file for writing
    $finalFile = fopen($finalPath, 'wb');
    if (!$finalFile) {
        throw new Exception('Cannot create final file');
    }

    // Combine all chunks
    for ($i = 0; $i < $totalChunks; $i++) {
        $chunkPath = $tempDir . '/' . $fileName . '.part' . $i;
        
        if (!file_exists($chunkPath)) {
            fclose($finalFile);
            throw new Exception('Missing chunk: ' . $i);
        }

        $chunkContent = file_get_contents($chunkPath);
        fwrite($finalFile, $chunkContent);
        
        // Delete chunk after combining
        unlink($chunkPath);
    }

    fclose($finalFile);

    // Clean up temp directory
    if (is_dir($tempDir)) {
        rmdir($tempDir);
    }

    echo json_encode([
        'success' => true,
        'message' => 'File uploaded successfully',
        'filePath' => $finalPath,
        'fileName' => $fileName
    ]);
}

function sanitizeFileName($fileName) {
    // Remove path traversal characters and other potentially dangerous characters
    $fileName = basename($fileName);
    
    // Replace spaces and special characters
    $fileName = preg_replace('/[^a-zA-Z0-9\._-]/', '_', $fileName);
    
    // Limit file name length
    if (strlen($fileName) > 255) {
        $ext = pathinfo($fileName, PATHINFO_EXTENSION);
        $name = pathinfo($fileName, PATHINFO_FILENAME);
        $fileName = substr($name, 0, 255 - strlen($ext) - 1) . '.' . $ext;
    }
    
    return $fileName;
}

// Clean up old temp directories (older than 1 hour)
function cleanupOldTempFiles() {
    $tempDirs = glob('uploads/temp_*');
    $now = time();
    
    foreach ($tempDirs as $dir) {
        if (is_dir($dir) && ($now - filemtime($dir)) > 3600) {
            array_map('unlink', glob("$dir/*"));
            rmdir($dir);
        }
    }
}

// Run cleanup on every request (optional, can be moved to cron job)
cleanupOldTempFiles();
?>