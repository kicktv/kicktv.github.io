<?php
session_start();
require_once 'functions.php';
require_once 'auth.php';

// Check authentication
if (!isLoggedIn()) {
    header('Location: auth.php');
    exit;
}

// Set root directory (with security check)
$root = realpath('./files');
$current_dir = isset($_GET['dir']) ? realpath($root . '/' . $_GET['dir']) : $root;

// Security: Prevent directory traversal
if (strpos($current_dir, $root) !== 0) {
    $current_dir = $root;
}

// Handle actions
if (isset($_GET['action'])) {
    handleAction($current_dir, $root);
}

// Get directory contents
$contents = getDirectoryContents($current_dir);

// Calculate breadcrumbs
$breadcrumbs = getBreadcrumbs($current_dir, $root);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Manager</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <header>
        <h1>File Manager</h1>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            <a href="logout.php" class="logout">Logout</a>
        </div>
    </header>

    <div class="toolbar">
        <div class="breadcrumbs">
            <?php foreach ($breadcrumbs as $crumb): ?>
                <a href="?dir=<?php echo urlencode($crumb['path']); ?>"><?php echo htmlspecialchars($crumb['name']); ?></a>
                <?php if (!empty($crumb['separator'])): ?>
                    <span class="separator">/</span>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>

        <div class="actions">
            <button id="newFolderBtn"><i class="fas fa-folder-plus"></i> New Folder</button>
            <button id="uploadBtn"><i class="fas fa-upload"></i> Upload</button>
            <button id="refreshBtn"><i class="fas fa-sync-alt"></i> Refresh</button>
            <div class="dropdown">
                <button class="dropbtn">More <i class="fas fa-caret-down"></i></button>
                <div class="dropdown-content">
                    <a href="#" id="downloadSelected"><i class="fas fa-download"></i> Download Selected</a>
                    <a href="#" id="deleteSelected"><i class="fas fa-trash"></i> Delete Selected</a>
                    <a href="#" id="zipSelected"><i class="fas fa-file-archive"></i> Zip Selected</a>
                    <a href="#" id="chmodSelected"><i class="fas fa-lock"></i> Change Permissions</a>
                </div>
            </div>
        </div>
    </div>

    <div class="file-upload-container" id="uploadContainer">
        <div class="upload-area" id="dropArea">
            <i class="fas fa-cloud-upload-alt"></i>
            <p>Drag & drop files here or click to browse</p>
            <input type="file" id="fileInput" multiple style="display: none;">
        </div>
        <div class="upload-progress" id="uploadProgress">
            <div class="progress-bar" id="progressBar"></div>
            <div class="status" id="uploadStatus"></div>
        </div>
        <div class="upload-actions">
            <button id="startUpload">Start Upload</button>
            <button id="cancelUpload">Cancel</button>
        </div>
    </div>

    <div class="new-folder-dialog" id="newFolderDialog">
        <div class="dialog-content">
            <h3>Create New Folder</h3>
            <input type="text" id="folderName" placeholder="Folder name">
            <div class="dialog-actions">
                <button id="createFolder">Create</button>
                <button id="cancelFolder">Cancel</button>
            </div>
        </div>
    </div>

    <div class="file-container">
        <table>
            <thead>
                <tr>
                    <th><input type="checkbox" id="selectAll"></th>
                    <th>Name</th>
                    <th>Size</th>
                    <th>Type</th>
                    <th>Modified</th>
                    <th>Permissions</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($breadcrumbs) && count($breadcrumbs) > 1): ?>
                    <tr>
                        <td></td>
                        <td><a href="?dir=<?php echo urlencode(dirname($_GET['dir'] ?? '')); ?>"><i class="fas fa-level-up-alt"></i> Parent Directory</a></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                <?php endif; ?>

                <?php foreach ($contents as $item): ?>
                    <tr>
                        <td><input type="checkbox" class="file-checkbox" data-path="<?php echo htmlspecialchars($item['path']); ?>"></td>
                        <td>
                            <?php if ($item['type'] == 'dir'): ?>
                                <i class="fas fa-folder"></i>
                                <a href="?dir=<?php echo urlencode($item['path']); ?>"><?php echo htmlspecialchars($item['name']); ?></a>
                            <?php else: ?>
                                <i class="<?php echo getFileIcon($item['name']); ?>"></i>
                                <a href="#" class="file-link" data-path="<?php echo htmlspecialchars($item['path']); ?>"><?php echo htmlspecialchars($item['name']); ?></a>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $item['size']; ?></td>
                        <td><?php echo $item['type']; ?></td>
                        <td><?php echo $item['modified']; ?></td>
                        <td><?php echo $item['perms']; ?></td>
                        <td class="actions">
                            <div class="dropdown">
                                <button class="action-btn"><i class="fas fa-ellipsis-v"></i></button>
                                <div class="dropdown-content">
                                    <?php if ($item['type'] == 'dir'): ?>
                                        <a href="#" class="rename-action" data-path="<?php echo htmlspecialchars($item['path']); ?>" data-type="dir"><i class="fas fa-edit"></i> Rename</a>
                                        <a href="?action=download&path=<?php echo urlencode($item['path']); ?>"><i class="fas fa-download"></i> Download</a>
                                    <?php else: ?>
                                        <a href="#" class="edit-action" data-path="<?php echo htmlspecialchars($item['path']); ?>"><i class="fas fa-edit"></i> Edit</a>
                                        <a href="?action=download&path=<?php echo urlencode($item['path']); ?>"><i class="fas fa-download"></i> Download</a>
                                    <?php endif; ?>
                                    <a href="#" class="rename-action" data-path="<?php echo htmlspecialchars($item['path']); ?>" data-type="<?php echo $item['type']; ?>"><i class="fas fa-i-cursor"></i> Rename</a>
                                    <a href="#" class="chmod-action" data-path="<?php echo htmlspecialchars($item['path']); ?>"><i class="fas fa-lock"></i> Permissions</a>
                                    <a href="#" class="delete-action" data-path="<?php echo htmlspecialchars($item['path']); ?>"><i class="fas fa-trash"></i> Delete</a>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="status-bar">
        <div class="selected-count">0 items selected</div>
        <div class="storage-info">
            <?php echo getStorageInfo($root); ?>
        </div>
    </div>

    <!-- Modal Dialogs -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Edit File</h2>
            <textarea id="fileEditor" spellcheck="false"></textarea>
            <div class="modal-actions">
                <button id="saveFile">Save</button>
                <button id="cancelEdit">Cancel</button>
            </div>
        </div>
    </div>

    <div id="renameModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Rename</h2>
            <input type="text" id="newName" placeholder="New name">
            <div class="modal-actions">
                <button id="confirmRename">Rename</button>
                <button id="cancelRename">Cancel</button>
            </div>
        </div>
    </div>

    <div id="chmodModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Change Permissions</h2>
            <div class="permission-bits">
                <div class="permission-group">
                    <label>Owner</label>
                    <div class="checkboxes">
                        <label><input type="checkbox" class="perm-checkbox" data-bit="400"> Read</label>
                        <label><input type="checkbox" class="perm-checkbox" data-bit="200"> Write</label>
                        <label><input type="checkbox" class="perm-checkbox" data-bit="100"> Execute</label>
                    </div>
                </div>
                <div class="permission-group">
                    <label>Group</label>
                    <div class="checkboxes">
                        <label><input type="checkbox" class="perm-checkbox" data-bit="40"> Read</label>
                        <label><input type="checkbox" class="perm-checkbox" data-bit="20"> Write</label>
                        <label><input type="checkbox" class="perm-checkbox" data-bit="10"> Execute</label>
                    </div>
                </div>
                <div class="permission-group">
                    <label>Others</label>
                    <div class="checkboxes">
                        <label><input type="checkbox" class="perm-checkbox" data-bit="4"> Read</label>
                        <label><input type="checkbox" class="perm-checkbox" data-bit="2"> Write</label>
                        <label><input type="checkbox" class="perm-checkbox" data-bit="1"> Execute</label>
                    </div>
                </div>
            </div>
            <div class="numeric-perm">
                <label>Numeric value:</label>
                <input type="text" id="numericPerm" value="644" maxlength="3">
            </div>
            <div class="modal-actions">
                <button id="confirmChmod">Apply</button>
                <button id="cancelChmod">Cancel</button>
            </div>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
</body>
</html>