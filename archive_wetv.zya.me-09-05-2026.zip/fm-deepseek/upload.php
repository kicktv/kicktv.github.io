<?php
session_start();
require_once 'functions.php';

if (!isLoggedIn()) {
    header('HTTP/1.1 403 Forbidden');
    exit;
}

$target_dir = isset($_POST['directory']) ? realpath('./files/' . $_POST['directory']) : realpath('./files');

// Security check
if (strpos($target_dir, realpath('./files')) !== 0) {
    header('HTTP/1.1 403 Forbidden');
    exit;
}

if (isset($_FILES['files'])) {
    $results = handleUpload($target_dir);
    header('Content-Type: application/json');
    echo json_encode($results);
} elseif (isset($_POST['url'])) {
    $url = filter_var($_POST['url'], FILTER_VALIDATE_URL);
    if ($url) {
        $result = downloadFromUrl($url, $target_dir);
        header('Content-Type: application/json');
        echo json_encode($result);
    } else {
        header('HTTP/1.1 400 Bad Request');
        echo json_encode(['error' => 'Invalid URL']);
    }
} else {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => 'No files or URL provided']);
}
?>