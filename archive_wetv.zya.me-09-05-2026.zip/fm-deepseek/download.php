<?php
session_start();
require_once 'functions.php';

if (!isLoggedIn()) {
    header('HTTP/1.1 403 Forbidden');
    exit;
}

$path = isset($_GET['path']) ? realpath('./files/' . $_GET['path']) : '';

// Security check
if (strpos($path, realpath('./files')) !== 0) {
    header('HTTP/1.1 403 Forbidden');
    exit;
}

if (file_exists($path)) {
    downloadItem($path);
} else {
    header('HTTP/1.1 404 Not Found');
    echo 'File not found';
}
?>