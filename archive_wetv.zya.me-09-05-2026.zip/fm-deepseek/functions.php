<?php
// Security settings
$allowed_actions = ['delete', 'rename', 'chmod', 'download', 'create_folder', 'edit', 'upload'];
$restricted_files = ['.htaccess', '.htpasswd', 'web.config'];
$allowed_edit_types = ['txt', 'php', 'html', 'css', 'js', 'json', 'xml', 'md', 'log'];

// Authentication check
function isLoggedIn() {
    return isset($_SESSION['authenticated']) && $_SESSION['authenticated'] === true;
}

// Get directory contents
function getDirectoryContents($path) {
    $contents = [];
    
    if (!is_dir($path)) {
        return $contents;
    }
    
    $items = scandir($path);
    
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') continue;
        
        $fullPath = $path . DIRECTORY_SEPARATOR . $item;
        $contents[] = getFileInfo($fullPath, $item);
    }
    
    return $contents;
}

// Get file/folder information
function getFileInfo($path, $name) {
    $info = [
        'name' => $name,
        'path' => $name,
        'type' => is_dir($path) ? 'dir' : 'file',
        'size' => formatSizeUnits(is_dir($path) ? getDirectorySize($path) : filesize($path)),
        'modified' => date("Y-m-d H:i:s", filemtime($path)),
        'perms' => getPermissionString($path),
        'readable' => is_readable($path),
        'writable' => is_writable($path)
    ];
    
    return $info;
}

// Calculate directory size recursively
function getDirectorySize($path) {
    $totalSize = 0;
    $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path));
    
    foreach ($files as $file) {
        if ($file->isFile()) {
            $totalSize += $file->getSize();
        }
    }
    
    return $totalSize;
}

// Format file size
function formatSizeUnits($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } elseif ($bytes > 1) {
        return $bytes . ' bytes';
    } elseif ($bytes == 1) {
        return '1 byte';
    } else {
        return '0 bytes';
    }
}

// Get permission string (e.g. drwxr-xr-x)
function getPermissionString($path) {
    $perms = fileperms($path);
    
    $info = '';
    $info .= (($perms & 0x4000) ? 'd' : '-');
    $info .= (($perms & 0x0100) ? 'r' : '-');
    $info .= (($perms & 0x0080) ? 'w' : '-');
    $info .= (($perms & 0x0040) ? 'x' : '-');
    $info .= (($perms & 0x0020) ? 'r' : '-');
    $info .= (($perms & 0x0010) ? 'w' : '-');
    $info .= (($perms & 0x0008) ? 'x' : '-');
    $info .= (($perms & 0x0004) ? 'r' : '-');
    $info .= (($perms & 0x0002) ? 'w' : '-');
    $info .= (($perms & 0x0001) ? 'x' : '-');
    
    return $info;
}

// Get numeric permissions (e.g. 755)
function getNumericPermissions($path) {
    return substr(sprintf('%o', fileperms($path)), -3);
}

// Get appropriate file icon
function getFileIcon($filename) {
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    $icons = [
        'pdf' => 'fas fa-file-pdf',
        'doc' => 'fas fa-file-word',
        'docx' => 'fas fa-file-word',
        'xls' => 'fas fa-file-excel',
        'xlsx' => 'fas fa-file-excel',
        'ppt' => 'fas fa-file-powerpoint',
        'pptx' => 'fas fa-file-powerpoint',
        'jpg' => 'fas fa-file-image',
        'jpeg' => 'fas fa-file-image',
        'png' => 'fas fa-file-image',
        'gif' => 'fas fa-file-image',
        'zip' => 'fas fa-file-archive',
        'rar' => 'fas fa-file-archive',
        'tar' => 'fas fa-file-archive',
        'gz' => 'fas fa-file-archive',
        'php' => 'fas fa-file-code',
        'html' => 'fas fa-file-code',
        'css' => 'fas fa-file-code',
        'js' => 'fas fa-file-code',
        'json' => 'fas fa-file-code',
        'txt' => 'fas fa-file-alt',
        'md' => 'fas fa-file-alt',
        'csv' => 'fas fa-file-csv',
    ];
    
    return $icons[$extension] ?? 'fas fa-file';
}

// Get breadcrumbs
function getBreadcrumbs($current_dir, $root) {
    $breadcrumbs = [];
    $relative_path = str_replace($root, '', $current_dir);
    $parts = array_filter(explode(DIRECTORY_SEPARATOR, $relative_path));
    
    $breadcrumbs[] = [
        'name' => 'Home',
        'path' => '',
        'separator' => !empty($parts)
    ];
    
    $current_path = '';
    foreach ($parts as $i => $part) {
        $current_path .= DIRECTORY_SEPARATOR . $part;
        $breadcrumbs[] = [
            'name' => $part,
            'path' => ltrim($current_path, DIRECTORY_SEPARATOR),
            'separator' => $i < count($parts) - 1
        ];
    }
    
    return $breadcrumbs;
}

// Get storage information
function getStorageInfo($path) {
    $total = disk_total_space($path);
    $free = disk_free_space($path);
    $used = $total - $free;
    
    $percent_used = ($used / $total) * 100;
    
    return sprintf(
        '%.1f GB used of %.1f GB (%.1f%% free)',
        $used / (1024 * 1024 * 1024),
        $total / (1024 * 1024 * 1024),
        100 - $percent_used
    );
}

// Handle file actions
function handleAction($current_dir, $root) {
    global $allowed_actions, $restricted_files, $allowed_edit_types;
    
    $action = $_GET['action'] ?? '';
    $path = $_GET['path'] ?? '';
    $full_path = $current_dir . DIRECTORY_SEPARATOR . $path;
    
    // Security checks
    if (!in_array($action, $allowed_actions)) {
        return ['error' => 'Action not allowed'];
    }
    
    if (in_array(basename($full_path), $restricted_files)) {
        return ['error' => 'File access restricted'];
    }
    
    if (strpos(realpath($full_path), $root) !== 0) {
        return ['error' => 'Access denied'];
    }
    
    switch ($action) {
        case 'delete':
            return deleteItem($full_path);
        case 'rename':
            $new_name = $_POST['new_name'] ?? '';
            return renameItem($full_path, $new_name);
        case 'chmod':
            $mode = $_POST['mode'] ?? '';
            return changePermissions($full_path, $mode);
        case 'download':
            return downloadItem($full_path);
        case 'create_folder':
            $folder_name = $_POST['folder_name'] ?? '';
            return createFolder($current_dir, $folder_name);
        case 'edit':
            return editFile($full_path);
        case 'upload':
            return handleUpload($current_dir);
    }
}

// Delete file or folder
function deleteItem($path) {
    if (is_dir($path)) {
        // Recursive directory deletion
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($path, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        
        foreach ($files as $file) {
            if ($file->isDir()) {
                rmdir($file->getRealPath());
            } else {
                unlink($file->getRealPath());
            }
        }
        
        return rmdir($path);
    } else {
        return unlink($path);
    }
}

// Rename file or folder
function renameItem($old_path, $new_name) {
    $new_path = dirname($old_path) . DIRECTORY_SEPARATOR . $new_name;
    
    if (file_exists($new_path)) {
        return ['error' => 'A file or folder with that name already exists'];
    }
    
    return rename($old_path, $new_path);
}

// Change permissions
function changePermissions($path, $mode) {
    if (!is_numeric($mode) || strlen($mode) != 3) {
        return ['error' => 'Invalid permission mode'];
    }
    
    return chmod($path, octdec($mode));
}

// Download file or folder
function downloadItem($path) {
    if (is_dir($path)) {
        // Create zip archive
        $zip = new ZipArchive();
        $zip_name = basename($path) . '.zip';
        $zip_path = sys_get_temp_dir() . DIRECTORY_SEPARATOR . $zip_name;
        
        if ($zip->open($zip_path, ZipArchive::CREATE) !== TRUE) {
            return ['error' => 'Could not create archive'];
        }
        
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($path),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $file_path = $file->getRealPath();
                $relative_path = substr($file_path, strlen($path) + 1);
                $zip->addFile($file_path, $relative_path);
            }
        }
        
        $zip->close();
        
        // Send the zip file
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $zip_name . '"');
        header('Content-Length: ' . filesize($zip_path));
        readfile($zip_path);
        
        // Delete the temp file
        unlink($zip_path);
        exit;
    } else {
        // Send single file
        if (file_exists($path)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($path) . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($path));
            readfile($path);
            exit;
        }
    }
    
    return ['error' => 'File not found'];
}

// Create new folder
function createFolder($current_dir, $folder_name) {
    $folder_path = $current_dir . DIRECTORY_SEPARATOR . $folder_name;
    
    if (file_exists($folder_path)) {
        return ['error' => 'A folder with that name already exists'];
    }
    
    return mkdir($folder_path, 0755);
}

// Edit file
function editFile($path) {
    global $allowed_edit_types;
    
    $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    
    if (!in_array($extension, $allowed_edit_types)) {
        return ['error' => 'File type not editable'];
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $content = $_POST['content'] ?? '';
        return file_put_contents($path, $content) !== false;
    } else {
        return ['content' => file_get_contents($path)];
    }
}

// Handle file upload
function handleUpload($target_dir) {
    if (!isset($_FILES['files'])) {
        return ['error' => 'No files uploaded'];
    }
    
    $results = [];
    
    foreach ($_FILES['files']['name'] as $i => $name) {
        $target_file = $target_dir . DIRECTORY_SEPARATOR . basename($name);
        
        if (file_exists($target_file)) {
            $results[] = ['file' => $name, 'error' => 'File already exists'];
            continue;
        }
        
        if (move_uploaded_file($_FILES['files']['tmp_name'][$i], $target_file)) {
            $results[] = ['file' => $name, 'success' => true];
        } else {
            $results[] = ['file' => $name, 'error' => 'Upload failed'];
        }
    }
    
    return $results;
}

// Remote URL download
function downloadFromUrl($url, $target_dir) {
    $file_name = basename($url);
    $target_path = $target_dir . DIRECTORY_SEPARATOR . $file_name;
    
    $file_data = file_get_contents($url);
    
    if ($file_data === false) {
        return ['error' => 'Could not download file'];
    }
    
    $bytes = file_put_contents($target_path, $file_data);
    
    return $bytes !== false ? ['success' => true, 'bytes' => $bytes] : ['error' => 'Could not save file'];
}
?>