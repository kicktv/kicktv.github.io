document.addEventListener('DOMContentLoaded', function() {
    // UI Elements
    const uploadBtn = document.getElementById('uploadBtn');
    const uploadContainer = document.getElementById('uploadContainer');
    const dropArea = document.getElementById('dropArea');
    const fileInput = document.getElementById('fileInput');
    const startUpload = document.getElementById('startUpload');
    const cancelUpload = document.getElementById('cancelUpload');
    const progressBar = document.getElementById('progressBar');
    const uploadStatus = document.getElementById('uploadStatus');
    const newFolderBtn = document.getElementById('newFolderBtn');
    const newFolderDialog = document.getElementById('newFolderDialog');
    const createFolder = document.getElementById('createFolder');
    const cancelFolder = document.getElementById('cancelFolder');
    const folderName = document.getElementById('folderName');
    const refreshBtn = document.getElementById('refreshBtn');
    const selectAll = document.getElementById('selectAll');
    const fileCheckboxes = document.querySelectorAll('.file-checkbox');
    const downloadSelected = document.getElementById('downloadSelected');
    const deleteSelected = document.getElementById('deleteSelected');
    const zipSelected = document.getElementById('zipSelected');
    const chmodSelected = document.getElementById('chmodSelected');
    const editModal = document.getElementById('editModal');
    const renameModal = document.getElementById('renameModal');
    const chmodModal = document.getElementById('chmodModal');
    const fileEditor = document.getElementById('fileEditor');
    const saveFile = document.getElementById('saveFile');
    const cancelEdit = document.getElementById('cancelEdit');
    const newName = document.getElementById('newName');
    const confirmRename = document.getElementById('confirmRename');
    const cancelRename = document.getElementById('cancelRename');
    const confirmChmod = document.getElementById('confirmChmod');
    const cancelChmod = document.getElementById('cancelChmod');
    const permCheckboxes = document.querySelectorAll('.perm-checkbox');
    const numericPerm = document.getElementById('numericPerm');
    
    // Current directory
    const currentDir = new URLSearchParams(window.location.search).get('dir') || '';
    let selectedItems = [];
    let currentFile = '';
    
    // Toggle upload container
    uploadBtn.addEventListener('click', function() {
        uploadContainer.style.display = uploadContainer.style.display === 'block' ? 'none' : 'block';
    });
    
    // Drag and drop upload
    dropArea.addEventListener('click', function() {
        fileInput.click();
    });
    
    fileInput.addEventListener('change', function() {
        updateFileList(this.files);
    });
    
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
        dropArea.addEventListener(eventName, highlight, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, unhighlight, false);
    });
    
    function highlight() {
        dropArea.classList.add('highlight');
    }
    
    function unhighlight() {
        dropArea.classList.remove('highlight');
    }
    
    dropArea.addEventListener('drop', function(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        updateFileList(files);
    });
    
    function updateFileList(files) {
        if (files.length > 0) {
            uploadStatus.textContent = `${files.length} file(s) selected`;
            progressBar.style.width = '0%';
            uploadProgress.style.display = 'block';
            startUpload.disabled = false;
        }
    }
    
    // Start upload
    startUpload.addEventListener('click', function() {
        if (fileInput.files.length === 0) return;
        
        const formData = new FormData();
        for (let i = 0; i < fileInput.files.length; i++) {
            formData.append('files[]', fileInput.files[i]);
        }
        formData.append('directory', currentDir);
        
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'upload.php', true);
        
        xhr.upload.onprogress = function(e) {
            if (e.lengthComputable) {
                const percentComplete = (e.loaded / e.total) * 100;
                progressBar.style.width = percentComplete + '%';
                uploadStatus.textContent = `Uploading... ${Math.round(percentComplete)}%`;
            }
        };
        
        xhr.onload = function() {
            if (xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);
                if (response.some(item => item.error)) {
                    uploadStatus.textContent = 'Some files failed to upload';
                } else {
                    uploadStatus.textContent = 'Upload complete!';
                    setTimeout(() => {
                        uploadContainer.style.display = 'none';
                        location.reload();
                    }, 1000);
                }
            } else {
                uploadStatus.textContent = 'Upload failed';
            }
            startUpload.disabled = true;
        };
        
        xhr.send(formData);
    });
    
    // Cancel upload
    cancelUpload.addEventListener('click', function() {
        fileInput.value = '';
        uploadContainer.style.display = 'none';
        uploadProgress.style.display = 'none';
    });
    
    // New folder dialog
    newFolderBtn.addEventListener('click', function() {
        newFolderDialog.style.display = 'block';
        folderName.focus();
    });
    
    createFolder.addEventListener('click', function() {
        const name = folderName.value.trim();
        if (name) {
            const formData = new FormData();
            formData.append('folder_name', name);
            formData.append('directory', currentDir);
            
            fetch('?action=create_folder', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                } else {
                    location.reload();
                }
            });
        }
        newFolderDialog.style.display = 'none';
        folderName.value = '';
    });
    
    cancelFolder.addEventListener('click', function() {
        newFolderDialog.style.display = 'none';
        folderName.value = '';
    });
    
    // Refresh
    refreshBtn.addEventListener('click', function() {
        location.reload();
    });
    
    // Select all/none
    selectAll.addEventListener('change', function() {
        fileCheckboxes.forEach(checkbox => {
            checkbox.checked = selectAll.checked;
        });
        updateSelectedCount();
    });
    
    // Update selected items
    function updateSelectedCount() {
        selectedItems = [];
        document.querySelectorAll('.file-checkbox:checked').forEach(checkbox => {
            selectedItems.push(checkbox.dataset.path);
        });
        document.querySelector('.selected-count').textContent = `${selectedItems.length} item(s) selected`;
    }
    
    fileCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateSelectedCount);
    });
    
    // Download selected
    downloadSelected.addEventListener('click', function() {
        if (selectedItems.length === 0) {
            alert('Please select at least one file or folder');
            return;
        }
        
        if (selectedItems.length === 1) {
            window.location.href = `?action=download&path=${encodeURIComponent(selectedItems[0])}`;
        } else {
            // For multiple files, we'd need to implement a zip creation endpoint
            alert('Multiple file download not implemented yet');
        }
    });
    
    // Delete selected
    deleteSelected.addEventListener('click', function() {
        if (selectedItems.length === 0) {
            alert('Please select at least one file or folder');
            return;
        }
        
        if (confirm(`Are you sure you want to delete ${selectedItems.length} item(s)?`)) {
            const promises = selectedItems.map(item => {
                return fetch(`?action=delete&path=${encodeURIComponent(item)}`)
                    .then(response => response.json());
            });
            
            Promise.all(promises)
                .then(results => {
                    const errors = results.filter(r => r.error);
                    if (errors.length > 0) {
                        alert(`Some items could not be deleted: ${errors.map(e => e.error).join(', ')}`);
                    }
                    location.reload();
                });
        }
    });
    
    // Zip selected
    zipSelected.addEventListener('click', function() {
        if (selectedItems.length === 0) {
            alert('Please select at least one file or folder');
            return;
        }
        
        alert('Zip functionality not implemented in this example');
    });
    
    // Change permissions
    chmodSelected.addEventListener('click', function() {
        if (selectedItems.length === 0) {
            alert('Please select at least one file or folder');
            return;
        }
        
        if (selectedItems.length > 1) {
            alert('Please select only one item to change permissions');
            return;
        }
        
        currentFile = selectedItems[0];
        chmodModal.style.display = 'block';
    });
    
    // File actions
    document.querySelectorAll('.edit-action').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            currentFile = this.dataset.path;
            
            fetch(`?action=edit&path=${encodeURIComponent(currentFile)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        alert(data.error);
                    } else {
                        fileEditor.value = data.content;
                        editModal.style.display = 'block';
                    }
                });
        });
    });
    
    document.querySelectorAll('.rename-action').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            currentFile = this.dataset.path;
            const isDir = this.dataset.type === 'dir';
            const currentName = currentFile.split('/').pop();
            
            document.querySelector('#renameModal h2').textContent = `Rename ${isDir ? 'Folder' : 'File'}`;
            newName.value = currentName;
            renameModal.style.display = 'block';
        });
    });
    
    document.querySelectorAll('.chmod-action').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            currentFile = this.dataset.path;
            chmodModal.style.display = 'block';
        });
    });
    
    document.querySelectorAll('.delete-action').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const filePath = this.dataset.path;
            const fileName = filePath.split('/').pop();
            
            if (confirm(`Are you sure you want to delete "${fileName}"?`)) {
                fetch(`?action=delete&path=${encodeURIComponent(filePath)}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.error) {
                            alert(data.error);
                        } else {
                            location.reload();
                        }
                    });
            }
        });
    });
    
    // Modal close buttons
    document.querySelectorAll('.close').forEach(btn => {
        btn.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });
    
    // Save file edits
    saveFile.addEventListener('click', function() {
        const formData = new FormData();
        formData.append('content', fileEditor.value);
        
        fetch(`?action=edit&path=${encodeURIComponent(currentFile)}`, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data === true) {
                editModal.style.display = 'none';
                location.reload();
            } else {
                alert('Failed to save file');
            }
        });
    });
    
    cancelEdit.addEventListener('click', function() {
        editModal.style.display = 'none';
    });
    
    // Confirm rename
    confirmRename.addEventListener('click', function() {
        const newNameValue = newName.value.trim();
        if (!newNameValue) {
            alert('Please enter a new name');
            return;
        }
        
        const formData = new FormData();
        formData.append('new_name', newNameValue);
        
        fetch(`?action=rename&path=${encodeURIComponent(currentFile)}`, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
            } else {
                renameModal.style.display = 'none';
                location.reload();
            }
        });
    });
    
    cancelRename.addEventListener('click', function() {
        renameModal.style.display = 'none';
    });
    
    // Permission checkboxes
    permCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateNumericPerm);
    });
    
    numericPerm.addEventListener('input', function() {
        const value = this.value;
        if (/^[0-7]{0,3}$/.test(value)) {
            updateCheckboxesFromNumeric(value);
        } else if (value.length > 0) {
            this.value = value.slice(0, -1);
        }
    });
    
    function updateNumericPerm() {
        let permValue = 0;
        document.querySelectorAll('.perm-checkbox:checked').forEach(checkbox => {
            permValue += parseInt(checkbox.dataset.bit);
        });
        
        // Convert to octal
        numericPerm.value = permValue.toString(8).padStart(3, '0');
    }
    
    function updateCheckboxesFromNumeric(value) {
        // Pad with zeros if needed
        value = value.padStart(3, '0');
        
        // Clear all checkboxes
        permCheckboxes.forEach(checkbox => {
            checkbox.checked = false;
        });
        
        // Set checkboxes based on numeric value
        const bits = [
            {bit: 400, index: 0}, // owner read
            {bit: 200, index: 1}, // owner write
            {bit: 100, index: 2}, // owner execute
            {bit: 40, index: 3},  // group read
            {bit: 20, index: 4},  // group write
            {bit: 10, index: 5},  // group execute
            {bit: 4, index: 6},   // others read
            {bit: 2, index: 7},    // others write
            {bit: 1, index: 8}     // others execute
        ];
        
        const owner = parseInt(value[0]) || 0;
        const group = parseInt(value[1]) || 0;
        const others = parseInt(value[2]) || 0;
        
        bits.forEach(bit => {
            const checkbox = document.querySelector(`.perm-checkbox[data-bit="${bit.bit}"]`);
            if (bit.index < 3 && (owner & (4 >> bit.index))) {
                checkbox.checked = true;
            } else if (bit.index < 6 && (group & (4 >> (bit.index - 3)))) {
                checkbox.checked = true;
            } else if (bit.index >= 6 && (others & (4 >> (bit.index - 6)))) {
                checkbox.checked = true;
            }
        });
    }
    
    // Apply permissions
    confirmChmod.addEventListener('click', function() {
        const permValue = numericPerm.value.padStart(3, '0');
        
        if (!/^[0-7]{3}$/.test(permValue)) {
            alert('Invalid permission value');
            return;
        }
        
        const formData = new FormData();
        formData.append('mode', permValue);
        
        fetch(`?action=chmod&path=${encodeURIComponent(currentFile)}`, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
            } else {
                chmodModal.style.display = 'none';
                location.reload();
            }
        });
    });
    
    cancelChmod.addEventListener('click', function() {
        chmodModal.style.display = 'none';
    });
    
    // Close modals when clicking outside
    window.addEventListener('click', function(e) {
        if (e.target === editModal) editModal.style.display = 'none';
        if (e.target === renameModal) renameModal.style.display = 'none';
        if (e.target === chmodModal) chmodModal.style.display = 'none';
        if (e.target === newFolderDialog) newFolderDialog.style.display = 'none';
    });
});