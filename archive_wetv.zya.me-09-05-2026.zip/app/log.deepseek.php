<?php
// Start the session
session_start();

// Database credentials (for demonstration, use proper database in production)
$user = 'user';
$pass = 'pass'; 


// Check if user is already logged in via cookies
if (isset($_COOKIE['username']))  {
echo '<h1> welcome.php';
exit();
}

// Process form submission
$error = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$username = $_POST['username'];
$password = $_POST['password'];
$remember = $_POST['remember'];

    // Validate credentials (replace with database check in production)
    if ($username === $user && $password  === $pass) {
        // Create authentication token
       // $auth_token = $user. $pass;
        
        // Set cookies if "Remember Me" is checked
        if ($remember) {
            $cookie_expiration = time() + (30 * 24 * 60 * 60); // 30 days
            setcookie('username', $username, $cookie_expiration, '/', '', true, true);
            //setcookie('auth', $auth_token, $cookie_expiration, '/', '', true, true);
        }
        
        // Redirect to welcome page
        header('Location: welcome.php');
        exit();
    } 
else {$error = 'Invalid username or password';}
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login with Cookies</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: #f0f2f5;
        }

        .login-container {
            background: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 530px;
            margin: 20px;
        }

        .login-form h2 {
            color: #1c1e21;
            text-align: center;
            margin-bottom: 30px;
            font-size: 24px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #606770;
            font-weight: 600;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #dddfe2;
            border-radius: 6px;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: #1877f2;
            box-shadow: 0 0 0 2px rgba(24, 119, 242, 0.2);
        }

        .remember-me {
            margin: 15px 0;
            display: flex;
            align-items: center;
        }

        .remember-me input {
            margin-right: 8px;
        }

        .login-btn {
            width: 100%;
            padding: 12px;
            background: #1877f2;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .login-btn:hover {
            background: #166fe5;
        }

        .error-message {
            color: #ff0000;
            margin-bottom: 15px;
            text-align: center;
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 20px;
                margin: 10px;
            }

            .login-form h2 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <form class="login-form" method="POST">
            <h2>Login</h2>
            
            <?php if ($error): ?>
                <div class="error-message"><?= $error ?></div>
            <?php endif; ?>

            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>

            <div class="remember-me">
                <input type="checkbox" id="remember" name="remember">
                <label for="remember">Remember Me</label>
            </div>

            <button type="submit" class="login-btn">Log In</button>
        </form>
    </div>
</body>
</html>