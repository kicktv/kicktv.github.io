﻿<!DOCTYPE html><html>
<head><title>Index of Files</title>
</head><body><h1>Index of Files</h1>
<ul>
<?php
//php show list all files directories 
//https://stackoverflow.com/a/3977514/12553572
$files = array();
$dir = opendir('./'); // open the cwd..also do an err check.
while(false != ($file = readdir($dir))) {
if(($file != ".") and ($file != "..") and ($file != "index.php")) {
$files[] = $file; // put in array.
}   
}
natsort($files); // sort.
// print.
foreach($files as $file) {
echo("<a href='$file'>$file</a> <br />\n");
}
?>
</ul>
</body></html>