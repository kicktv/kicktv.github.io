<?php
session_start();

// Configuration
$users = [
    'admin' => [
        'password' => 'admin123',
        'role' => 'admin'
    ],
    'user' => [
        'password' => 'user123',
        'role' => 'user'
    ]
];

$baseDir = './'; // Base directory for file storage

// Create base directory if it doesn't exist
if (!file_exists($baseDir)) {
    mkdir($baseDir, 0755, true);
}

// Authentication
function authenticate($username, $password, $users) {
    if (isset($users[$username]) && $users[$username]['password'] === $password) {
        $_SESSION['logged_in'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $users[$username]['role'];
        return true;
    }
    return false;
}

// File operations
function getFileList($dir) {
    $files = [];
    $items = scandir($dir);
    
    foreach ($items as $item) {
        if ($item != '.' && $item != '..') {
            //$path = $dir . '/' . $item;
              $path = $dir . $item;
            $file = [
                'name' => $item,
                'path' => $path,
                'type' => is_dir($path) ? 'dir' : 'file',
                'size' => is_dir($path) ? '' : filesize($path),
                'modified' => date('Y-m-d H:i:s', filemtime($path))
            ];
            
            if (is_file($path)) {
                $file['extension'] = pathinfo($path, PATHINFO_EXTENSION);
            }
            
            $files[] = $file;
        }
    }
    
    return $files;
}

function formatSize($size) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;
    while ($size >= 1024 && $i < count($units) - 1) {
        $size /= 1024;
        $i++;
    }
    return round($size, 2) . ' ' . $units[$i];
}

function isTextFile($file) {
    $textExtensions = ['txt', 'html', 'htm', 'css', 'js', 'php', 'json', 'xml', 'md', 'csv', 'log', 'sql', 'ini', 'conf', 'bat', 'sh'];
    $extension = pathinfo($file, PATHINFO_EXTENSION);
    return in_array(strtolower($extension), $textExtensions);
}

function zipDirectory($source, $destination) {
    if (!extension_loaded('zip') || !file_exists($source)) {
        return false;
    }

    $zip = new ZipArchive();
    if (!$zip->open($destination, ZipArchive::CREATE)) {
        return false;
    }

    $source = str_replace('\\', '/', realpath($source));
    $basePath = substr($source, strrpos($source, '/') + 1);

    if (is_dir($source)) {
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source), RecursiveIteratorIterator::SELF_FIRST);

        foreach ($files as $file) {
            $file = str_replace('\\', '/', realpath($file));

            if (is_dir($file)) {
                $zip->addEmptyDir(str_replace($source . '/', '', $basePath . '/' . $file . '/'));
            } else if (is_file($file)) {
                $zip->addFile($file, str_replace($source . '/', '', $basePath . '/' . $file));
            }
        }
    } else if (is_file($source)) {
        $zip->addFile($source, basename($source));
    }

    return $zip->close();
}

// Handle form actions
$error = '';
$success = '';
$currentDir = isset($_GET['dir']) ? $_GET['dir'] : $baseDir;
$fileContent = '';
$fileName = '';

// Validate current directory path to prevent directory traversal
if (strpos(realpath($currentDir), realpath($baseDir)) !== 0) {
    $currentDir = $baseDir;
}

// Handle login
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    if (authenticate($username, $password, $users)) {
        $success = "Welcome, $username!";
    } else {
        $error = "Invalid username or password!";
    }
}

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Handle file upload (admin only)
if (isset($_POST['upload']) && isset($_SESSION['logged_in']) && $_SESSION['role'] === 'admin') {
    if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $tempFile = $_FILES['file']['tmp_name'];
        $targetFile = $currentDir . '/' . basename($_FILES['file']['name']);
        
        if (move_uploaded_file($tempFile, $targetFile)) {
            $success = "File uploaded successfully!";
        } else {
            $error = "Error uploading file!";
        }
    } else {
        $error = "Please select a file to upload!";
    }
}

// Handle multiple file upload (admin only)
if (isset($_POST['upload_multiple']) && isset($_SESSION['logged_in']) && $_SESSION['role'] === 'admin') {
    $uploadedCount = 0;
    $failedCount = 0;
    
    foreach ($_FILES['multiple_files']['name'] as $key => $name) {
        if ($_FILES['multiple_files']['error'][$key] === UPLOAD_ERR_OK) {
            $tempFile = $_FILES['multiple_files']['tmp_name'][$key];
            $targetFile = $currentDir . '/' . basename($name);
            
            if (move_uploaded_file($tempFile, $targetFile)) {
                $uploadedCount++;
            } else {
                $failedCount++;
            }
        } else if ($_FILES['multiple_files']['error'][$key] !== UPLOAD_ERR_NO_FILE) {
            $failedCount++;
        }
    }
    
    if ($uploadedCount > 0) {
        $success = "$uploadedCount file(s) uploaded successfully!";
        if ($failedCount > 0) {
            $error = "$failedCount file(s) failed to upload.";
        }
    } elseif ($failedCount > 0) {
        $error = "All files failed to upload.";
    } else {
        $error = "Please select files to upload!";
    }
}

// Handle directory creation (admin only)
if (isset($_POST['create_dir']) && isset($_SESSION['logged_in']) && $_SESSION['role'] === 'admin') {
    $dirName = $_POST['dir_name'];
    $newDir = $currentDir . '/' . $dirName;
    
    if (empty($dirName)) {
        $error = "Directory name cannot be empty!";
    } elseif (file_exists($newDir)) {
        $error = "Directory already exists!";
    } else {
        if (mkdir($newDir, 0755)) {
            $success = "Directory created successfully!";
        } else {
            $error = "Error creating directory!";
        }
    }
}

// Handle file creation (admin only)
if (isset($_POST['create_file']) && isset($_SESSION['logged_in']) && $_SESSION['role'] === 'admin') {
    $fileName = $_POST['file_name'];
    $newFile = $currentDir . '/' . $fileName;
    
    if (empty($fileName)) {
        $error = "File name cannot be empty!";
    } elseif (file_exists($newFile)) {
        $error = "File already exists!";
    } else {
        if (file_put_contents($newFile, '') !== false) {
            $success = "File created successfully!";
        } else {
            $error = "Error creating file!";
        }
    }
}

// Handle file editing (admin only)
if (isset($_GET['edit']) && isset($_SESSION['logged_in']) && $_SESSION['role'] === 'admin') {
    $fileToEdit = urldecode($_GET['edit']);
    $fullPath = realpath($fileToEdit);
    $baseDirPath = realpath($baseDir);
    
    // Security check - ensure the file is within the base directory
    if (strpos($fullPath, $baseDirPath) === 0 && is_file($fullPath) && isTextFile($fullPath)) {
        $fileContent = file_get_contents($fullPath);
        $fileName = basename($fullPath);
    } else {
        $error = "Invalid file or non-text file!";
    }
}

// Handle save edited file (admin only)
if (isset($_POST['save_file']) && isset($_SESSION['logged_in']) && $_SESSION['role'] === 'admin') {
    $fileToSave = $_POST['file_path'];
    $content = $_POST['file_content'];
    $fullPath = realpath($fileToSave);
    $baseDirPath = realpath($baseDir);
    
    // Security check
    if (strpos($fullPath, $baseDirPath) === 0 && is_file($fullPath)) {
        if (file_put_contents($fullPath, $content) !== false) {
            $success = "File saved successfully!";
        } else {
            $error = "Error saving file!";
        }
    } else {
        $error = "Invalid file path!";
    }
}

// Handle file renaming (admin only)
if (isset($_POST['rename']) && isset($_SESSION['logged_in']) && $_SESSION['role'] === 'admin') {
    $oldPath = $_POST['old_path'];
    $newName = $_POST['new_name'];
    $dirPath = dirname($oldPath);
    $newPath = $dirPath . '/' . $newName;
    
    $fullOldPath = realpath($oldPath);
    $baseDirPath = realpath($baseDir);
    
    // Security check
    if (strpos($fullOldPath, $baseDirPath) === 0 && file_exists($fullOldPath)) {
        if (empty($newName)) {
            $error = "New name cannot be empty!";
        } elseif (file_exists($newPath)) {
            $error = "A file or directory with that name already exists!";
        } else {
            if (rename($oldPath, $newPath)) {
                $success = "Renamed successfully!";
            } else {
                $error = "Error renaming!";
            }
        }
    } else {
        $error = "Invalid file path!";
    }
}

// Handle file deletion (admin only)
if (isset($_GET['delete']) && isset($_SESSION['logged_in']) && $_SESSION['role'] === 'admin') {
    $fileToDelete = urldecode($_GET['delete']);
    $fullPath = realpath($fileToDelete);
    $baseDirPath = realpath($baseDir);
    
    // Security check - ensure the file is within the base directory
    if (strpos($fullPath, $baseDirPath) === 0) {
        if (is_file($fullPath)) {
            if (unlink($fullPath)) {
                $success = "File deleted successfully!";
            } else {
                $error = "Error deleting file!";
            }
        } elseif (is_dir($fullPath)) {
            // Only empty directories can be deleted with rmdir
            if (count(scandir($fullPath)) <= 2) { // Only . and .. entries
                if (rmdir($fullPath)) {
                    $success = "Directory deleted successfully!";
                } else {
                    $error = "Error deleting directory!";
                }
            } else {
                $error = "Cannot delete non-empty directory!";
            }
        } else {
            $error = "File or directory does not exist!";
        }
    } else {
        $error = "Invalid file path!";
    }
}

// Handle file/directory compression (admin only)
if (isset($_GET['compress']) && isset($_SESSION['logged_in']) && $_SESSION['role'] === 'admin') {
    $pathToCompress = urldecode($_GET['compress']);
    $fullPath = realpath($pathToCompress);
    $baseDirPath = realpath($baseDir);
    
    // Security check
    if (strpos($fullPath, $baseDirPath) === 0 && file_exists($fullPath)) {
        $zipName = basename($fullPath) . '.zip';
        $zipPath = dirname($fullPath) . '/' . $zipName;
        
        if (file_exists($zipPath)) {
            $error = "Zip file already exists!";
        } else {
            if (is_dir($fullPath)) {
                if (zipDirectory($fullPath, $zipPath)) {
                    $success = "Directory compressed successfully!";
                } else {
                    $error = "Error compressing directory!";
                }
            } else {
                $zip = new ZipArchive();
                if ($zip->open($zipPath, ZipArchive::CREATE) === TRUE) {
                    $zip->addFile($fullPath, basename($fullPath));
                    $zip->close();
                    $success = "File compressed successfully!";
                } else {
                    $error = "Error creating zip file!";
                }
            }
        }
    } else {
        $error = "Invalid path!";
    }
}

// Handle zip extraction (admin only)
if (isset($_GET['extract']) && isset($_SESSION['logged_in']) && $_SESSION['role'] === 'admin') {
    $zipFile = urldecode($_GET['extract']);
    $fullPath = realpath($zipFile);
    $baseDirPath = realpath($baseDir);
    
    // Security check
    if (strpos($fullPath, $baseDirPath) === 0 && file_exists($fullPath) && pathinfo($fullPath, PATHINFO_EXTENSION) == 'zip') {
        $extractDir = dirname($fullPath) . '/' . pathinfo(basename($fullPath), PATHINFO_FILENAME);
        
        // Create extraction directory if it doesn't exist
        if (!file_exists($extractDir)) {
            mkdir($extractDir, 0755, true);
        }
        
        $zip = new ZipArchive;
        if ($zip->open($fullPath) === TRUE) {
            $zip->extractTo($extractDir);
            $zip->close();
            $success = "Zip file extracted successfully!";
        } else {
            $error = "Error extracting zip file!";
        }
    } else {
        $error = "Invalid zip file!";
    }
}

// Get file list for current directory
$files = getFileList($currentDir);

// Navigation breadcrumbs
$breadcrumbs = [];
$path = '';
$relativePath = str_replace($baseDir, '', $currentDir);
$parts = explode('/', trim($relativePath, '/'));
$path = $baseDir;
$breadcrumbs[] = ['path' => $baseDir, 'name' => 'Home'];

foreach ($parts as $part) {
    if (!empty($part)) {
        $path .= '/' . $part;
        $breadcrumbs[] = ['path' => $path, 'name' => $part];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enhanced File Manager</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .login-container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="password"],
        textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button, .btn {
            display: inline-block;
            background-color: #4CAF50;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }
        button:hover, .btn:hover {
            background-color: #45a049;
        }
        .btn-danger {
            background-color: #f44336;
        }
        .btn-danger:hover {
            background-color: #da3c30;
        }
        .btn-secondary {
            background-color: #2196F3;
        }
        .btn-secondary:hover {
            background-color: #0b7dda;
        }
        .btn-warning {
            background-color: #ff9800;
        }
        .btn-warning:hover {
            background-color: #e68a00;
        }
        .btn-info {
            background-color: #00bcd4;
        }
        .btn-info:hover {
            background-color: #00a5bb;
        }
        .alert {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .user-info {
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .breadcrumb {
            margin: 10px 0;
            padding: 8px;
            background-color: #f8f9fa;
            border-radius: 4px;
        }
        .breadcrumb a {
            color: #007bff;
            text-decoration: none;
        }
        .breadcrumb a:hover {
            text-decoration: underline;
        }
        .file-list {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .file-list th, .file-list td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .file-list th {
            background-color: #f2f2f2;
        }
        .file-list tr:hover {
            background-color: #f5f5f5;
        }
        .file-icon {
            margin-right: 5px;
        }
        .directory {
            font-weight: bold;
            color: #007bff;
        }
        .actions {
            display: flex;
            flex-wrap: wrap;
            gap: 5px;
        }
        .feature-containers {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 20px;
        }
        .feature-container {
            flex: 1;
            min-width: 250px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #f9f9f9;
        }
        .feature-container h3 {
            margin-bottom: 10px;
        }
        .editor-container {
            margin-top: 20px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #fff;
        }
        .editor-container h2 {
            margin-bottom: 15px;
        }
        textarea.code-editor {
            width: 100%;
            min-height: 400px;
            font-family: Consolas, Monaco, 'Andale Mono', monospace;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            resize: vertical;
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            overflow: auto;
        }
        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 20px;
            border-radius: 5px;
            width: 50%;
            max-width: 500px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: #000;
        }
        .drag-area {
            border: 2px dashed #ccc;
            height: 100px;
            border-radius: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            margin-bottom: 10px;
        }
        .drag-area.active {
            border-color: #4CAF50;
            background-color: #f0fff0;
        }
        .drag-area p {
            margin: 0;
            color: #777;
        }
        
        /* Responsive design */
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }
            .file-list {
                font-size: 14px;
            }
            .feature-containers {
                flex-direction: column;
            }
            .feature-container {
                width: 100%;
            }
            .modal-content {
                width: 90%;
                margin: 20% auto;
            }
        }
        
        /* File type icons */
        .file-image { color: #4CAF50; }
        .file-pdf { color: #f44336; }
        .file-text { color: #2196F3; }
        .file-archive { color: #ff9800; }
        .file-code { color: #9c27b0; }
        .file-default { color: #607d8b; }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="container">
        <h1>Enhanced File Manager</h1>
        
        <?php if (!isset($_SESSION['logged_in'])): ?>
            <!-- Login form -->
            <div class="login-container">
                <h2>Login</h2>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <form method="post" action="">
                    <div class="form-group">
                        <label for="username">Username:</label>
                        <input type="text" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    <button type="submit" name="login">Login</button>
                </form>
            </div>
        <?php else: ?>
            <!-- User info and logout -->
            <div class="user-info">
                <div>
                    <strong>Welcome, <?php echo $_SESSION['username']; ?> (<?php echo $_SESSION['role']; ?>)</strong>
                </div>
                <a href="?logout=1" class="btn btn-danger">Logout</a>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <!-- Breadcrumbs navigation -->
            <div class="breadcrumb">
                <?php foreach ($breadcrumbs as $index => $crumb): ?>
                    <a href="?dir=<?php echo urlencode($crumb['path']); ?>"><?php echo htmlspecialchars($crumb['name']); ?></a>
                    <?php if ($index < count($breadcrumbs) - 1) echo ' / '; ?>
                <?php endforeach; ?>
            </div>
            
            <?php if (isset($_GET['edit']) && $fileName && $_SESSION['role'] === 'admin'): ?>
                <!-- File Editor -->
                <div class="editor-container">
                    <h2>Editing: <?php echo htmlspecialchars($fileName); ?></h2>
                    <form method="post" action="">
                        <input type="hidden" name="file_path" value="<?php echo htmlspecialchars($_GET['edit']); ?>">
                        <div class="form-group">
                            <textarea name="file_content" class="code-editor"><?php echo htmlspecialchars($fileContent); ?></textarea>
                        </div>
                        <div class="form-group">
                            <button type="submit" name="save_file" class="btn">Save Changes</button>
                            <a href="?dir=<?php echo urlencode($currentDir); ?>" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            <?php else: ?>
                <!-- Admin features -->
                <?php if ($_SESSION['role'] === 'admin'): ?>
                    <div class="feature-containers">
                        <!-- File upload form -->
                        <div class="feature-container">
                            <h3>Upload Files</h3>
                            <form method="post" action="" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="file">Single File:</label>
                                    <input type="file" id="file" name="file">
                                    <button type="submit" name="upload" class="btn">Upload</button>
                                </div>
                            </form>
                            <hr style="margin: 15px 0;">
                            <form method="post" action="" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="multiple-files">Multiple Files:</label>
                                    <div class="drag-area" id="drag-area">
                                        <p>Drag & Drop files here or click to browse</p>
                                    </div>
                                    <input type="file" id="multiple-files" name="multiple_files[]" multiple style="display: none;">
                                    <button type="submit" name="upload_multiple" class="btn">Upload All</button>
                                </div>
                            </form>
                        </div>
                        
                        <!-- Create directory form -->
                        <div class="feature-container">
                            <h3>Create Directory</h3>
                            <form method="post" action="">
                                <div class="form-group">
                                    <label for="dir-name">Directory Name:</label>
                                    <input type="text" id="dir-name" name="dir_name" placeholder="New Folder" required>
                                    <button type="submit" name="create_dir" class="btn">Create</button>
                                </div>
                            </form>
                        </div>
                        
                        <!-- Create file form -->
                        <div class="feature-container">
                            <h3>Create File</h3>
                            <form method="post" action="">
                                <div class="form-group">
                                    <label for="file-name">File Name:</label>
                                    <input type="text" id="file-name" name="file_name" placeholder="new-file.txt" required>
                                    <button type="submit" name="create_file" class="btn">Create</button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- File list table -->
                <table class="file-list">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Size</th>
                            <th>Modified</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($currentDir != $baseDir): ?>
                            <tr>
                                <td colspan="5">
                                    <a href="?dir=<?php echo urlencode(dirname($currentDir)); ?>">
                                        <i class="fas fa-arrow-up"></i> Parent Directory
                                    </a>
                                </td>
                            </tr>
                        <?php endif; ?>
                        
                        <?php foreach ($files as $file): ?>
                            <tr>
                                <td>
                                    <?php if ($file['type'] === 'dir'): ?>
                                        <a href="?dir=<?php echo urlencode($file['path']); ?>" class="directory">
                                            <i class="fas fa-folder file-icon"></i> <?php echo htmlspecialchars($file['name']); ?>
                                        </a>
                                    <?php else: ?>
                                        <?php
                                        $iconClass = 'fas fa-file file-default';
                                        if (isset($file['extension'])) {
                                            switch (strtolower($file['extension'])) {
                                                case 'jpg':
                                                case 'jpeg':
                                                case 'png':
                                                case 'gif':
                                                    $iconClass = 'fas fa-file-image file-image';
                                                    break;
                                                case 'pdf':
                                                    $iconClass = 'fas fa-file-pdf file-pdf';
//--------------------------------------------------------------------------------------------------------------------


                                                    break;
                                                case 'txt':
                                                case 'log':
                                                case 'md':
                                                    $iconClass = 'fas fa-file-alt file-text';
                                                    break;
                                                case 'zip':
                                                case 'rar':
                                                case 'tar':
                                                case 'gz':
                                                    $iconClass = 'fas fa-file-archive file-archive';
                                                    break;
                                                case 'html':
                                                case 'css':
                                                case 'php':
                                                case 'js':
                                                case 'json':
                                                case 'xml':
                                                    $iconClass = 'fas fa-file-code file-code';
                                                    break;
                                            }
                                        }
                                        ?>
                                        <i class="<?php echo $iconClass; ?>"></i> <?php echo htmlspecialchars($file['name']); ?>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $file['type'] === 'dir' ? 'Directory' : (isset($file['extension']) ? strtoupper($file['extension']) : 'File'); ?></td>
                                <td><?php echo $file['type'] === 'file' ? formatSize($file['size']) : '-'; ?></td>
                                <td><?php echo $file['modified']; ?></td>
                                <td class="actions">
                                    <?php if ($file['type'] === 'file'): ?>
                                        <a href="<?php echo $file['path']; ?>" target="_blank" class="btn btn-secondary">View</a>
                                        
                                        <?php if ($_SESSION['role'] === 'admin'): ?>
                                            <?php if (isTextFile($file['path'])): ?>
                                                <a href="?edit=<?php echo urlencode($file['path']); ?>&dir=<?php echo urlencode($currentDir); ?>" class="btn btn-info">Edit</a>
                                            <?php endif; ?>
                                            
                                            <button type="button" class="btn btn-warning" onclick="showRenameModal('<?php echo addslashes($file['path']); ?>', '<?php echo addslashes($file['name']); ?>')">Rename</button>
                                            
                                            <?php if (isset($file['extension']) && strtolower($file['extension']) === 'zip'): ?>
                                                <a href="?extract=<?php echo urlencode($file['path']); ?>&dir=<?php echo urlencode($currentDir); ?>" class="btn btn-info" onclick="return confirm('Extract this zip file?')">Extract</a>
                                            <?php else: ?>
                                                <a href="?compress=<?php echo urlencode($file['path']); ?>&dir=<?php echo urlencode($currentDir); ?>" class="btn btn-info" onclick="return confirm('Compress this file?')">Compress</a>
                                            <?php endif; ?>
                                            
                                            <a href="?delete=<?php echo urlencode($file['path']); ?>&dir=<?php echo urlencode($currentDir); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this file?')">Delete</a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if ($_SESSION['role'] === 'admin'): ?>
                                            <button type="button" class="btn btn-warning" onclick="showRenameModal('<?php echo addslashes($file['path']); ?>', '<?php echo addslashes($file['name']); ?>')">Rename</button>
                                            <a href="?compress=<?php echo urlencode($file['path']); ?>&dir=<?php echo urlencode($currentDir); ?>" class="btn btn-info" onclick="return confirm('Compress this directory?')">Compress</a>
                                            <a href="?delete=<?php echo urlencode($file['path']); ?>&dir=<?php echo urlencode($currentDir); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this directory?')">Delete</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        
                        <?php if (count($files) == 0): ?>
                            <tr>
                                <td colspan="5" style="text-align: center;">No files or directories found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    
    <!-- Rename Modal -->
    <div id="renameModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeRenameModal()">&times;</span>
            <h3>Rename</h3>
            <form method="post" action="" id="renameForm">
                <input type="hidden" name="old_path" id="old-path">
                <div class="form-group">
                    <label for="new-name">New Name:</label>
                    <input type="text" id="new-name" name="new_name" required>
                </div>
                <div class="form-group">
                    <button type="submit" name="rename" class="btn">Rename</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Auto-hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            
            alerts.forEach(function(alert) {
                setTimeout(function() {
                    alert.style.opacity = '1';
                    let fadeEffect = setInterval(function() {
                        if (alert.style.opacity > 0) {
                            alert.style.opacity -= 0.1;
                        } else {
                            clearInterval(fadeEffect);
                            alert.style.display = 'none';
                        }
                    }, 50);
                }, 5000);
            });
            
            // Drag and drop functionality
            const dragArea = document.getElementById('drag-area');
            const fileInput = document.getElementById('multiple-files');
            
            if (dragArea && fileInput) {
                dragArea.addEventListener('click', () => {
                    fileInput.click();
                });
                
                fileInput.addEventListener('change', () => {
                    updateFileList(fileInput.files);
                });
                
                dragArea.addEventListener('dragover', (e) => {
                    e.preventDefault();
                    dragArea.classList.add('active');
                });
                
                dragArea.addEventListener('dragleave', () => {
                    dragArea.classList.remove('active');
                });
                
                dragArea.addEventListener('drop', (e) => {
                    e.preventDefault();
                    dragArea.classList.remove('active');
                    fileInput.files = e.dataTransfer.files;
                    updateFileList(e.dataTransfer.files);
                });
                
                function updateFileList(files) {
                    let fileNames = '';
                    if (files.length > 0) {
                        fileNames = `Selected ${files.length} file(s)`;
                    } else {
                        fileNames = 'Drag & Drop files here or click to browse';
                    }
                    dragArea.innerHTML = `<p>${fileNames}</p>`;
                }
            }
        });
        
        // Rename modal functionality
        function showRenameModal(path, name) {
            const modal = document.getElementById('renameModal');
            const oldPathInput = document.getElementById('old-path');
            const newNameInput = document.getElementById('new-name');
            
            oldPathInput.value = path;
            newNameInput.value = name;
            
            modal.style.display = 'block';
        }
        
        function closeRenameModal() {
            const modal = document.getElementById('renameModal');
            modal.style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('renameModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
    </script>
</body>
</html>

