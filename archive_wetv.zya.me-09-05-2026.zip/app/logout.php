<?php
// Clear the user cookie
 setcookie('username', '', time() - 3600, "/"); // Delete username cookie
setcookie('password', '', time() - 3600, "/"); // Delete password cookie
header('Location: login.php');
exit();
?>