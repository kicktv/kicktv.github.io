<?php
/**
Source:https://claude.ai/chat/b9fb0a29-bb05-49a3-a5aa-89cb5c003013
*/

/**
 * Large Video Streaming Script with Range Request Support
 * Supports seeking, forward/backward movement for remote videos
 */

// Check if this is a streaming request
if (isset($_GET['stream']) && isset($_GET['url'])) {
    streamVideo($_GET['url']);
    exit;
}

function streamVideo($remoteVideoUrl) {
    // Configuration
    $bufferSize = 8192; // 8KB chunks for streaming
    
    // Validate URL
    if (empty($remoteVideoUrl)) {
        http_response_code(400);
        die('Error: No video URL provided');
    }
    
    // Validate URL format
    if (!filter_var($remoteVideoUrl, FILTER_VALIDATE_URL)) {
        http_response_code(400);
        die('Error: Invalid URL format');
    }
    
    // Initialize cURL to get video information
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $remoteVideoUrl);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $response = curl_exec($ch);
    
    // Get content information
    $contentLength = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
    $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    
    curl_close($ch);
    
    // Check if remote server responded successfully
    if ($httpCode !== 200 && $httpCode !== 206) {
        http_response_code(404);
        die('Error: Unable to access remote video. HTTP Code: ' . $httpCode . ' - ' . $curlError);
    }
    
    // Validate content length
    if ($contentLength <= 0) {
        // Try to get content length differently
        $contentLength = getRemoteFileSize($remoteVideoUrl);
        if ($contentLength <= 0) {
            http_response_code(500);
            die('Error: Unable to determine video file size');
        }
    }
    
    // Default content type if not provided
    if (empty($contentType) || strpos($contentType, 'video') === false) {
        $contentType = 'video/mp4';
    }
    
    // Get range request from client
    $rangeHeader = isset($_SERVER['HTTP_RANGE']) ? $_SERVER['HTTP_RANGE'] : '';
    $start = 0;
    $end = $contentLength - 1;
    $length = $contentLength;
    
    // Parse range header
    if (!empty($rangeHeader)) {
        // Range header format: bytes=start-end
        if (preg_match('/bytes=(\d+)-(\d*)/', $rangeHeader, $matches)) {
            $start = intval($matches[1]);
            
            if (!empty($matches[2])) {
                $end = intval($matches[2]);
            }
            
            // Validate range
            if ($start > $end || $start < 0 || $end >= $contentLength) {
                header('HTTP/1.1 416 Requested Range Not Satisfiable');
                header("Content-Range: bytes */$contentLength");
                exit;
            }
            
            $length = $end - $start + 1;
            
            // Send partial content response
            http_response_code(206);
            header("Content-Range: bytes $start-$end/$contentLength");
        }
    } else {
        // Send OK response for full content
        http_response_code(200);
    }
    
    // Set headers for video streaming
    header("Content-Type: $contentType");
    header("Content-Length: $length");
    header("Accept-Ranges: bytes");
    header("Cache-Control: public, max-age=3600");
    header("Connection: keep-alive");
    
    // Prevent output buffering
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    // Stream video content from remote server
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $remoteVideoUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
    curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_BUFFERSIZE, $bufferSize);
    curl_setopt($ch, CURLOPT_TIMEOUT, 0);
    
    // Set range for cURL request
    if ($start > 0 || $end < ($contentLength - 1)) {
        curl_setopt($ch, CURLOPT_RANGE, "$start-$end");
    }
    
    // Write function to output data in chunks
    curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($curl, $data) {
        echo $data;
        if (ob_get_level()) {
            ob_flush();
        }
        flush();
        return strlen($data);
    });
    
    // Execute streaming
    $result = curl_exec($ch);
    
    // Check for errors
    if ($result === false) {
        error_log('cURL Error: ' . curl_error($ch));
    }
    
    curl_close($ch);
}

function getRemoteFileSize($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $data = curl_exec($ch);
    $size = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
    curl_close($ch);
    
    return $size;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Stream Player</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            background: #1a1a1a;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 900px;
            width: 100%;
        }
        
        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #4CAF50;
        }
        
        .video-wrapper {
            background: #000;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0,0,0,0.5);
            margin-bottom: 20px;
        }
        
        video {
            width: 100%;
            display: block;
        }
        
        .input-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        
        input[type="text"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #333;
            border-radius: 4px;
            background: #2a2a2a;
            color: #fff;
            font-size: 14px;
        }
        
        input[type="text"]:focus {
            outline: none;
            border-color: #4CAF50;
        }
        
        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        
        button {
            flex: 1;
            padding: 12px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: background 0.3s;
        }
        
        button:hover {
            background: #45a049;
        }
        
        button:active {
            transform: scale(0.98);
        }
        
        button:disabled {
            background: #555;
            cursor: not-allowed;
        }
        
        .controls {
            margin-top: 20px;
            padding: 20px;
            background: #2a2a2a;
            border-radius: 8px;
        }
        
        .controls h3 {
            margin-bottom: 15px;
            color: #4CAF50;
        }
        
        .skip-buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
        }
        
        .skip-buttons button {
            background: #555;
        }
        
        .skip-buttons button:hover:not(:disabled) {
            background: #666;
        }
        
        .info {
            margin-top: 20px;
            padding: 15px;
            background: #2a2a2a;
            border-radius: 8px;
            font-size: 14px;
            line-height: 1.6;
        }
        
        .info strong {
            color: #4CAF50;
        }
        
        .status {
            margin-top: 10px;
            padding: 10px;
            background: #333;
            border-radius: 4px;
            font-size: 13px;
            color: #aaa;
            display: none;
        }
        
        .status.show {
            display: block;
        }
        
        .status.error {
            background: #d32f2f;
            color: #fff;
        }
        
        .status.success {
            background: #388e3c;
            color: #fff;
        }
        
        .examples {
            margin-top: 15px;
            padding: 15px;
            background: #2a2a2a;
            border-radius: 8px;
        }
        
        .examples h3 {
            margin-bottom: 10px;
            color: #4CAF50;
            font-size: 16px;
        }
        
        .examples ul {
            list-style: none;
            padding: 0;
        }
        
        .examples li {
            padding: 8px;
            margin: 5px 0;
            background: #333;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.2s;
            font-size: 13px;
            word-break: break-all;
        }
        
        .examples li:hover {
            background: #444;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎬 Video Stream Player</h1>
        
        <div class="video-wrapper">
            <video id="videoPlayer" controls preload="metadata">
                Your browser does not support the video tag.
            </video>
        </div>
        
        <div class="input-group">
            <label for="videoUrl">Enter Video URL:</label>
            <input type="text" id="videoUrl" placeholder="https://example.com/video.mp4">
            <div class="button-group">
                <button id="loadBtn" onclick="loadVideo()">Load Video</button>
                <button onclick="clearVideo()">Clear</button>
            </div>
            <div id="status" class="status"></div>
        </div>
        
        <div class="controls">
            <h3>Quick Seek Controls</h3>
            <div class="skip-buttons">
                <button onclick="skipVideo(-30)">⏪ -30s</button>
                <button onclick="skipVideo(-10)">⏪ -10s</button>
                <button onclick="skipVideo(10)">+10s ⏩</button>
                <button onclick="skipVideo(30)">+30s ⏩</button>
            </div>
        </div>
        
        <div class="examples">
            <h3>📝 Test with Sample Videos</h3>
            <ul>
                <li onclick="loadSampleVideo('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4')">
                    Big Buck Bunny (Sample Video)
                </li>
                <li onclick="loadSampleVideo('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4')">
                    Elephants Dream (Sample Video)
                </li>
            </ul>
        </div>
        
        <div class="info">
            <strong>Instructions:</strong><br>
            • Enter a direct video URL (MP4, WebM, OGG format)<br>
            • Click "Load Video" to start streaming<br>
            • Use the video controls or quick seek buttons for navigation<br>
            • The script supports range requests for efficient seeking<br>
            • Works with large video files from remote servers<br>
            • You can click on sample videos above to test
        </div>
    </div>
    
    <script>
        const videoPlayer = document.getElementById('videoPlayer');
        const videoUrlInput = document.getElementById('videoUrl');
        const statusDiv = document.getElementById('status');
        const loadBtn = document.getElementById('loadBtn');
        
        function showStatus(message, type = 'info') {
            statusDiv.textContent = message;
            statusDiv.className = 'status show ' + type;
            
            if (type === 'success') {
                setTimeout(() => {
                    statusDiv.className = 'status';
                }, 3000);
            }
        }
        
        function loadVideo() {
            const url = videoUrlInput.value.trim();
            
            if (!url) {
                showStatus('Please enter a video URL', 'error');
                return;
            }
            
            // Validate URL format
            try {
                new URL(url);
            } catch (e) {
                showStatus('Invalid URL format', 'error');
                return;
            }
            
            showStatus('Loading video...', 'info');
            loadBtn.disabled = true;
            
            // Set video source through our PHP streaming script
            const streamUrl = window.location.pathname + '?stream=1&url=' + encodeURIComponent(url);
            videoPlayer.src = streamUrl;
            videoPlayer.load();
        }
        
        function loadSampleVideo(url) {
            videoUrlInput.value = url;
            loadVideo();
        }
        
        function clearVideo() {
            videoPlayer.pause();
            videoPlayer.src = '';
            videoUrlInput.value = '';
            statusDiv.className = 'status';
            loadBtn.disabled = false;
        }
        
        function skipVideo(seconds) {
            if (videoPlayer.src) {
                videoPlayer.currentTime = Math.max(0, Math.min(videoPlayer.duration, videoPlayer.currentTime + seconds));
            } else {
                showStatus('Please load a video first', 'error');
            }
        }
        
        // Handle keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            if (!videoPlayer.src) return;
            
            switch(e.key) {
                case 'ArrowLeft':
                    skipVideo(-10);
                    e.preventDefault();
                    break;
                case 'ArrowRight':
                    skipVideo(10);
                    e.preventDefault();
                    break;
                case ' ':
                    if (videoPlayer.paused) {
                        videoPlayer.play();
                    } else {
                        videoPlayer.pause();
                    }
                    e.preventDefault();
                    break;
            }
        });
        
        // Display video loading status
        videoPlayer.addEventListener('loadstart', function() {
            showStatus('Loading video...', 'info');
        });
        
        videoPlayer.addEventListener('loadedmetadata', function() {
            showStatus('Video loaded successfully!', 'success');
            loadBtn.disabled = false;
        });
        
        videoPlayer.addEventListener('canplay', function() {
            console.log('Video ready to play');
        });
        
        videoPlayer.addEventListener('error', function(e) {
            let errorMsg = 'Error loading video. ';
            if (videoPlayer.error) {
                switch(videoPlayer.error.code) {
                    case 1:
                        errorMsg += 'The video download was aborted.';
                        break;
                    case 2:
                        errorMsg += 'A network error occurred.';
                        break;
                    case 3:
                        errorMsg += 'The video is corrupt or not supported.';
                        break;
                    case 4:
                        errorMsg += 'The video format is not supported.';
                        break;
                    default:
                        errorMsg += 'Unknown error.';
                }
            }
            showStatus(errorMsg, 'error');
            loadBtn.disabled = false;
        });
        
        videoPlayer.addEventListener('seeking', function() {
            console.log('Seeking to: ' + videoPlayer.currentTime);
        });
        
        videoPlayer.addEventListener('seeked', function() {
            console.log('Seeked to: ' + videoPlayer.currentTime);
        });
    </script>
</body>
</html>