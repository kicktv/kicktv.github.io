<?php
// Directory to scan (current directory by default)
$directory = "./";

// Function to recursively list files and folders
function listFilesAndFolders($dir) {
    $result = [];
    if (is_dir($dir)) {
        $files = scandir($dir);
        foreach ($files as $file) {
            if ($file !== '.' && $file !== '..') {
                $path = $dir . DIRECTORY_SEPARATOR . $file;
                if (is_dir($path)) {
                    $result[] = ['type' => 'folder', 'name' => $file, 'path' => $path];
                } else {
                    $result[] = ['type' => 'file', 'name' => $file, 'path' => $path];
                }
            }
        }
    }
    return $result;
}

// Get the list of files and folders
$fileList = listFilesAndFolders($directory);

// Pass the data to the HTML page
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File and Folder List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        li.folder {
            background-color: #e3f2fd;
        }
        li.file {
            background-color: #f1f8e9;
        }
        .icon {
            margin-right: 10px;
            font-size: 20px;
        }
        @media (max-width: 600px) {
            .container {
                padding: 15px;
            }
            li {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Files and Folders</h1>
        <ul id="file-list">
            <?php foreach ($fileList as $item): ?>
                <li class="<?php echo $item['type']; ?>">
                    <span>
                        <span class="icon"><?php echo $item['type'] === 'folder' ? '📁' : '📄'; ?></span>
                        <?php echo htmlspecialchars($item['name']); ?>
                    </span>
                    <span><?php echo $item['type'] === 'folder' ? '' : formatSize(filesize($item['path'])); ?></span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <script>
        // Helper function to format file size
        function formatSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
            const i = Math.floor(Math.log(bytes) / Math.log(1024));
            return parseFloat((bytes / Math.pow(1024, i)).toFixed(2)) + ' ' + sizes[i];
        }

        // Attach the formatSize function to the PHP-generated file sizes
        document.querySelectorAll('#file-list li.file span:last-child').forEach(span => {
            span.textContent = formatSize(parseInt(span.textContent));
        });
    </script>
</body>
</html>