<?php
// Configuration
$rootDir = __DIR__ . ''; // Root directory for file management

// Function to list files and folders
function listFiles($dir) {
    $files = [];
    if (is_dir($dir)) {
        $scanned = array_diff(scandir($dir), ['.', '..']);
        foreach ($scanned as $item) {
            $path = $dir . '/' . $item;
            $files[] = [
                'name' => $item,
                'type' => is_dir($path) ? 'folder' : 'file',
                'size' => is_file($path) ? filesize($path) : 0,
                'mtime' => filemtime($path),
            ];
        }
    }
    return $files;
}

// Handle file deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    $filePath = $rootDir . '/' . $_POST['delete'];
    if (file_exists($filePath)) {
        unlink($filePath);
    }
}

// Get current directory path from query string
$currentDir = isset($_GET['dir']) ? trim($_GET['dir'], '/') : '';
$currentPath = $rootDir . ($currentDir !== '' ? '/' . $currentDir : '');

// Ensure directory exists
if (!is_dir($currentPath)) {
    $currentPath = $rootDir;
    $currentDir = '';
}
?>

<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>File Manager</title>
<style>
/* General Styles */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f5f5f5;
}

.container {
    max-width: 800px;
    margin: 50px auto;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

form {
    display: flex;
    justify-content: center;
    margin-bottom: 20px;
}

input[type="file"], button {
    padding: 10px 20px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
    cursor: pointer;
}

button {
    margin-left: 10px;
    background-color: #007bff;
    color: white;
    border: none;
}

button:hover {
    background-color: #0056b3;
}

.file-list {
    list-style: none;
    padding: 0;
}

.file-list li {
    padding: 10px;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.file-list li a {
    text-decoration: none;
    color: #007bff;
    font-weight: bold;
}

.file-list li span {
    color: #333;
}

.file-list li button {
    background-color: #dc3545;
    color: white;
    border: none;
    padding: 5px 10px;
    border-radius: 4px;
}

.file-list li button:hover {
    background-color: #bd2130;
}


</style>
</head><body>
    <div class="container">
        <h1>File Manager</h1>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="file" name="fileToUpload" id="fileToUpload">
            <button type="submit" name="upload">Upload File</button>
        </form>

        <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['fileToUpload'])): ?>
            <?php
            $targetDir = $currentPath . '/';
            $targetFile = $targetDir . basename($_FILES['fileToUpload']['name']);

            if (move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $targetFile)) {
                echo '<p>File uploaded successfully.</p>';
            } else {
                echo '<p>Error uploading file.</p>';
            }
            ?>
        <?php endif; ?>

        <ul class="file-list">
            <?php if ($currentDir !== ''): ?>
                <li><a href="?dir=<?= dirname($currentDir) ?>">../</a></li>
            <?php endif; ?>
            <?php foreach (listFiles($currentPath) as $file): ?>
                <li>
                    <?php if ($file['type'] === 'folder'): ?>
                        <a href="?dir=<?= $currentDir !== '' ? $currentDir . '/' . $file['name'] : $file['name'] ?>"><?= $file['name'] ?></a>
                    <?php else: ?>
                        <span><?= $file['name'] ?> (<?= round($file['size'] / 1024, 2) ?> KB)</span>
                        <form action="" method="post" style="display:inline;">
                            <button type="submit" name="delete" value="<?= $currentDir !== '' ? $currentDir . '/' . $file['name'] : $file['name'] ?>" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const fileInput = document.getElementById('fileToUpload');

    fileInput.addEventListener('change', function () {
        if (this.files.length > 0) {
            alert('Selected file: ' + this.files[0].name);
        }
    });
});

</script>
</body>
</html>