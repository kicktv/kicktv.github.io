<?php
/**
 * Large Video Streaming Script with Range Request Support
 * Supports seeking, forward/backward movement for remote videos
 */

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors in stream
ini_set('log_errors', 1);

// Check if this is a streaming request
if (isset($_GET['stream']) && isset($_GET['url'])) {
    streamVideo($_GET['url']);
    exit;
}

// Check if this is a test request
if (isset($_GET['test']) && isset($_GET['url'])) {
    testVideoUrl($_GET['url']);
    exit;
}

function testVideoUrl($url) {
    header('Content-Type: application/json');
    
    $result = array(
        'url' => $url,
        'accessible' => false,
        'supports_range' => false,
        'content_type' => '',
        'content_length' => 0,
        'http_code' => 0,
        'error' => ''
    );
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    
    $response = curl_exec($ch);
    
    if ($response === false) {
        $result['error'] = curl_error($ch);
        curl_close($ch);
        echo json_encode($result);
        return;
    }
    
    $result['http_code'] = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $result['content_type'] = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $result['content_length'] = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
    
    // Check if accessible
    if ($result['http_code'] == 200 || $result['http_code'] == 206) {
        $result['accessible'] = true;
    }
    
    // Check for Accept-Ranges header
    if (preg_match('/accept-ranges:\s*bytes/i', $response)) {
        $result['supports_range'] = true;
    }
    
    curl_close($ch);
    
    echo json_encode($result);
}

function streamVideo($remoteVideoUrl) {
    // Configuration
    $bufferSize = 1024 * 16; // 16KB chunks
    
    // Validate URL
    if (empty($remoteVideoUrl)) {
        http_response_code(400);
        die('Error: No video URL provided');
    }
    
    // Validate URL format
    if (!filter_var($remoteVideoUrl, FILTER_VALIDATE_URL)) {
        http_response_code(400);
        die('Error: Invalid URL format');
    }
    
    // Initialize cURL to get video information with better headers
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $remoteVideoUrl);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
    curl_setopt($ch, CURLOPT_REFERER, isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '');
    
    $response = curl_exec($ch);
    
    if ($response === false) {
        http_response_code(500);
        die('Error: ' . curl_error($ch));
    }
    
    // Get content information
    $contentLength = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
    $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    curl_close($ch);
    
    // Check if remote server responded successfully
    if ($httpCode !== 200 && $httpCode !== 206) {
        http_response_code($httpCode);
        die('Error: Unable to access remote video. HTTP Code: ' . $httpCode);
    }
    
    // Handle cases where content length is not available
    if ($contentLength <= 0) {
        // Some servers don't provide content-length, try alternative method
        $contentLength = getRemoteFileSizeAlternative($remoteVideoUrl);
    }
    
    // Default content type if not provided
    if (empty($contentType) || strpos($contentType, 'video') === false) {
        // Try to detect from URL
        $ext = strtolower(pathinfo(parse_url($remoteVideoUrl, PHP_URL_PATH), PATHINFO_EXTENSION));
        switch($ext) {
            case 'mp4':
                $contentType = 'video/mp4';
                break;
            case 'webm':
                $contentType = 'video/webm';
                break;
            case 'ogg':
            case 'ogv':
                $contentType = 'video/ogg';
                break;
            case 'mov':
                $contentType = 'video/quicktime';
                break;
            case 'avi':
                $contentType = 'video/x-msvideo';
                break;
            case 'mkv':
                $contentType = 'video/x-matroska';
                break;
            default:
                $contentType = 'video/mp4';
        }
    }
    
    // Get range request from client
    $rangeHeader = isset($_SERVER['HTTP_RANGE']) ? $_SERVER['HTTP_RANGE'] : '';
    $start = 0;
    $end = ($contentLength > 0) ? $contentLength - 1 : 0;
    $length = $contentLength;
    
    // Parse range header
    if (!empty($rangeHeader) && $contentLength > 0) {
        if (preg_match('/bytes=(\d+)-(\d*)/', $rangeHeader, $matches)) {
            $start = intval($matches[1]);
            
            if (!empty($matches[2])) {
                $end = intval($matches[2]);
            }
            
            // Validate range
            if ($start > $end || $start < 0 || $end >= $contentLength) {
                header('HTTP/1.1 416 Requested Range Not Satisfiable');
                header("Content-Range: bytes */$contentLength");
                exit;
            }
            
            $length = $end - $start + 1;
            
            // Send partial content response
            http_response_code(206);
            header("Content-Range: bytes $start-$end/$contentLength");
        }
    } else {
        // Send OK response for full content
        http_response_code(200);
    }
    
    // Set headers for video streaming
    header("Content-Type: $contentType");
    if ($contentLength > 0) {
        header("Content-Length: $length");
    }
    header("Accept-Ranges: bytes");
    header("Cache-Control: public, max-age=3600");
    header("Connection: keep-alive");
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Expose-Headers: Content-Length, Content-Range");
    
    // Prevent output buffering
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    // Disable time limit for large files
    set_time_limit(0);
    
    // Stream video content from remote server
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $remoteVideoUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
    curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_BUFFERSIZE, $bufferSize);
    curl_setopt($ch, CURLOPT_TIMEOUT, 0);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
    curl_setopt($ch, CURLOPT_REFERER, isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '');
    
    // Set range for cURL request
    if ($start > 0 || ($contentLength > 0 && $end < ($contentLength - 1))) {
        curl_setopt($ch, CURLOPT_RANGE, "$start-$end");
    }
    
    // Write function to output data in chunks
    curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($curl, $data) {
        echo $data;
        if (connection_status() != 0) {
            return 0; // Stop if connection is aborted
        }
        return strlen($data);
    });
    
    // Execute streaming
    curl_exec($ch);
    curl_close($ch);
}

function getRemoteFileSizeAlternative($url) {
    // Try to get file size using GET with small range
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_NOBODY, false);
    curl_setopt($ch, CURLOPT_RANGE, '0-0');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    
    $response = curl_exec($ch);
    
    if ($response !== false && preg_match('/content-range:\s*bytes\s*\d+-\d+\/(\d+)/i', $response, $matches)) {
        curl_close($ch);
        return intval($matches[1]);
    }
    
    curl_close($ch);
    return -1;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Stream Player</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 900px;
            width: 100%;
        }
        
        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #4CAF50;
            font-size: 28px;
        }
        
        .video-wrapper {
            background: #000;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0,0,0,0.5);
            margin-bottom: 20px;
        }
        
        video {
            width: 100%;
            display: block;
        }
        
        .input-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        
        input[type="text"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #333;
            border-radius: 4px;
            background: #2a2a2a;
            color: #fff;
            font-size: 14px;
        }
        
        input[type="text"]:focus {
            outline: none;
            border-color: #4CAF50;
        }
        
        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        
        button {
            flex: 1;
            padding: 12px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        button:hover:not(:disabled) {
            background: #45a049;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(76, 175, 80, 0.3);
        }
        
        button:active:not(:disabled) {
            transform: translateY(0);
        }
        
        button:disabled {
            background: #555;
            cursor: not-allowed;
            opacity: 0.6;
        }
        
        button.secondary {
            background: #ff9800;
        }
        
        button.secondary:hover:not(:disabled) {
            background: #f57c00;
        }
        
        .controls {
            margin-top: 20px;
            padding: 20px;
            background: rgba(42, 42, 42, 0.8);
            border-radius: 8px;
            backdrop-filter: blur(10px);
        }
        
        .controls h3 {
            margin-bottom: 15px;
            color: #4CAF50;
        }
        
        .skip-buttons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
        }
        
        .skip-buttons button {
            background: #555;
        }
        
        .skip-buttons button:hover:not(:disabled) {
            background: #666;
            box-shadow: 0 4px 8px rgba(255, 255, 255, 0.1);
        }
        
        .status {
            margin-top: 10px;
            padding: 12px;
            background: #333;
            border-radius: 4px;
            font-size: 13px;
            color: #aaa;
            display: none;
            border-left: 4px solid #555;
        }
        
        .status.show {
            display: block;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .status.error {
            background: #d32f2f;
            color: #fff;
            border-left-color: #f44336;
        }
        
        .status.success {
            background: #388e3c;
            color: #fff;
            border-left-color: #4CAF50;
        }
        
        .status.warning {
            background: #f57c00;
            color: #fff;
            border-left-color: #ff9800;
        }
        
        .examples {
            margin-top: 15px;
            padding: 15px;
            background: rgba(42, 42, 42, 0.8);
            border-radius: 8px;
            backdrop-filter: blur(10px);
        }
        
        .examples h3 {
            margin-bottom: 10px;
            color: #4CAF50;
            font-size: 16px;
        }
        
        .examples ul {
            list-style: none;
            padding: 0;
        }
        
        .examples li {
            padding: 10px;
            margin: 5px 0;
            background: #333;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.2s;
            font-size: 13px;
            word-break: break-all;
            border-left: 3px solid transparent;
        }
        
        .examples li:hover {
            background: #444;
            border-left-color: #4CAF50;
            transform: translateX(5px);
        }
        
        .info {
            margin-top: 20px;
            padding: 15px;
            background: rgba(42, 42, 42, 0.8);
            border-radius: 8px;
            font-size: 14px;
            line-height: 1.8;
            backdrop-filter: blur(10px);
        }
        
        .info strong {
            color: #4CAF50;
        }
        
        .debug-info {
            margin-top: 10px;
            padding: 10px;
            background: #1a1a1a;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            display: none;
        }
        
        .debug-info.show {
            display: block;
        }
        
        .debug-info div {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎬 Video Stream Player</h1>
        
        <div class="video-wrapper">
            <video id="videoPlayer" controls preload="metadata">
                Your browser does not support the video tag.
            </video>
        </div>
        
        <div class="input-group">
            <label for="videoUrl">Enter Video URL:</label>
            <input type="text" id="videoUrl" placeholder="https://example.com/video.mp4">
            <div class="button-group">
                <button id="testBtn" class="secondary" onclick="testVideo()">🔍 Test URL</button>
                <button id="loadBtn" onclick="loadVideo()">▶️ Load Video</button>
                <button onclick="clearVideo()">🗑️ Clear</button>
            </div>
            <div id="status" class="status"></div>
            <div id="debugInfo" class="debug-info"></div>
        </div>
        
        <div class="controls">
            <h3>⏩ Quick Seek Controls</h3>
            <div class="skip-buttons">
                <button onclick="skipVideo(-30)">⏪ -30s</button>
                <button onclick="skipVideo(-10)">⏪ -10s</button>
                <button onclick="skipVideo(10)">+10s ⏩</button>
                <button onclick="skipVideo(30)">+30s ⏩</button>
            </div>
        </div>
        
        <div class="examples">
            <h3>📝 Test with Sample Videos</h3>
            <ul>
                <li onclick="loadSampleVideo('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4')">
                    🐰 Big Buck Bunny (Google Cloud Storage)
                </li>
                <li onclick="loadSampleVideo('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4')">
                    🐘 Elephants Dream (Google Cloud Storage)
                </li>
                <li onclick="loadSampleVideo('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4')">
                    🔥 For Bigger Blazes (Google Cloud Storage)
                </li>
            </ul>
        </div>
        
        <div class="info">
            <strong>📋 Instructions:</strong><br>
            • Enter a direct video URL (MP4, WebM, OGG, MOV, AVI, MKV)<br>
            • Click "🔍 Test URL" to check if the video is accessible<br>
            • Click "▶️ Load Video" to start streaming<br>
            • Use video controls or quick seek buttons for navigation<br>
            • Supports range requests for efficient seeking<br>
            • Works with large video files from remote servers<br>
            <br>
            <strong>⚠️ Common Issues:</strong><br>
            • Video must be a direct link (not a web page)<br>
            • Some servers block hotlinking or require authentication<br>
            • HTTPS sites may block HTTP video sources<br>
            • Test URL feature will show detailed connection info
        </div>
    </div>
    
    <script>
        const videoPlayer = document.getElementById('videoPlayer');
        const videoUrlInput = document.getElementById('videoUrl');
        const statusDiv = document.getElementById('status');
        const debugInfoDiv = document.getElementById('debugInfo');
        const loadBtn = document.getElementById('loadBtn');
        const testBtn = document.getElementById('testBtn');
        
        function showStatus(message, type = 'info') {
            statusDiv.textContent = message;
            statusDiv.className = 'status show ' + type;
            
            if (type === 'success') {
                setTimeout(() => {
                    statusDiv.className = 'status';
                }, 5000);
            }
        }
        
        function showDebugInfo(data) {
            let html = '<strong>🔍 Connection Test Results:</strong><br>';
            html += '<div>📍 HTTP Code: ' + data.http_code + '</div>';
            html += '<div>✅ Accessible: ' + (data.accessible ? 'Yes' : 'No') + '</div>';
            html += '<div>📊 Range Support: ' + (data.supports_range ? 'Yes' : 'No') + '</div>';
            html += '<div>📦 Content Type: ' + (data.content_type || 'Unknown') + '</div>';
            html += '<div>📏 File Size: ' + formatBytes(data.content_length) + '</div>';
            if (data.error) {
                html += '<div style="color: #f44336;">❌ Error: ' + data.error + '</div>';
            }
            
            debugInfoDiv.innerHTML = html;
            debugInfoDiv.className = 'debug-info show';
        }
        
        function formatBytes(bytes) {
            if (bytes === 0 || bytes < 0) return 'Unknown';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
        }
        
        async function testVideo() {
            const url = videoUrlInput.value.trim();
            
            if (!url) {
                showStatus('Please enter a video URL', 'error');
                return;
            }
            
            try {
                new URL(url);
            } catch (e) {
                showStatus('Invalid URL format', 'error');
                return;
            }
            
            showStatus('Testing video URL...', 'info');
            testBtn.disabled = true;
            debugInfoDiv.className = 'debug-info';
            
            try {
                const response = await fetch(window.location.pathname + '?test=1&url=' + encodeURIComponent(url));
                const data = await response.json();
                
                showDebugInfo(data);
                
                if (data.accessible) {
                    showStatus('✅ Video is accessible and ready to stream!', 'success');
                } else {
                    showStatus('⚠️ Video may not be accessible. Check debug info below.', 'warning');
                }
            } catch (error) {
                showStatus('❌ Failed to test URL: ' + error.message, 'error');
            } finally {
                testBtn.disabled = false;
            }
        }
        
        function loadVideo() {
            const url = videoUrlInput.value.trim();
            
            if (!url) {
                showStatus('Please enter a video URL', 'error');
                return;
            }
            
            try {
                new URL(url);
            } catch (e) {
                showStatus('Invalid URL format', 'error');
                return;
            }
            
            showStatus('Loading video...', 'info');
            loadBtn.disabled = true;
            
            const streamUrl = window.location.pathname + '?stream=1&url=' + encodeURIComponent(url);
            videoPlayer.src = streamUrl;
            videoPlayer.load();
        }
        
        function loadSampleVideo(url) {
            videoUrlInput.value = url;
            debugInfoDiv.className = 'debug-info';
            loadVideo();
        }
        
        function clearVideo() {
            videoPlayer.pause();
            videoPlayer.src = '';
            videoUrlInput.value = '';
            statusDiv.className = 'status';
            debugInfoDiv.className = 'debug-info';
            loadBtn.disabled = false;
        }
        
        function skipVideo(seconds) {
            if (videoPlayer.src && videoPlayer.duration) {
                videoPlayer.currentTime = Math.max(0, Math.min(videoPlayer.duration, videoPlayer.currentTime + seconds));
            } else {
                showStatus('Please load a video first', 'error');
            }
        }
        
        document.addEventListener('keydown', function(e) {
            if (!videoPlayer.src || document.activeElement === videoUrlInput) return;
            
            switch(e.key) {
                case 'ArrowLeft':
                    skipVideo(-10);
                    e.preventDefault();
                    break;
                case 'ArrowRight':
                    skipVideo(10);
                    e.preventDefault();
                    break;
                case ' ':
                    if (videoPlayer.paused) {
                        videoPlayer.play();
                    } else {
                        videoPlayer.pause();
                    }
                    e.preventDefault();
                    break;
            }
        });
        
        videoPlayer.addEventListener('loadstart', function() {
            showStatus('Loading video...', 'info');
        });
        
        videoPlayer.addEventListener('loadedmetadata', function() {
            showStatus('✅ Video loaded successfully! Duration: ' + Math.round(videoPlayer.duration) + 's', 'success');
            loadBtn.disabled = false;
        });
        
        videoPlayer.addEventListener('canplay', function() {
            console.log('Video ready to play');
        });
        
        videoPlayer.addEventListener('error', function(e) {
            let errorMsg = '❌ Error loading video. ';
            if (videoPlayer.error) {
                switch(videoPlayer.error.code) {
                    case 1:
                        errorMsg += 'Download aborted.';
                        break;
                    case 2:
                        errorMsg += 'Network error.';
                        break;
                    case 3:
                        errorMsg += 'Video corrupt or unsupported format.';
                        break;
                    case 4:
                        errorMsg += 'Format not supported by browser.';
                        break;
                    default:
                        errorMsg += 'Unknown error.';
                }
            }
            errorMsg += ' Try testing the URL first.';
            showStatus(errorMsg, 'error');
            loadBtn.disabled = false;
        });
        
        videoPlayer.addEventListener('progress', function() {
            if (videoPlayer.buffered.length > 0) {
                const buffered = videoPlayer.buffered.end(videoPlayer.buffered.length - 1);
                const duration = videoPlayer.duration;
                if (duration > 0) {
                    const percent = Math.round((buffered / duration) * 100);
                    console.log('Buffered: ' + percent + '%');
                }
            }
        });
    </script>
</body>
</html>