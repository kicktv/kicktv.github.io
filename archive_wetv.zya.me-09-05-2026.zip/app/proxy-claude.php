<?php
// Configuration
$remoteUrl = "http://flaxtv.blogspot.com/"; // Change this to the URL you want to proxy
$baseProxyUrl = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
$replaceBaseUrl = $remoteUrl; // The base URL to replace in links

// Get the URL to fetch from the query parameter or use the default
$urlToFetch = isset($_GET['url']) ? $_GET['url'] : $remoteUrl;

// Validate URL (basic security check)
if (!filter_var($urlToFetch, FILTER_VALIDATE_URL)) {
    die("Invalid URL provided");
}

// Initialize cURL session
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $urlToFetch);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Only for development
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');

// Execute cURL session
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);

// Check for cURL errors
if (curl_errno($ch)) {
    die("Fetch error: " . curl_error($ch));
}
curl_close($ch);

// If not HTML content, output as-is with proper content type
if (strpos($contentType, 'text/html') === false) {
    header("Content-Type: $contentType");
    echo $response;
    exit;
}

// Process HTML content
function replaceUrls($html, $baseUrl, $proxyUrl, $replaceBase) {
    // Create a DOM parser
    $dom = new DOMDocument();
    
    // Suppress errors for malformed HTML
    libxml_use_internal_errors(true);
    $dom->loadHTML($html, LIBXML_NOWARNING);
    libxml_clear_errors();
    
    // Process links (a href)
    $links = $dom->getElementsByTagName('a');
    foreach ($links as $link) {
        if ($link->hasAttribute('href')) {
            $href = $link->getAttribute('href');
            
            // Skip javascript: links, anchor links, and mailto: links
            if (strpos($href, 'javascript:') === 0 || strpos($href, '#') === 0 || strpos($href, 'mailto:') === 0) {
                continue;
            }
            
            // Convert relative URLs to absolute
            if (strpos($href, 'http') !== 0) {
                // Handle root-relative URLs
                if (strpos($href, '/') === 0) {
                    $href = rtrim($replaceBase, '/') . $href;
                } else {
                    // Handle relative URLs
                    $href = rtrim(dirname($baseUrl), '/') . '/' . $href;
                }
            }
            
            // Replace links to proxy through this script
            $proxyHref = $proxyUrl . "?url=" . urlencode($href);
            $link->setAttribute('href', $proxyHref);
        }
    }
    
    // Process forms (action attribute)
    $forms = $dom->getElementsByTagName('form');
    foreach ($forms as $form) {
        if ($form->hasAttribute('action')) {
            $action = $form->getAttribute('action');
            
            // Convert relative URLs to absolute
            if (strpos($action, 'http') !== 0 && strpos($action, '#') !== 0) {
                if (strpos($action, '/') === 0) {
                    $action = rtrim($replaceBase, '/') . $action;
                } else {
                    $action = rtrim(dirname($baseUrl), '/') . '/' . $action;
                }
            }
            
            // Replace form action to proxy through this script
            $proxyAction = $proxyUrl . "?url=" . urlencode($action);
            $form->setAttribute('action', $proxyAction);
        }
        
        // Add hidden field to preserve method
        $method = $form->getAttribute('method');
        $input = $dom->createElement('input');
        $input->setAttribute('type', 'hidden');
        $input->setAttribute('name', '_proxy_method');
        $input->setAttribute('value', $method);
        $form->appendChild($input);
    }
    
    // Process images, scripts, css (src, href)
    $tags = array(
        array('tag' => 'img', 'attr' => 'src'),
        array('tag' => 'script', 'attr' => 'src'),
        array('tag' => 'link', 'attr' => 'href')
    );
    
    foreach ($tags as $tagInfo) {
        $elements = $dom->getElementsByTagName($tagInfo['tag']);
        foreach ($elements as $element) {
            if ($element->hasAttribute($tagInfo['attr'])) {
                $src = $element->getAttribute($tagInfo['attr']);
                
                // Skip data: URLs and absolute URLs that don't match our base
                if (strpos($src, 'data:') === 0) {
                    continue;
                }
                
                // Convert relative URLs to absolute
                if (strpos($src, 'http') !== 0) {
                    if (strpos($src, '/') === 0) {
                        $src = rtrim($replaceBase, '/') . $src;
                    } else {
                        $src = rtrim(dirname($baseUrl), '/') . '/' . $src;
                    }
                }
                
                // For resources like images, CSS, and scripts, we'll directly link to them
                // or optionally proxy them through a resource-specific endpoint
                $element->setAttribute($tagInfo['attr'], $src);
            }
        }
    }
    
    // Add base target to open links in the same window
    $head = $dom->getElementsByTagName('head')->item(0);
    if ($head) {
        $base = $dom->createElement('base');
        $base->setAttribute('target', '_self');
        $head->appendChild($base);
    }
    
    // Add custom CSS for responsiveness
    $style = $dom->createElement('style');
    $style->setAttribute('type', 'text/css');
    $css = '
        /* Responsive styles */
       // body {
            max-width: 100%;
            overflow-x: hidden;
        }

     //  img, video, iframe {
            max-width: 100%;
            height: auto;
        }
        /* Proxy notification bar */
      
  // #proxy-bar {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background-color: rgba(0,0,0,0.8);
            color: white;
            padding: 10px;
            z-index: 9999;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
       // #proxy-bar a {
            color: #4CAF50;
        }
       
// #proxy-bar-close {
            cursor: pointer;
            padding: 0 10px;
        }
       // body {
            margin-top: 40px;
        }
      //  @media (max-width: 768px) {
            #proxy-bar {
                padding: 5px;
                font-size: 12px;
            }
            body {
                margin-top: 30px;
            }
        }

    ';
    $style->appendChild($dom->createTextNode($css));
    $head->appendChild($style);
    
    // Add proxy notification bar script
    $script = $dom->createElement('script');
    $js = '
        document.addEventListener("DOMContentLoaded", function() {
            var div = document.createElement("div");
            div.id = "proxy-bar";
            div.innerHTML = "Viewing proxied content from <a href=\"' . htmlspecialchars($baseUrl) . 
            '\">' . htmlspecialchars($baseUrl) . '</a> <span id=\"proxy-bar-close\">×</span>";
            document.body.insertBefore(div, document.body.firstChild);
            
            document.getElementById("proxy-bar-close").addEventListener("click", function() {
                document.getElementById("proxy-bar").style.display = "none";
                document.body.style.marginTop = "0";
            });
            
            // Handle AJAX requests
            (function(open) {
                XMLHttpRequest.prototype.open = function(method, url, async, user, pass) {
                    // Modify URLs for AJAX requests
                    if (url.indexOf("http") === 0 && url.indexOf("' . $_SERVER['HTTP_HOST'] . '") === -1) {
                        url = "' . $baseProxyUrl . '?url=" + encodeURIComponent(url);
                    }
                    open.call(this, method, url, async, user, pass);
                };
            })(XMLHttpRequest.prototype.open);
        });
    ';
    $script->appendChild($dom->createTextNode($js));
    $head->appendChild($script);
    
    return $dom->saveHTML();
}

// Process the HTML
$processedHtml = replaceUrls($response, $urlToFetch, $baseProxyUrl, $replaceBaseUrl);

// Output the processed HTML
header("Content-Type: text/html; charset=UTF-8");
echo $processedHtml;
?>