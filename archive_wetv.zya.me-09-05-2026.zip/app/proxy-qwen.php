<?php
// index.php

// Check if the user has submitted a URL to fetch
$remoteUrl = $_GET['url'] ?? '';

if (!empty($remoteUrl)) {
    // Validate the URL
    if (filter_var($remoteUrl, FILTER_VALIDATE_URL)) {
        // Fetch the content from the remote URL
        $content = file_get_contents($remoteUrl);

        if ($content !== false) {
            // Modify the HTML links (replace href attributes)
            $dom = new DOMDocument();
            @$dom->loadHTML($content); // Suppress warnings for invalid HTML

            // Get all anchor tags
            $anchors = $dom->getElementsByTagName('a');
            foreach ($anchors as $anchor) {
                $href = $anchor->getAttribute('href');
                if (!empty($href)) {
                    // Replace the href with a proxy link
                    $proxyHref = "proxy-qwen.php?url=" . urlencode($href);
                    $anchor->setAttribute('href', $proxyHref);
                }
            }

            // Convert the modified DOM back to HTML
            $modifiedContent = $dom->saveHTML();

            // Output the modified content
            echo $modifiedContent;
            exit;
        } else {
            echo "<p>Failed to fetch content from the provided URL.</p>";
        }
    } else {
        echo "<p>Invalid URL provided.</p>";
    }
}
?>

<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Proxy Website</title>
<style>
/* style.css */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    background-color: #f4f4f9;
    color: #333;
    padding: 20px;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    margin-bottom: 20px;
}

form {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 20px;
}

input[type="text"] {
    width: 70%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    margin-right: 10px;
}

button {
    padding: 10px 20px;
    background-color: #007BFF;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

#content {
    margin-top: 20px;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    background-color: #f9f9f9;
}

@media (max-width: 768px) {
    input[type="text"] {
        width: 60%;
    }

    button {
        padding: 8px 15px;
    }
}
</style>
</head>
<body>
    <div class="container">
        <h1>Proxy Website</h1>
        <form method="GET" action="proxy-qwen.php">
            <label for="url">Enter URL:</label>
            <input type="text" id="url" name="url" placeholder="https://example.com" required>
            <button type="submit">Fetch Content</button>
        </form>

        <div id="content">
            <!-- Fetched content will be displayed here -->
        </div>
    </div>

<script>
// script.js

document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('form');

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const urlInput = document.getElementById('url');
        const url = urlInput.value.trim();

        if (url) {
            // Redirect to the same page with the URL parameter
            window.location.href = `proxy-qwen.php?url=${encodeURIComponent(url)}`;
        } else {
            alert('Please enter a valid URL.');
        }
    });
});
</script>
</body>
</html>