<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login with Cookies</title>
<style>
/* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f9;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.login-container {
    background-color: #fff;
    padding: 40px 30px;
    border-radius: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 98%;
    max-width: 490px;
    text-align: center;
}

.login-container h2 {
    margin-bottom: 20px;
    color: #333;
}

.login-container label {
     float: left;
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: #555;
}

.login-container input[type="text"],
.login-container input[type="password"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 16px;
}

.login-container button {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.login-container button:hover {
    background-color: #0056b3;
}

@media (max-width: 600px) {
    .login-container {
        padding: 15px;
    }

    .login-container input[type="text"],
    .login-container input[type="password"] {
        font-size: 14px;
    }

    .login-container button {
        font-size: 14px;
    }
}
</style>
</head>
<body>
<?php
// Check if the user is already logged in via cookies
if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
    $storedUsername = $_COOKIE['username'];
    $storedPassword = $_COOKIE['password'];

    // Simulated database credentials (for demonstration purposes only)
    $validUsername = "admin";
    $validPassword = "pass";

    if ($storedUsername === $validUsername && $storedPassword === $validPassword) {
        echo "<p><h2>Welcome, $storedUsername!... </h2></p> <br/>";
        echo "<p>You are logged in.</p>";
        echo '<a href="logout.php">Logout</a>';
        exit;
    }
}

/*
// Handle logout request
if (isset($_GET['logout'])) {
    setcookie('username', '', time() - 3600, "/"); // Delete username cookie
    setcookie('password', '', time() - 3600, "/"); // Delete password cookie
    header("Location: login.php");
    exit();
}
*/

// Handle login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Simulated database credentials (for demonstration purposes only)
    $validUsername = "admin";
    $validPassword = "pass";

    if ($username === $validUsername && $password === $validPassword) {
        // Set cookies to keep the user logged in
        setcookie('username', $username, time() + (86400 * 30), "/"); // Expires in 30 days
        setcookie('password', $password, time() + (86400 * 30), "/"); // Expires in 30 days
        header("Location: login.php");
        exit();
    } else {
        $error = "Invalid username or password!";
    }
}
?>

<div class="login-container">
    <h2>Login</h2>
    <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <form method="post" action="">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <button type="submit">Login</button>
    </form>
</div>

</body>
</html>