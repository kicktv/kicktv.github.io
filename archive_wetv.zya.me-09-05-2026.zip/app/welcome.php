<?php
session_start();

// Check if cookies exist
if (!isset($_COOKIE['username']) || !isset($_COOKIE['auth'])) {
    header('Location: log.deepseek.php');
    exit;
}

// Validate cookies (add proper validation in production)
$valid_username = 'user123';
$valid_password_hash = password_hash('pass123', PASSWORD_DEFAULT);
$valid_auth = hash('sha256', $valid_username.$valid_password_hash);

if ($_COOKIE['auth'] !== $valid_auth) {
    header('Location: log.deepseek.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <style>
        /* Add similar styles as login page */
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: #f0f2f5;
            text-align: center;
        }
        
        .welcome-container {
            background: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 20px;
        }
        
        .welcome-message {
            font-size: 24px;
            margin-bottom: 20px;
        }
        
        .logout-link {
            color: #1877f2;
            text-decoration: none;
            font-weight: 600;
        }
        
        .logout-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="welcome-container">
        <h1 class="welcome-message">Welcome, <?= htmlspecialchars($_COOKIE['username']) ?>!</h1>
        <a href="index.php?logout=1" class="logout-link">Logout</a>
    </div>
</body>
</html>