<?php
error_reporting(0);
ini_set('display_errors', 0 );

header('Access-Control-Allow-Origin: *');

$id= $_GET['id'];
if(empty($id)) {$id='wf4lrmc46i7mhug';}

$title = file_get_contents('https://www.dropbox.com/s/'.$id);
preg_match('/<title>Dropbox - (.*) - Simplify/', $title, $matches);
$title = urldecode($matches[1]);
$dropbox = 'https://dl.dropboxusercontent.com/s/'.$id.'/'.$title;

session_start();
if (isset($_GET["token"]) && isset($_SESSION[$_GET["token"]])) {
header('Content-Type: application/octet-stream');
$file = $_SESSION[$_GET["token"]]; //Get the filename
readfile($file);    
}
session_start();
$sid = session_id();
$path = $dropbox;
//$token = md5($path.$sid); //You need to use proper encryption. This is not secure at all.
$token = sha1(uniqid(time(), true));
$_SESSION[$token] = $path;
$url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?token='.$token;
//header('Location: ' . $url);
//echo '"url:""'. $url .'";';
//echo $url;
?>
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>test generate token by php</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
</head><body><center> <h2>test generate token by php </h2><h3> link download</h3><br/>
<a href="<?php echo $url;?>"><?php echo $url;?></a><br/><br/>
<video width="540"  height="320" controls poster="">
<source src="<?php echo $url;?>" type="video/mp4">
</video></center></body></html>
