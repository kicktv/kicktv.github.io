<?php
$url = isset($_GET['src']) ? htmlspecialchars($_GET['src']) : null;
$support_domain = 'www.mediafire.com';
if(empty($url)) {
$url = 'https://www.mediafire.com/file/8x5ol3r8wpb477a/small.mp4';}
if($url) {preg_match('@^(?:http.?://)?([^/]+)@i', $url, $matches);
$host = $matches[1];
if($host != $support_domain) {echo '<center><h2>Please input a valid mediafire url...</h2></center>';
exit;} }

function getHTML($url,$timeout)
{$ch = curl_init($url);
       curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]); 
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
       curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
       curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 
       curl_setopt($ch, CURLOPT_FAILONERROR, 1); // 
       return @curl_exec($ch);}
$html=getHTML($url,10);
preg_match('/aria-label="Download file"\n.+href="(.*)"/', $html, $matches);
$result = urldecode($matches[1]);
//echo $result;
header('Content-type: application/octet-stream');
header('Content-Disposition: attachment; filename='.basename($result));
readfile($result);
exit();




?>
