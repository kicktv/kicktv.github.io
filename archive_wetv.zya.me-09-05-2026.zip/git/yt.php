<?php
function getHTML($url,$timeout)
{$ch = curl_init($url); // initialize curl with given url
       curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]); // set  useragent
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // write the response to a variable
       curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // follow redirects if any
       curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); // max. seconds to execute
       curl_setopt($ch, CURLOPT_FAILONERROR, 1); // stop when it encounters an error
       return @curl_exec($ch);}
$url = "" .$_GET['id'];
//$pattern = '#^(?:https?://)?(?:www\.)?(?:youtu\.be/|youtube\.com(?:/embed/|/v/|/watch\?v=|/watch\?.+&v=))([\w-]{11})(?:.+)?$#x';
//preg_match($pattern, $url, $matches);
//echo $matches[1];
//$html=getHTML("https://clipmega.com/watch?v=".$matches[1],10);
$html=getHTML("https://clipmega.com/watch?v=".$url,10);
preg_match_all('/<source .*src=["|\']([^"|\']+)/i', $html, $matches);
foreach ($matches[1] as $key=>$value)
header('Content-Type: application/octet-stream');
readfile($value);
exit;
?>
