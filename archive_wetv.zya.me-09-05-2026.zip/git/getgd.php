<?php 
error_reporting(0);

$id = "1dl00Fz4CQeVRLHuRJbi3syf7HIrjg-Q-";
$link = "https://drive.google.com/uc?export=download&id=$id";
$userAgent = $_SERVER['HTTP_USER_AGENT'];


$cookie = "cookies.txt"; 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$link);
curl_setopt ($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt ($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
curl_setopt($ch, CURLOPT_HEADER  ,1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER  ,1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$output = curl_exec($ch);
curl_close($ch); 



$cookie = "cookies.txt"; 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$link);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
curl_setopt($ch, CURLOPT_HEADER  ,1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER  ,1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$output = curl_exec($ch);
curl_close($ch); 

$start = explode('confirm=',$output);
$end = explode('&amp;id',$start[1]);
$confirm = $end[0];
$gd = "https://drive.google.com/uc?export=download&confirm=$confirm&id=$id";
//echo $gd;
header('Content-type: application/octet-stream');
readfile('https://drive.google.com/uc?export=download&confirm=0MUZ&id=1dl00Fz4CQeVRLHuRJbi3syf7HIrjg-Q-');
?>
