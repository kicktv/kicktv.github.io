<?php
header('Location: http://flaxtv.blogspot.com/2022/09/tv5monde-maghreb-orient-live.html');
exit();
?>