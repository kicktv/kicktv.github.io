<?php  
$to=$_POST['to'];
$subject=$_POST['subject'];
$message=$_POST['message'];
$from="mydomain@mail.com";
$headers="from:.$from";
mail($to, $subject, $message, $headers);
if ($_POST['submit']) 
?>
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>Send Free Email Online</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style>img[alt="www.000webhost.com"]{display:none;}</style>
<style  type="text/css">
html,body {height:100%; width:100%; padding:0px; margin:0px;}
.title {padding:0px; margin:0px; background-color: #02C54C; color: #ffffff;
width: 100%; height: 60px; line-height: 55px;}
.button {background-color: #02C54C;border: none;color: #ffffff;padding: 15px 32px;
text-align: center;text-decoration: none;
display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer;width: 98%;}
.textinput {width: 98%; min-height:120px; outline: none;resize: none; border: 1px solid #000;}
.bat {width: 360px; height:30px;  border: 1px solid #000;}
</style></head><body>
<center> <h1 class="title"> Send Free Email Online </h1>
<form  method="post"  action="<?php echo $PHP_SELF?>">
<h1>email adress: </h1><input  class="bat"  type="text" name="to">
<h1>subject: </h1><input class="bat"  type="text" name="subject">
<h1>text message: </h1><textarea  class="textinput" name="message"></textarea><br>
<input  type="submit"  class="button" name="submit"  value="send">
</form></center></body></html>
