<?php
header('Access-Control-Allow-Origin: *');
function getHTML($url,$timeout,$cookie=null)
{$ch = curl_init($url); // initialize curl with given url
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]); // set  useragent
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // write the response to a variable
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // follow redirects if any
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); // max. seconds to execute
curl_setopt($ch, CURLOPT_FAILONERROR, 1); // stop when it encounters an error
curl_setopt($ch, CURLOPT_COOKIEFILE,'');
if($cookie) curl_setopt($ch, CURLOPT_COOKIE, $cookie);
return @curl_exec($ch);}
//$url = 'http://www.flaxtv.ga/';
$url = isset($_GET['url']) ? htmlspecialchars($_GET['url']) : null;
if(empty($url)) { $url = 'http://testhtmlonline.blogspot.com/'; }
$html=getHTML($url,10);
echo htmlspecialchars($html);
?>
