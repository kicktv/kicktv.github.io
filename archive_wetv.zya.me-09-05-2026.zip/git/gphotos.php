<?php
$userAgent = $_SERVER['HTTP_USER_AGENT'];
$url = "" .$_GET['src'];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_REFERER, "");
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt( $ch, CURLOPT_USERAGENT, $userAgent );
$content = curl_exec($ch);
curl_close($ch);
//echo htmlspecialchars($content);
$start = explode('"https://video-',$content);
$end = explode('",',$start[1]);
$file = "https://video-".$end[0]; 
header('Content-Type: application/octet-stream');
readfile($file);
exit;
?>
