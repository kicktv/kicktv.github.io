<?php
//How to stop access of a PHP file from other sites
$yoursite = "html-editor.tk"; //Your site url without http://
$yoursite2 = "www.html-editor.tk"; //Type your domain with www. this time
$referer = $_SERVER['HTTP_REFERER'];
//Check if browser sends referrer url or not
if ($referer == "") { //If not, set referrer as your domain
$domain = $yoursite;
} else {
$domain = parse_url($referer); //If yes, parse referrer
}
if($domain['host'] == $yoursite || $domain['host'] == $yoursite2) {
//Run your image generation code
} else {echo 'protect domain';
 //echo '<script>if(window==window.top) document.location="http://www.flaxtv.ga/2017/02/tele-maroc-live.html"</script>';
 //header("Location: http://www.flaxtv.ga/2017/02/tele-maroc-live.html");
exit(); //Stop running the script
}    
?> 
<!DOCTYPE html><html><head><meta charset="utf-8">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>tele maroc live </title>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style  type="text/css">
html,body {height:100%; width:100%; padding:0; margin:0; }
iframe {height:100%;width:100%; padding:0; margin:0;position:fixed;}</style>
</head><body><iframe  id="ap" src="archive.php"
allowtransparency="true" frameborder="0" width="100%"  height="100%"></iframe></body></html>

