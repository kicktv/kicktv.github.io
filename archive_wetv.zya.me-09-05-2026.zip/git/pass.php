<?php
//قم بتغيير كلمة السر الحالية الى كلمة سر اخرى بتشفير sha1 كلمة السر الحالية هي "123456"'
//$password = '7c4a8d09ca3762af61e59520943dc26494f8941b';
$password='0000';
session_start();
if(!isset($_SESSION['login'])){$_SESSION['login']=false;}
if(isset($_POST['password']))
{if($_POST['password']==$password){$_SESSION['login']=true;}
else {die ('<br><br><center><h2>Incorrect password');}}if(!$_SESSION['login']):
?>
<!DOCTYPE html><html lang="en">
<head><meta charset="utf-8">
<title>Login</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style type="text/css">
body {background-color:#fff;}.btn:hover {background-color: #fff;color:#0600ff;}
.form-signin .form-control {position: relative;height: auto;
-webkit-box-sizing: border-box;-moz-box-sizing: border-box;
box-sizing: border-box; padding: 10px; font-size: 16px; margin-bottom: 3px; 
border:solid #0600ff 1px; width:400px;height:40px;}
@media only screen and (max-width:500px) {.form-signin .form-control{width:98%; height:35px;}}
button{background-color:#0600ff;width:400px;height:40px; line-height: 0px;
border: solid 1px; color:azure;font-size:20px;}
@media only screen and (max-width:500px) {button{width:98%; height:35px;}}
</style></head><body><center><h2>You need to login</h2>
<form class="form-signin" action="" method="post">
<input class="form-control" type="password" placeholder="Enter Your Password" name="password"/><br/>
<button class="btn btn-lg btn-primary btn-block" type="submit" name="submit" value="submit">Login</button>
</form></center></body></html>

<?php
exit();
endif;
?>
<!-- 
here put your code html 
<h1> test code html </h1>
-->
