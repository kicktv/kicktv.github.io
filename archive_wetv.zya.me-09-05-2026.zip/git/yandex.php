<?php 
$url = ''.$_GET["src"];
if(empty($url)) {$url = 'https://yadi.sk/i/DlBKi9atbeVcSg';}
$api = 'https://cloud-api.yandex.net:443/v1/disk/public/resources/download?public_key='.$url;
$get = file_get_contents($api);
$json = json_decode($get);
$video = $json->href;
//echo $video;
$headers = get_headers($video,true);
$file = $headers['Location'];
header('Content-type: application/octet-stream');
readfile($file);
?>
