<?php
function getHTML($url,$timeout)
{$ch = curl_init($url); // initialize curl with given url
       curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]); // set  useragent
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // write the response to a variable
       curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // follow redirects if any
       curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); // max. seconds to execute
       curl_setopt($ch, CURLOPT_FAILONERROR, 1); // stop when it encounters an error
       return @curl_exec($ch);}
$link = $_GET["id"];
if(empty($link)) {$link = '2yh8mbxypw125uj7mejjz6fodi38l9w0';}
$part = explode("/", $link);
$last = end($part);
$box = "https://app.box.com/s/$last";
$html=getHTML($box,10);
preg_match('/"itemID":(.*),"itemType/', $html, $matches);
$videoUrl = "https://m.box.com/file/$matches[1]/download?shared_link=$box";
//echo $videoUrl;
?>
<!-- START HTML CODE -->
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>app.box</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style type="text/css">
html,body {height:100%; width:100%; padding:0px; margin:0px;}
video {object-fit: fill; position:fixed;height:100%;width:100%; padding:0px; margin:0px;}
</style></head><body>
<video width="100%" height="100%"  controls>
<source src="<?php echo $videoUrl ;?>" type="video/mp4"></video>
</body></html>

