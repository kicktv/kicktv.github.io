<?php
header('Access-Control-Allow-Origin: *');
if(!empty($_GET['page'])){
$page=file_get_contents($_GET['page']);
echo htmlspecialchars($page);
}
else{
?>
<html dir="rtl"><head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>test</title></head><body>
<iframe id="hello" width="100%" height="100%" name="Iframe1" src="<?php echo $page;?>"></iframe>
</body></html>
<?php } ?> 
