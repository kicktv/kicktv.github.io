<?php
$video = "https://kicktv.github.io/html-editor/videos/sintel.mp4";
header('Content-type: application/octet-stream');
readfile($video);
?>
