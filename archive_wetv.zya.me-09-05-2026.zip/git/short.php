<?php
if($_POST){
$url = $_POST['url'];
$asname = $_POST['asname'];
$name = basename($asname);
list($txt, $ext) = explode(".", $name);
$name = $txt;
$name = $name.".php".$ext;
$code = "<?php
header('Location: $url');
exit();
?>";
$upload = file_put_contents("$name",$code); } ?>
<!DOCTYPE html><html lang="en">
<head><meta charset="utf-8">
<title>URL Shortener</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style type="text/css">
body {background-color:#fff;}.btn:hover {background-color: #fff;color:#0600ff;}
.form-signin .form-control {position: relative;height: auto;
-webkit-box-sizing: border-box;-moz-box-sizing: border-box;
box-sizing: border-box; padding: 10px; font-size: 16px; margin-bottom: 3px; 
border: solid black 1px; width: 100%;}
button{background-color:#0600ff; width: 100%; height: 50px; line-height: 0px;
border: solid 1px; color:azure;font-size:20px;}
img[alt="www.000webhost.com"]{display:none;}
</style></head><body><center><br><br><br><br><h2> URL Shortener from URL</h2><br><br>
<form class="form-signin" action="" method="post">
<input id="url" class="form-control" size="100" type="text" placeholder="Paste the URL to be shortened" name="url" /><br/>
<input id="name" class="form-control" size="100" type="text" placeholder="File name" name="asname"><br/>
<button id="btn_save" class="btn btn-lg btn-primary btn-block" type="submit" value="submit">Shortener URL </button>
</form><br/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="https://kicktv.github.io/save.js"></script>
<?php
//check success
if($upload) 
$link = "ShortURL:<a href='http://". $_SERVER['SERVER_NAME']."/git/".$name."' target='_blank'>
http://". $_SERVER['SERVER_NAME']."/git/".$name."</a>";
echo substr($link, 0, strrpos($link, "."));?>
</center></body></html>
