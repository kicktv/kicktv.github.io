<?php  
$link = ''  .$_GET["src"];
$part = explode("/", $link);
$last = end($part);
//echo $last;
$url = 'https://m.ok.ru/video/'.$last;
$test = file_get_contents($url);
$start = strpos($test, 'https://m.ok.ru/dk?st.cmd=moviePlaybackRedirect&');
$end = strpos($test, '" data-',$start);
$test = substr($test, $start,$end - $start);
//echo $test ; ?>
<!-- START HTML -->
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title> api video ok.ru </title><style type="text/css">
html,body {height:100%;width:100%;padding:0px; margin:0px;}
video {object-fit:fill;}
#ap{position:fixed;height:100%;width:100%;padding:0px; margin:0px;}
img[alt="www.000webhost.com"]{display:none;}
</style></head><body>
<video id="ap" autoplay controls   preload="auto" width="100%" height="100%"
src="<?php echo $test ;?>" type="video/mp4"  poster=""></video></body></html>
<!--
https://wikapp.herokuapp.com/ok.php?src=https://ok.ru/video/1026124417540?film-safina-nouh
https://wikapp.herokuapp.com/ok.php?src=907996957375
https://wikapp.herokuapp.com/ok.php?src=1228785322702
https://wikapp.herokuapp.com/ok.php?src=871337560767
https://wikapp.herokuapp.com/ok.php?src=1026124417540?film-safina-nouh
-->
