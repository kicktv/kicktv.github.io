<?php
// display pdf in browser
//https://wikapp.herokuapp.com/pdf.php?src=https://www.dopdfwn.com/cacnoscana/scanoanya/Sh0046.pdf
header('Content-type: application/pdf');
$url = isset($_GET['src']) ? htmlspecialchars($_GET['src']) : null;
if(empty($url)) {$url = 'https://drive.google.com/uc?id=10qbZMskN_xdOSFuIOzRmy4yaAGCKME2I&export=download/al-khaima.pdf'; }
//$link = '' .$_GET["src"]);
readfile($url);
?>

