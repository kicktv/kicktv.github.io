<?php
$url = "https://sendit.cloud/k0oksz3jf7cd";
$link = file_get_contents($url);
$start = explode('source src="',$link);
$end = explode('" type',$start[1]);
$video = $end[0];
?>
 
<head>
  <link href="https://vjs.zencdn.net/7.8.3/video-js.css" rel="stylesheet" />
 
  <!-- If you'd like to support IE8 (for Video.js versions prior to v7) -->
  <script src="https://vjs.zencdn.net/ie8/1.1.2/videojs-ie8.min.js"></script>
</head>
 
<body>
  <video
    id="my-video"
    class="video-js"
    controls
    preload="auto"
    width="640"
    height="264"
    poster="MY_VIDEO_POSTER.jpg"
    data-setup="{}"
  >
    <source src="<?php echo $video; ?>" type="video/mp4" />
    <p class="vjs-no-js">
      To view this video plea<?php echo $video; ?>se enable JavaScript, and consider upgrading to a
      web browser that
      <a href="<?php echo $video; ?>" target="_blank"
        >supports HTML5 video</a
      >
    </p>
  </video>
 
  <script src="https://vjs.zencdn.net/7.8.3/video.js"></script>
</body>
