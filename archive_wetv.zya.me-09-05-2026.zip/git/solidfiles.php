<?php
$url = isset($_GET['url']) ? htmlspecialchars($_GET['url']) : null;
$support_domain = 'www.solidfiles.com';
if(empty($url)) {
$url = 'https://www.solidfiles.com/v/38Geeqr3wXpaP';}
if($url) {preg_match('@^(?:http.?://)?([^/]+)@i', $url, $matches);
$host = $matches[1];
if($host != $support_domain) {echo '<center><h2>Please input a valid solidfiles url...</h2></center>';
exit;} }

function getHTML($url,$timeout)
{$ch = curl_init($url);
       curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]); 
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
       curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
       curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 
       curl_setopt($ch, CURLOPT_FAILONERROR, 1); // 
       return @curl_exec($ch);}
$html=getHTML($url,10);
preg_match('/"streamUrl":"(.*)"/', $html, $matches);
$result = urldecode($matches[1]);
//echo $result;
header('Content-type: application/octet-stream');
readfile($result);
?>
