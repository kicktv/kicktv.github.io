<?php
$id= $_GET['id'];
$gdrive = "https://www.googleapis.com/drive/v3/files/" .$id. "?alt=media&key=AIzaSyAgJNu0Gt0vAFVCN3g0fqlRrksIrscRiLM";

session_start();
if (isset($_GET["token"]) && isset($_SESSION[$_GET["token"]])) {
header('Content-Type: application/octet-stream');
$file = $_SESSION[$_GET["token"]]; //Get the filename
readfile($file);    
}
session_start();
$sid = session_id();
$path = $gdrive;
//$hash = md5($path.$sid); //You need to use proper encryption. This is not secure at all.
$token = sha1(uniqid(time(), true));
$_SESSION[$token] = $path;
$url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?token='.$token;
//echo $url;
header('Location: ' . $url);
?>
