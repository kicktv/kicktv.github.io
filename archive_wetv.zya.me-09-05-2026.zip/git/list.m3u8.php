<?php
//https://www.startimes.com/f.aspx?t=38329366

$url = "http://159.89.4.93/hls/ch1.m3u8";
$json = file_get_contents($url);
$test = str_replace("ch1-","http://159.89.4.93/hls/ch1-" ,$json);
echo $test;

?>
