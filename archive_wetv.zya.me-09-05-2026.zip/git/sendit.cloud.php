<?php
error_reporting(0);
$url = "https://sendit.cloud/k0oksz3jf7cd";
$link = file_get_contents($url);
$start = explode('source src="',$link);
$end = explode('" type',$start[1]);
$video = $end[0];

header('Content-Description: File Transfer');
header('Content-type: application/octet-stream');
header('Content-Transfer-Encoding: chunked');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Accept-Ranges: bytes');
header('Content-Disposition: inline');
header('Content-Transfer-Encoding: Binary');
header('Content-Disposition: attachment; filename='.basename($video));
readfile($video);
exit();
?>
