<?php
function getHTML($url,$timeout)
{$ch = curl_init($url); // initialize curl with given url
       curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]); // set  useragent
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // write the response to a variable
       curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // follow redirects if any
       curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); // max. seconds to execute
       curl_setopt($ch, CURLOPT_FAILONERROR, 1); // stop when it encounters an error
       return @curl_exec($ch);}
$url = 'https://fors4-g.herokuapp.com/'.$_GET["id"].'/change_file_name.html';
$html=getHTML($url,10);
$start = explode('https://fors4-g.herokuapp.com/paste.php?id=',$html);
$end = explode('"',$start[1]);
$video = "https://fors4-g.herokuapp.com/d/".$end[0].".mp4"; 
header("Location: http://www.html-editor.tk/video?src=".$video);
exit();
//echo $video
?>
<!-- START HTML
<!DOCTYPE html><html lang="en"><head>
<meta charset="utf-8">
<title>api 4shared</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style  type="text/css">
html,body { height:100%; width:100%; padding:0; margin:0; }
#my-video{position:fixed; height:100%;width:100%; padding:0; margin:0;}
img[alt="www.000webhost.com"]{display:none;}
video {height:100%;width:100%; padding:0; margin:0;position:fixed;}
video {object-fit: fill;}</style>
 <script src="https://zoptv.github.io/jwplayer7/jwplayer7.js" type="text/javascript"></script>
<script>jwplayer.key="XYS/ica6YQUMq9rC6J2E77obUFoIPLeM";</script>
</head><body><div id="my-video"></div>
<script type="text/javascript">jwplayer("my-video").setup({ file:"<?php echo $video;?>" ,type: "video/mp4",
logo: {file: "https://archive.org/download/logkhaled/khaledtv.png", position: 'top.left', hide: 'true', margin: '2', 
linktarget: '_blank',hide: 'false', over: '70',out: '', link: "http://www.khaledtv.tk"},
title: 'www.khaledtv.tk',autostart: "false",width: "100%",height: "100%",
stretching: "exactfit",primary:"flash"});</script>
<!-- <video  width="100%"  height="100%" autoplay controls  src="" 
type="video/mp4" poster="http://www.flaxtv.ga://www.drivetv.ga/mediafire/mediafire.png"></video> -->
</body></html> -->
<!--
https://wikapp.herokuapp.com/4shared.php?id=WctLKA1oba
-->
