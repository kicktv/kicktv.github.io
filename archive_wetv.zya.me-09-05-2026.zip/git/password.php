<?php
//قم بتغيير كلمة السر الحالية الى كلمة سر اخرى بتشفير sha1 كلمة السر الحالية هي "123456"'
//$password = '7c4a8d09ca3762af61e59520943dc26494f8941b';
$username='khaled';
$password='0000';
session_start();
if(!isset($_SESSION['login'])){$_SESSION['login']=false;}
if(isset($_POST['username']) && isset($_POST['password']))
{if($_POST['username']==$username && $_POST['password']==$password){$_SESSION['login']=true;}
else {die ('<br><br><center><h2>Incorrect username or password');}}if(!$_SESSION['login']):
?>
<!DOCTYPE html><html lang="en">
<head><meta charset="utf-8">
<title>Login</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style type="text/css">
body {background-color:#fff;}.btn:hover {background-color: #fff;color:#0600ff;}
.form-signin .form-control {position: relative;height: auto;
-webkit-box-sizing: border-box;-moz-box-sizing: border-box;
box-sizing: border-box; padding: 10px; font-size: 16px; margin-bottom: 3px; 
border:solid #0600ff 1px; width:400px;height:40px;}
@media only screen and (max-width:500px) {.form-signin .form-control{width:98%; height:35px;}}
button{background-color:#0600ff;width:400px;height:40px; line-height: 0px;
border: solid 1px; color:azure;font-size:20px;}
@media only screen and (max-width:500px) {button{width:98%; height:35px;}}
</style></head><body><center><h2>You need to login</h2>
<form class="form-signin" action="" method="post">
<input class="form-control" type="text" placeholder="Enter Your username" name="username"/><br/>
<input class="form-control" type="password" placeholder="Enter Your Password" name="password"/><br/>
<button class="btn btn-lg btn-primary btn-block" type="submit" name="submit" value="submit">Login</button>
</form></center></body></html>

<?php
exit();
endif;
?>

<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>test video via input </title>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"/>  
<style  type="text/css">
#box{position:relative;width:70%;margin:0}
#search-form {height: 40px; border: 1px solid #999; -webkit-border-radius: 5px; -moz-border-radius: 5px;
border-radius: 5px; background-color: #fff; overflow: hidden;}
#bat{font-size:14px;color:#ddd;border-width:0;border:1px solid #4d90fe;background:transparent}
#box input[type="text"]{width:90%;padding:11px 0 12px 1em;color:#333;outline:none}
#btn{position:absolute;top:0;right:0;height:42px;width:80px;font-size:14px;color:#fff;text-align:center;line-height:42px;
border-width:0;background-color:#4d90fe;-webkit-border-radius:0 5px 5px 0;-moz-border-radius:0 5px 5px 0;
border-radius:0 5px 5px 0;cursor:pointer}
video {object-fit:fill; width:800px; height:404px;  border: 1px solid #000; z-index:1;}
@media only screen and (max-width:980px) {video{width:99%;height:auto;}}
</style></head><body><center><h1>Responsive Input Box Button </h1><div id="box">
<form action="javascript:loadVideo()">
<input id="bat"  type="text"  value="https://kicktv.github.io/html-editor/videos/sintel.mp4" required>
<button id="btn" type="submit">Play</button></form></div>
<br> <video  id="app"  width="100%"  height="100%"   controls poster="" src=""></video></center>
<script type="text/javascript">function loadVideo() {var vid = document.getElementById("app");
vid.src = document.getElementById("bat").value;}</script></body></html>
