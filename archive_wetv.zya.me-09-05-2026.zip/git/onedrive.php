<?php
$url = isset($_GET['id']) ? htmlspecialchars($_GET['id']) : null;
$part = explode("/", $url);
$last = end($part);
if(empty($last)) {$last = 's!AuLdiinudnn9gQK8YUbc_c68kOMj';}
$url = "https://api.onedrive.com/v1.0/shares/".$last."/root/content";
header('Content-type: application/octet-stream');
readfile($url);
?>
