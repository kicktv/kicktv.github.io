<?php
header('Location: http://flaxtv.blogspot.com/2016/03/MBC2-Live.html');
exit();
?>