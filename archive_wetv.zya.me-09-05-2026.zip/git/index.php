<?php
//if ( strstr( $_SERVER['HTTP_REFERER'], 'html-editor.tk' ) ) {}
//else {header("location: http://www.flaxtv.ga/"); }
echo '<center><h1>Welcome To My Website</h1><br><h1>' .$_SERVER['HTTP_HOST']. '</h1></center>';
?>
