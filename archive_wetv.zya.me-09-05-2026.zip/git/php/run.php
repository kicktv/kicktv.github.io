 <?php
if (isset($_POST['submit'])) {$submit = $_POST['area'];} eval("?> $code <?php ");
?>
