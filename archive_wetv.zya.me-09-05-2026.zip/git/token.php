<?php
session_start();
if (isset($_GET["video"]) && isset($_SESSION[$_GET["video"]])) {
header('Content-Type: application/octet-stream');
$file = $_SESSION[$_GET["video"]]; //Get the filename
readfile($file);    
}
session_start();
$sid = session_id();
$expire = time() + 3 * 60; // 3*60=3minutes
//$path = 'https://raw.githubusercontent.com/kicktv/html-editor/gh-pages/videos/sintel.mp4';
//$path = 'https://raw.githubusercontent.com/kicktv/html-editor/gh-pages/video.mp4';
$path = 'https://wetv.gitlab.io/1.mp4';
$video = $path.$sid;
//$token = base64_encode($video.$expire.random_bytes(64));
$token = md5($video.$expire);
//$token = md5($video);
$_SESSION[$token] = $path;
$url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?video='.$token;
echo $url;
?>
