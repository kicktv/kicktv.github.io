<?php
//https://claude.ai/chat/aff31146-b619-41fc-9f31-1f1402e75a80

// Enable error reporting for debugging (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set response header to JSON
header('Content-Type: application/json');

// CORS headers (adjust as needed for your domain)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

class SecureFileUploader {
    private $uploadDir = 'uploads/';
// private $maxFileSize = 15 * 1024 * 1024; // 15MB
    private $maxFileSize = 300 * 1024 * 1024; // 300 MB
    private $allowedTypes = [
        // Images
        'image/jpeg' => 'jpg',
        'image/jpg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        
        // Videos
        'video/mp4' => 'mp4',
        'video/avi' => 'avi',
        'video/x-msvideo' => 'avi',
        'video/x-matroska' => 'mkv',
        
        // Audio
        'audio/mp3' => 'mp3',
        'audio/mpeg' => 'mp3',
        'audio/wav' => 'wav',
        
        // Documents
        'text/plain' => 'txt',
        'application/pdf' => 'pdf'
    ];
    
    private $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'mp4', 'avi', 'mkv', 'mp3', 'wav', 'txt', 'pdf'];

    public function __construct() {
        // Create upload directory if it doesn't exist
        if (!file_exists($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }
        
        // Create .htaccess for security
        $this->createHtaccess();
    }

    private function createHtaccess() {
        $htaccessPath = $this->uploadDir . '.htaccess';
        if (!file_exists($htaccessPath)) {
            $content = "# Prevent PHP execution in uploads directory\n";
            $content .= "php_flag engine off\n";
            $content .= "AddType text/plain .php .php3 .phtml .pht\n";
            $content .= "RemoveHandler .php .phtml .php3 .php4 .php5 .php6\n";
            file_put_contents($htaccessPath, $content);
        }
    }

    public function handleRequest() {
        try {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Only POST requests allowed');
            }

            // Handle delete request
            if (isset($_POST['action']) && $_POST['action'] === 'delete') {
                return $this->deleteFile();
            }

            // Handle upload request
            $method = $_POST['method'] ?? '';
            
            switch ($method) {
                case 'file':
                    return $this->handleFileUpload();
                case 'url':
                    return $this->handleUrlUpload();
                default:
                    throw new Exception('Invalid upload method');
            }
        } catch (Exception $e) {
            return $this->jsonResponse(false, $e->getMessage());
        }
    }

    private function handleFileUpload() {
        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('No file uploaded or upload error occurred');
        }

        $file = $_FILES['file'];
        
        // Validate file
        $this->validateFile($file['tmp_name'], $file['name'], $file['size'], $file['type']);
        
        // Generate secure filename
        $filename = $this->generateSecureFilename($file['name']);
        $filePath = $this->uploadDir . $filename;
        
        // Move uploaded file
        if (!move_uploaded_file($file['tmp_name'], $filePath)) {
            throw new Exception('Failed to save uploaded file');
        }
        
        return $this->jsonResponse(true, 'File uploaded successfully', [
            'filename' => $filename,
            'original_name' => $file['name'],
            'file_size' => $this->formatFileSize($file['size'])
        ]);
    }

    private function handleUrlUpload() {
        $url = $_POST['url'] ?? '';
        
        if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
            throw new Exception('Invalid URL provided');
        }

        // Validate URL scheme
        $parsedUrl = parse_url($url);
        if (!in_array($parsedUrl['scheme'], ['http', 'https'])) {
            throw new Exception('Only HTTP and HTTPS URLs are allowed');
        }

        // Create context with timeout and user agent
        $context = stream_context_create([
            'http' => [
                'timeout' => 30,
                'user_agent' => 'Mozilla/5.0 (compatible; SecureUploader/1.0)',
                'follow_location' => true,
                'max_redirects' => 3
            ]
        ]);

        // Get file headers first to check size and type
        $headers = get_headers($url, 1, $context);
        if (!$headers) {
            throw new Exception('Unable to fetch file information from URL');
        }

        // Check if URL is accessible
        $statusCode = 0;
        if (isset($headers[0])) {
            preg_match('/HTTP\/\d\.\d\s+(\d+)/', $headers[0], $matches);
            $statusCode = intval($matches[1] ?? 0);
        }
        
        if ($statusCode < 200 || $statusCode >= 400) {
            throw new Exception('Unable to access the URL (HTTP ' . $statusCode . ')');
        }

        // Check content length
        $contentLength = $headers['Content-Length'] ?? $headers['content-length'] ?? 0;
        if (is_array($contentLength)) {
            $contentLength = end($contentLength);
        }
        
        if ($contentLength > $this->maxFileSize) {
            throw new Exception('Remote file exceeds maximum size limit of ' . $this->formatFileSize($this->maxFileSize));
        }

        // Get content type
        $contentType = $headers['Content-Type'] ?? $headers['content-type'] ?? '';
        if (is_array($contentType)) {
            $contentType = end($contentType);
        }
        
        // Remove charset info if present
        $contentType = explode(';', $contentType)[0];

        // Download the file
        $fileContent = file_get_contents($url, false, $context);
        if ($fileContent === false) {
            throw new Exception('Failed to download file from URL');
        }

        // Check actual file size
        $actualSize = strlen($fileContent);
        if ($actualSize > $this->maxFileSize) {
            throw new Exception('Downloaded file exceeds maximum size limit');
        }

        // Create temporary file for validation
        $tempFile = tempnam(sys_get_temp_dir(), 'upload_');
        file_put_contents($tempFile, $fileContent);

        // Extract filename from URL
        $urlPath = parse_url($url, PHP_URL_PATH);
        $originalFilename = basename($urlPath);
        if (empty($originalFilename) || strpos($originalFilename, '.') === false) {
            // Generate filename based on content type
            $extension = $this->getExtensionFromMimeType($contentType);
            $originalFilename = 'downloaded_file.' . $extension;
        }

        try {
            // Validate the downloaded file
            $this->validateFile($tempFile, $originalFilename, $actualSize, $contentType);
            
            // Generate secure filename
            $filename = $this->generateSecureFilename($originalFilename);
            $filePath = $this->uploadDir . $filename;
            
            // Move file to uploads directory
            if (!rename($tempFile, $filePath)) {
                throw new Exception('Failed to save downloaded file');
            }
            
            return $this->jsonResponse(true, 'File downloaded and uploaded successfully', [
                'filename' => $filename,
                'original_name' => $originalFilename,
                'file_size' => $this->formatFileSize($actualSize)
            ]);
            
        } finally {
            // Clean up temp file if it still exists
            if (file_exists($tempFile)) {
                unlink($tempFile);
            }
        }
    }

    private function validateFile($filePath, $originalName, $fileSize, $mimeType) {
        // Check file size
        if ($fileSize > $this->maxFileSize) {
            throw new Exception('File size exceeds maximum limit of ' . $this->formatFileSize($this->maxFileSize));
        }

        // Check file extension
        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        if (!in_array($extension, $this->allowedExtensions)) {
            throw new Exception('File type not allowed. Allowed types: ' . implode(', ', $this->allowedExtensions));
        }

        // Check MIME type
        $detectedMimeType = mime_content_type($filePath);
        if (!isset($this->allowedTypes[$mimeType]) && !isset($this->allowedTypes[$detectedMimeType])) {
            throw new Exception('Invalid file type detected');
        }

        // Additional security checks
        $this->performSecurityChecks($filePath, $originalName);
    }

    private function performSecurityChecks($filePath, $originalName) {
        // Check for dangerous file extensions in the name
        $dangerousExtensions = ['php', 'php3', 'php4', 'php5', 'phtml', 'pht', 'exe', 'bat', 'com', 'scr', 'vbs', 'js', 'jar'];
        $fileName = strtolower($originalName);
        
        foreach ($dangerousExtensions as $ext) {
            if (strpos($fileName, '.' . $ext) !== false) {
                throw new Exception('Potentially dangerous file type detected');
            }
        }

        // Check file signature (magic bytes) for common file types
        $fileHandle = fopen($filePath, 'rb');
        if ($fileHandle) {
            $magicBytes = fread($fileHandle, 20);
            fclose($fileHandle);
            
            // Basic magic byte validation for images
            $validSignatures = [
                'image/jpeg' => ["\xFF\xD8\xFF"],
                'image/png' => ["\x89PNG\r\n\x1A\n"],
                'image/gif' => ["GIF87a", "GIF89a"],
                'application/pdf' => ["%PDF-"]
            ];
            
            $detectedMimeType = mime_content_type($filePath);
            if (isset($validSignatures[$detectedMimeType])) {
                $isValid = false;
                foreach ($validSignatures[$detectedMimeType] as $signature) {
                    if (strpos($magicBytes, $signature) === 0) {
                        $isValid = true;
                        break;
                    }
                }
                if (!$isValid) {
                    throw new Exception('File signature does not match file type');
                }
            }
        }
    }

    private function generateSecureFilename($originalName) {
        // Get file extension
        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        
        // Generate unique filename
        $uniqueId = uniqid();
        $randomString = bin2hex(random_bytes(8));
        $timestamp = time();
        
        return $timestamp . '_' . $uniqueId . '_' . $randomString . '.' . $extension;
    }

    private function getExtensionFromMimeType($mimeType) {
        return $this->allowedTypes[$mimeType] ?? 'bin';
    }

    private function deleteFile() {
        $filename = $_POST['filename'] ?? '';
        
        if (empty($filename)) {
            throw new Exception('No filename provided');
        }

        // Sanitize filename (security check)
        $filename = basename($filename);
        $filePath = $this->uploadDir . $filename;

        if (!file_exists($filePath)) {
            throw new Exception('File not found');
        }

        if (!unlink($filePath)) {
            throw new Exception('Failed to delete file');
        }

        return $this->jsonResponse(true, 'File deleted successfully');
    }

    private function formatFileSize($bytes) {
        if ($bytes === 0) return '0 Bytes';
        
        $k = 1024;
        $sizes = ['Bytes', 'KB', 'MB', 'GB'];
        $i = floor(log($bytes) / log($k));
        
        return round($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
    }

    private function jsonResponse($success, $message, $data = []) {
        $response = [
            'success' => $success,
            'message' => $message
        ];
        
        if (!empty($data)) {
            $response = array_merge($response, $data);
        }
        
        return json_encode($response);
    }
}

// Initialize and handle the request
try {
    $uploader = new SecureFileUploader();
    echo $uploader->handleRequest();
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}
?>