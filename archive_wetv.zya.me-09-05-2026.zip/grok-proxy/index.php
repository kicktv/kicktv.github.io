<?php
// Enable error reporting for debugging (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// ---------------------------------------------------------------------
// CONFIG
// ---------------------------------------------------------------------
$PROXY_USER_AGENT = $_SERVER['HTTP_USER_AGENT'] ?? 'Mozilla/5.0 (compatible; ProxyMiniBrowser/1.0)';
$TIMEOUT          = 30;
$MAX_REDIRECTS    = 10;

// ---------------------------------------------------------------------
// Helper: unique session key for this "browser tab"
$tab_id = $_GET['tab'] ?? 'default';
if (!isset($_SESSION['tabs'][$tab_id])) {
    $_SESSION['tabs'][$tab_id] = [
        'cookies' => [],
        'history' => [],
    ];
}
$tab = &$_SESSION['tabs'][$tab_id];

// ---------------------------------------------------------------------
// Proxy request
// ---------------------------------------------------------------------
function proxy_request($url, $method = 'GET', $post_data = [], &$tab) {
    global $PROXY_USER_AGENT, $TIMEOUT, $MAX_REDIRECTS;

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_USERAGENT      => $PROXY_USER_AGENT,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_HEADER         => true,
        CURLOPT_TIMEOUT        => $TIMEOUT,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_COOKIE         => '', // we'll set manually
    ]);

    // Send cookies
    if (!empty($tab['cookies'])) {
        $cookie_str = http_build_query($tab['cookies'], '', '; ');
        curl_setopt($ch, CURLOPT_COOKIE, $cookie_str);
    }

    // POST
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    }

    $raw = curl_exec($ch);
    if (curl_error($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        return ['error' => $error];
    }

    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $headers_raw = substr($raw, 0, $header_size);
    $body        = substr($raw, $header_size);
    $info        = curl_getinfo($ch);
    curl_close($ch);

    // Parse headers
    $headers = [];
    foreach (explode("\r\n", $headers_raw) as $line) {
        if (strpos($line, ':') !== false) {
            [$k, $v] = explode(':', $line, 2);
            $headers[strtolower(trim($k))] = trim($v);
        }
    }

    // Store Set-Cookie
    if (isset($headers['set-cookie'])) {
        $cookies = is_array($headers['set-cookie']) ? $headers['set-cookie'] : [$headers['set-cookie']];
        foreach ($cookies as $cookie) {
            if (preg_match('/^([^=]+)=([^;]*)/', $cookie, $m)) {
                $tab['cookies'][$m[1]] = $m[2];
            }
        }
    }

    // Handle redirect
    if ($info['http_code'] >= 300 && $info['http_code'] < 400 && !empty($headers['location'])) {
        $location = $headers['location'];
        $parsed = parse_url($url);
        if ($location[0] === '/') {
            $location = $parsed['scheme'] . '://' . $parsed['host'] . $location;
        } elseif (!preg_match('#^https?://#i', $location)) {
            $location = $parsed['scheme'] . '://' . $parsed['host'] . dirname($parsed['path']) . '/' . $location;
        }
        if (--$MAX_REDIRECTS <= 0) return ['error' => 'Too many redirects'];
        return proxy_request($location, $method, $post_data, $tab);
    }

    return [
        'body'    => $body,
        'headers' => $headers,
        'info'    => $info,
    ];
}

// ---------------------------------------------------------------------
// MAIN LOGIC
// ---------------------------------------------------------------------
$target_url = '';
$message    = '';

if (!empty($_GET['url']) || $_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw_url = $_POST['url'] ?? $_GET['url'];
    $target_url = filter_var($raw_url, FILTER_VALIDATE_URL);

    if ($target_url) {
        // Save to history
        if (!in_array($target_url, $tab['history'])) {
            $tab['history'][] = $target_url;
            if (count($tab['history']) > 50) array_shift($tab['history']);
        }

        $method = $_SERVER['REQUEST_METHOD'];
        $post_data = ($method === 'POST') ? $_POST : [];

        $result = proxy_request($target_url, $method, $post_data, $tab);

        if (isset($result['error'])) {
            $message = '<p class="error">Proxy Error: ' . htmlspecialchars($result['error']) . '</p>';
        } else {
            $content_type = $result['info']['content_type'] ?? 'text/html';
            $body = $result['body'];

            // Rewrite HTML
            if (stripos($content_type, 'text/html') !== false) {
                $base = parse_url($target_url);
                $base_url = $base['scheme'] . '://' . $base['host'] . (isset($base['port']) ? ':' . $base['port'] : '');
                $base_path = isset($base['path']) ? dirname($base['path']) . '/' : '/';

                $resolve = function($rel) use ($base_url, $base_path) {
                    if (!$rel || preg_match('#^https?://#i', $rel) || preg_match('#^data:#i', $rel) || preg_match('#^//#', $rel)) {
                        return $rel;
                    }
                    if ($rel[0] === '/') return $base_url . $rel;
                    return $base_url . $base_path . $rel;
                };

                // Fix: Correctly rebuild attribute
                $body = preg_replace_callback(
                    '#(href|src)=["\']([^"\']+)["\']#i',
                    function($m) use ($resolve, $tab_id) {
                        $attr = strtolower($m[1]);
                        $url  = $m[2];
                        $abs  = $resolve($url);
                        if ($abs === $url) return $m[0]; // skip if unchanged
                        return $attr . '="' . htmlspecialchars($abs, ENT_QUOTES) . '?url=' . urlencode($abs) . '&tab=' . $tab_id . '"';
                    },
                    $body
                );

                // CSS url()
                $body = preg_replace_callback(
                    '#url\((["\']?)(.+?)\1\)#i',
                    function($m) use ($resolve) {
                        $url = $m[2];
                        $abs = $resolve($url);
                        return 'url(' . $m[1] . $abs . $m[1] . ')';
                    },
                    $body
                );

                // Forms
                $body = preg_replace_callback(
                    '#<form([^>]*action=["\'])([^"\']+)(["\'][^>]*)>#i',
                    function($m) use ($resolve, $tab_id) {
                        $abs = $resolve($m[2]);
                        return '<form' . $m[1] . $abs . $m[3] . ' onsubmit="return proxyForm(this, \'' . addslashes($tab_id) . '\');">';
                    },
                    $body
                );

                // Inject JS
                $inject_js = <<<JS
<script>
function proxyForm(f, tab) {
    var action = f.action || '';
    if (!action) return true;
    var sep = action.includes('?') ? '&' : '?';
    f.action = action + sep + 'tab=' + encodeURIComponent(tab);
    return true;
}
</script>
JS;
                $body = preg_replace('#</head>#i', $inject_js . "\n</head>", $body, 1);
            }

            // Output
            if (!headers_sent()) {
                header('Content-Type: ' . $content_type);
            }
            echo $body;
            exit;
        }
    } else {
        $message = '<p class="error">Invalid URL. Must include http:// or https://</p>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Proxy Mini-Browser</title>
    <style>
        :root{--primary:#0066cc;--bg:#f8f9fa;--text:#212529;}
        body{margin:0;font-family:Arial,sans-serif;background:var(--bg);color:var(--text);display:flex;flex-direction:column;min-height:100vh;}
        header,footer{background:var(--primary);color:#fff;padding:0.8rem 1rem;}
        header h1{font-size:1.2rem;margin:0;}
        .container{max-width:960px;margin:auto;padding:1rem;flex:1;}
        .address-bar{display:flex;gap:0.5rem;margin-bottom:1rem;}
        .address-bar input[type=text]{flex:1;padding:0.6rem;font-size:1rem;border:1px solid #ccc;border-radius:4px;}
        .address-bar button{padding:0 1.2rem;background:var(--primary);color:#fff;border:none;border-radius:4px;cursor:pointer;font-weight:bold;}
        .address-bar button:hover{background:#0055aa;}
        .tabs{display:flex;gap:0.5rem;margin-bottom:0.5rem;overflow-x:auto;}
        .tabs a{padding:0.4rem 0.8rem;background:#fff;border:1px solid #ddd;border-radius:4px 4px 0 0;text-decoration:none;color:var(--text);white-space:nowrap;}
        .tabs a.active{background:var(--primary);color:#fff;border-color:var(--primary);}
        .content{border:1px solid #ddd;background:#fff;padding:1rem;min-height:60vh;border-radius:0 4px 4px 4px;}
        .error{color:#d9534f;background:#ffe6e6;padding:0.8rem;border-radius:4px;margin:1rem 0;}
        @media (max-width:600px){
            .address-bar{flex-direction:column;}
            .address-bar button{width:100%;}
        }
    </style>
</head>
<body>
<header><h1>Proxy Mini-Browser</h1></header>
<div class="container">

    <!-- Tabs -->
    <div class="tabs">
        <?php
        $active = $tab_id;
        foreach (array_keys($_SESSION['tabs'] ?? []) as $t) {
            $class = ($t === $active) ? 'active' : '';
            echo "<a href=\"?tab=$t\" class=\"$class\">Tab $t</a>";
        }
        $new_id = substr(bin2hex(random_bytes(4)), 0, 6);
        echo "<a href=\"?tab=$new_id\">+ New</a>";
        ?>
    </div>

    <!-- Address Bar -->
    <form method="get" class="address-bar">
        <input type="text" name="url" placeholder="https://example.com" value="<?=htmlspecialchars($target_url)?>" required>
        <input type="hidden" name="tab" value="<?=htmlspecialchars($tab_id)?>">
        <button type="submit">Go</button>
    </form>

    <?php if ($message) echo $message; ?>

    <!-- Content -->
    <div class="content">
        <?php if ($target_url && !$message): ?>
            <iframe src="?url=<?=urlencode($target_url)?>&tab=<?=htmlspecialchars($tab_id)?>" 
                    style="width:100%;height:80vh;border:none;" 
                    sandbox="allow-forms allow-modals allow-popups allow-scripts allow-same-origin">
            </iframe>
        <?php else: ?>
            <p style="text-align:center;color:#777;margin-top:3rem;">
                Enter a URL to start browsing through the proxy.<br>
                <small>Supports login forms, cookies, and sessions per tab.</small>
            </p>
        <?php endif; ?>
    </div>
</div>

<footer><small>PHP Proxy Mini-Browser – Demo Only</small></footer>
</body>
</html>