const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const bodyParser = require('body-parser');
const path = require('path');
const url = require('url');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.post('/proxy', async (req, res) => {
  try {
    const targetUrl = req.body.url;
    
    // Basic URL validation
    if (!targetUrl || !targetUrl.match(/^https?:\/\/[^\s$.?#].[^\s]*$/)) {
      return res.status(400).json({ error: 'Invalid URL. Please enter a valid URL including http:// or https://' });
    }

    // Fetch the remote content
    const response = await axios.get(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });

    // Parse the HTML
    const $ = cheerio.load(response.data);
    
    // Get the base URL for resolving relative URLs
    const baseUrl = new URL(targetUrl).origin;
    
    // Modify all anchor tags to redirect through proxy
    $('a').each((i, link) => {
      const href = $(link).attr('href');
      if (href) {
        // Skip javascript: and mailto: links
        if (href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('#')) {
          return;
        }
        
        // Resolve relative URLs to absolute URLs
        let absoluteUrl;
        try {
          absoluteUrl = new URL(href, targetUrl).href;
        } catch (e) {
          // If URL parsing fails, leave the link as is
          return;
        }
        
        // Replace the href with our proxy URL
        $(link).attr('href', `javascript:fetchUrl('${absoluteUrl}')`);
      }
    });
    
    // Handle base tags
    $('base').each((i, baseTag) => {
      const href = $(baseTag).attr('href');
      if (href) {
        $(baseTag).attr('href', baseUrl);
      }
    });
    
    // Remove or modify potentially harmful tags/attributes
    $('script').remove(); // Remove all script tags
    $('[onclick], [onload], [onerror]').removeAttr('onclick').removeAttr('onload').removeAttr('onerror');
    
    // Add custom styling for proxied content
    $('head').append('<style>.proxied-content { padding: 20px; }</style>');
    
    // Add our custom wrapper
    const proxyHtml = `
      <div class="proxied-content">
        <div class="proxy-bar">
          <p>Currently viewing: ${targetUrl}</p>
          <button onclick="goBack()">Back to Proxy</button>
        </div>
        ${$.html()}
      </div>
    `;
    
    res.json({ html: proxyHtml, url: targetUrl });
  } catch (error) {
    console.error('Proxy error:', error.message);
    res.status(500).json({ 
      error: 'Failed to fetch or process the URL', 
      details: error.message
    });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Proxy server running on http://localhost:${PORT}`);
});