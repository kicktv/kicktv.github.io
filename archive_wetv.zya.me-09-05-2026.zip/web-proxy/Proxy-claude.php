<?php
// Error reporting for debugging (remove in production)
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Security: Define allowed domains (empty array means all domains are allowed)
$allowedDomains = [];

// Function to validate URL
function isValidUrl($url) {
    return filter_var($url, FILTER_VALIDATE_URL);
}

// Function to check if domain is allowed
function isDomainAllowed($url) {
    global $allowedDomains;
    if (empty($allowedDomains)) {
        return true; // All domains allowed
    }
    $host = parse_url($url, PHP_URL_HOST);
    return in_array($host, $allowedDomains);
}

// Process the form submission
$url = '';
$content = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['url'])) {
    $url = trim($_POST['url']);
    
    // Validate URL
    if (!isValidUrl($url)) {
        $error = 'Invalid URL. Please enter a valid URL including http:// or https://';
    } elseif (!isDomainAllowed($url)) {
        $error = 'This domain is not allowed.';
    } else {
        // Initialize cURL session
        $ch = curl_init();
        
        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
        
        // Execute cURL session
        $content = curl_exec($ch);
        
        // Check for errors
        if (curl_errno($ch)) {
            $error = 'Failed to fetch content: ' . curl_error($ch);
            $content = '';
        }
        
        // Close cURL session
        curl_close($ch);
        
        // If content was retrieved successfully, modify the links
        if ($content && empty($error)) {
            // Load HTML content into DOMDocument
            $dom = new DOMDocument();
            
            // Suppress warnings for malformed HTML
            libxml_use_internal_errors(true);
            
            // Load HTML content
            $dom->loadHTML($content, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
            
            // Clear any error messages
            libxml_clear_errors();
            
            // Get all anchor tags
            $links = $dom->getElementsByTagName('a');
            
            // Modify href attributes
            foreach ($links as $link) {
                if ($link->hasAttribute('href')) {
                    $href = $link->getAttribute('href');
                    
                    // Skip if it's a javascript: or # link
                    if (strpos($href, 'javascript:') === 0 || $href === '#') {
                        continue;
                    }
                    
                    // Convert relative URLs to absolute URLs
                    if (strpos($href, 'http') !== 0) {
                        $base = parse_url($url);
                        $baseUrl = $base['scheme'] . '://' . $base['host'];
                        
                        if (strpos($href, '/') === 0) {
                            $href = $baseUrl . $href;
                        } else {
                            $path = isset($base['path']) ? dirname($base['path']) : '/';
                            $href = $baseUrl . $path . '/' . $href;
                        }
                    }
                    
                    // Modify the href attribute to go through the proxy
                    $encodedUrl = urlencode($href);
                    $link->setAttribute('href', '?proxyurl=' . $encodedUrl);
                }
            }
            
            // Convert modified DOM back to HTML
            $content = $dom->saveHTML();
        }
    }
}

// Check if we're handling a proxied URL request
if (isset($_GET['proxyurl'])) {
    $proxyUrl = urldecode($_GET['proxyurl']);
    
    // Validate URL
    if (!isValidUrl($proxyUrl)) {
        $error = 'Invalid URL in proxy request.';
    } elseif (!isDomainAllowed($proxyUrl)) {
        $error = 'This domain is not allowed for proxying.';
    } else {
        // Redirect to submit the form with this URL
        header("Location: index.php", true, 307);
        echo "<form id='redirectForm' method='post' action=''>";
        echo "<input type='hidden' name='url' value='" . htmlspecialchars($proxyUrl, ENT_QUOTES, 'UTF-8') . "'>";
        echo "</form>";
        echo "<script>document.getElementById('redirectForm').submit();</script>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Web Proxy</title>
    <style>
        :root {
            --primary-color: #4a6fa5;
            --secondary-color: #166088;
            --background-color: #f5f7fa;
            --text-color: #333;
            --error-color: #e74c3c;
            --success-color: #2ecc71;
            --border-color: #ddd;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: var(--text-color);
            background-color: var(--background-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 1rem;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        main {
            flex: 1;
            padding: 1.5rem;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }
        
        .proxy-form {
            background-color: white;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
            margin-bottom: 1rem;
        }
        
        @media (min-width: 768px) {
            .form-group {
                flex-direction: row;
                align-items: center;
            }
        }
        
        label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--secondary-color);
        }
        
        @media (min-width: 768px) {
            label {
                width: 80px;
                margin-bottom: 0;
                margin-right: 1rem;
            }
        }
        
        input[type="text"] {
            flex: 1;
            padding: 0.75rem;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 1rem;
        }
        
        button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.2s;
        }
        
        button:hover {
            background-color: var(--secondary-color);
        }
        
        @media (min-width: 768px) {
            button {
                margin-left: 1rem;
            }
        }
        
        .error-message {
            color: var(--error-color);
            margin: 1rem 0;
            padding: 0.75rem;
            background-color: rgba(231, 76, 60, 0.1);
            border-radius: 4px;
            border-left: 4px solid var(--error-color);
        }
        
        .content-container {
            background-color: white;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem 0;
            color: #999;
        }
        
        .empty-state i {
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }
        
        footer {
            text-align: center;
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
            margin-top: auto;
        }
        
        /* Responsive iframe for content */
        .iframe-container {
            position: relative;
            padding-bottom: 56.25%; /* 16:9 aspect ratio */
            height: 0;
            overflow: hidden;
        }
        
        .iframe-container iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: 0;
        }
        
        /* Content styling */
        .proxied-content {
            max-width: 100%;
            overflow-x: auto;
        }
        
        .proxied-content img {
            max-width: 100%;
            height: auto;
        }
        
        /* Loading spinner */
        .loading {
            display: none;
            text-align: center;
            padding: 2rem;
        }
        
        .spinner {
            border: 4px solid rgba(0, 0, 0, 0.1);
            width: 36px;
            height: 36px;
            border-radius: 50%;
            border-left-color: var(--primary-color);
            animation: spin 1s linear infinite;
            margin: 0 auto 1rem auto;
        }
        
        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>PHP Web Proxy</h1>
        <p>Browse websites through our secure proxy service</p>
    </header>
    
    <main>
        <section class="proxy-form">
            <form method="post" action="" id="proxyForm">
                <div class="form-group">
                    <label for="url">URL:</label>
                    <input type="text" id="url" name="url" value="<?php echo htmlspecialchars($url, ENT_QUOTES, 'UTF-8'); ?>" placeholder="https://example.com" required>
                    <button type="submit" id="submitBtn">Proxy</button>
                </div>
            </form>
            
            <?php if ($error): ?>
                <div class="error-message">
                    <?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>
        </section>
        
        <div class="loading" id="loadingSpinner">
            <div class="spinner"></div>
            <p>Loading content...</p>
        </div>
        
        <section class="content-container">
            <?php if ($content): ?>
                <div class="proxied-content">
                    <?php echo $content; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i>🌐</i>
                    <p>Enter a URL above to proxy a website</p>
                </div>
            <?php endif; ?>
        </section>
    </main>
    
    <footer>
        <p>&copy; <?php echo date('Y'); ?> PHP Web Proxy | For educational purposes only</p>
    </footer>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('proxyForm');
            const loadingSpinner = document.getElementById('loadingSpinner');
            const submitBtn = document.getElementById('submitBtn');
            
            form.addEventListener('submit', function() {
                // Show loading spinner
                loadingSpinner.style.display = 'block';
                submitBtn.disabled = true;
                submitBtn.innerText = 'Loading...';
            });
            
            // Function to adjust relative links on the page
            function adjustLinks() {
                const currentUrl = document.getElementById('url').value;
                if (!currentUrl) return;
                
                const baseUrl = new URL(currentUrl);
                
                // Get all links in the proxied content
                const links = document.querySelectorAll('.proxied-content a');
                
                links.forEach(link => {
                    const href = link.getAttribute('href');
                    
                    // Skip if it doesn't have an href or is already processed
                    if (!href || href.startsWith('?proxyurl=')) return;
                    
                    // Create absolute URL if it's relative
                    let absoluteUrl;
                    try {
                        absoluteUrl = new URL(href, baseUrl.href).href;
                        // Modify to go through proxy
                        link.setAttribute('href', '?proxyurl=' + encodeURIComponent(absoluteUrl));
                    } catch (e) {
                        console.error('Error processing URL:', href, e);
                    }
                });
            }
            
            // Run link adjustment if there's content
            if (document.querySelector('.proxied-content')) {
                adjustLinks();
            }
        });
    </script>
</body>
</html>