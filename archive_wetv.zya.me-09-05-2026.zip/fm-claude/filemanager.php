<?php
/**
 * PHP File Manager with Account Management
 * 
 * Features:
 * - User registration and authentication
 * - Password hashing and security measures
 * - File operations (upload, download, delete, rename)
 * - Directory navigation and creation
 * - File sharing between users
 * - Permission management
 */

// Start session for user authentication
session_start();

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'filemanager');

// File system configuration
define('ROOT_DIR', 'user_files/');
define('MAX_UPLOAD_SIZE', 50 * 1024 * 1024); // 50MB

// Initialize database connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Create required tables if they don't exist
function setupDatabase() {
    global $conn;
    
    // Users table
    $conn->query("CREATE TABLE IF NOT EXISTS users (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        storage_limit BIGINT DEFAULT 1073741824, /* 1GB default */
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Files table
    $conn->query("CREATE TABLE IF NOT EXISTS files (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        filename VARCHAR(255) NOT NULL,
        filepath VARCHAR(512) NOT NULL,
        mimetype VARCHAR(100),
        size BIGINT DEFAULT 0,
        owner_id INT(11) NOT NULL,
        parent_dir VARCHAR(512) DEFAULT '/',
        is_directory TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
    )");
    
    // Shares table
    $conn->query("CREATE TABLE IF NOT EXISTS shares (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        file_id INT(11) NOT NULL,
        user_id INT(11) NOT NULL,
        shared_by INT(11) NOT NULL,
        permissions TINYINT(1) DEFAULT 1, /* 1=read, 2=write, 3=both */
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (file_id) REFERENCES files(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (shared_by) REFERENCES users(id) ON DELETE CASCADE
    )");
}

// Create root storage directory if it doesn't exist
if (!file_exists(ROOT_DIR)) {
    mkdir(ROOT_DIR, 0755, true);
}

// Helper Functions
function sanitizePath($path) {
    $path = str_replace('..', '', $path);
    $path = preg_replace('/\/+/', '/', $path);
    return $path;
}

function getUserDirectory($userId) {
    $dir = ROOT_DIR . $userId . '/';
    if (!file_exists($dir)) {
        mkdir($dir, 0755, true);
    }
    return $dir;
}

function getAvailableStorage($userId) {
    global $conn;
    
    // Get user's storage limit
    $stmt = $conn->prepare("SELECT storage_limit FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $storageLimit = $row['storage_limit'];
    
    // Calculate used space
    $stmt = $conn->prepare("SELECT SUM(size) as used FROM files WHERE owner_id = ? AND is_directory = 0");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $usedStorage = $row['used'] ? $row['used'] : 0;
    
    return [
        'used' => $usedStorage,
        'total' => $storageLimit,
        'available' => $storageLimit - $usedStorage
    ];
}

function formatFileSize($bytes) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 2) . ' ' . $units[$i];
}

// Authentication Functions
function registerUser($username, $email, $password) {
    global $conn;
    
    // Validate input
    if (empty($username) || empty($email) || empty($password)) {
        return ['success' => false, 'message' => 'All fields are required'];
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ['success' => false, 'message' => 'Invalid email format'];
    }
    
    if (strlen($password) < 8) {
        return ['success' => false, 'message' => 'Password must be at least 8 characters long'];
    }
    
    try {
        // Check if username or email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            return ['success' => false, 'message' => 'Username or email already exists'];
        }
        
        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert new user
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashedPassword);
        $stmt->execute();
        
        if ($stmt->affected_rows > 0) {
            $userId = $stmt->insert_id;
            // Create user directory
            getUserDirectory($userId);
            return ['success' => true, 'message' => 'Registration successful!', 'user_id' => $userId];
        } else {
            return ['success' => false, 'message' => 'Registration failed. Please try again.'];
        }
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
    }
}

function loginUser($username, $password) {
    global $conn;
    
    // Validate input
    if (empty($username) || empty($password)) {
        return ['success' => false, 'message' => 'Username and password are required'];
    }
    
    try {
        // Find user
        $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // Verify password
            if (password_verify($password, $user['password'])) {
                // Set session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                
                return ['success' => true, 'message' => 'Login successful!', 'user_id' => $user['id']];
            } else {
                return ['success' => false, 'message' => 'Invalid password'];
            }
        } else {
            return ['success' => false, 'message' => 'User not found'];
        }
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
    }
}

function logoutUser() {
    // Destroy session
    session_unset();
    session_destroy();
    return ['success' => true, 'message' => 'Logout successful'];
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// File Operations
function listFiles($directory = '/', $userId = null) {
    global $conn;
    
    if (!isLoggedIn() && $userId === null) {
        return ['success' => false, 'message' => 'User not logged in'];
    }
    
    $userId = $userId ?? $_SESSION['user_id'];
    $directory = sanitizePath($directory);
    
    // Get files owned by user in specified directory
    $stmt = $conn->prepare("SELECT id, filename, filepath, mimetype, size, is_directory, created_at 
                           FROM files WHERE owner_id = ? AND parent_dir = ? ORDER BY is_directory DESC, filename ASC");
    $stmt->bind_param("is", $userId, $directory);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $files = [];
    while ($row = $result->fetch_assoc()) {
        $files[] = $row;
    }
    
    // Get shared files
    $stmt = $conn->prepare("SELECT f.id, f.filename, f.filepath, f.mimetype, f.size, f.is_directory, f.created_at, s.permissions
                           FROM shares s JOIN files f ON s.file_id = f.id 
                           WHERE s.user_id = ? ORDER BY f.is_directory DESC, f.filename ASC");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $sharedFiles = [];
    while ($row = $result->fetch_assoc()) {
        $row['shared'] = true;
        $sharedFiles[] = $row;
    }
    
    return [
        'success' => true,
        'directory' => $directory,
        'files' => $files,
        'shared_files' => $sharedFiles,
        'storage' => getAvailableStorage($userId)
    ];
}

function uploadFile($userId = null) {
    global $conn;
    
    if (!isLoggedIn() && $userId === null) {
        return ['success' => false, 'message' => 'User not logged in'];
    }
    
    $userId = $userId ?? $_SESSION['user_id'];
    $directory = isset($_POST['directory']) ? sanitizePath($_POST['directory']) : '/';
    
    if (!isset($_FILES['file'])) {
        return ['success' => false, 'message' => 'No file uploaded'];
    }
    
    $file = $_FILES['file'];
    
    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errorMessages = [
            UPLOAD_ERR_INI_SIZE => 'The uploaded file exceeds the upload_max_filesize directive in php.ini',
            UPLOAD_ERR_FORM_SIZE => 'The uploaded file exceeds the MAX_FILE_SIZE directive in the HTML form',
            UPLOAD_ERR_PARTIAL => 'The uploaded file was only partially uploaded',
            UPLOAD_ERR_NO_FILE => 'No file was uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing a temporary folder',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
            UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the file upload'
        ];
        
        return ['success' => false, 'message' => $errorMessages[$file['error']] ?? 'Unknown upload error'];
    }
    
    // Check file size
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        return ['success' => false, 'message' => 'File size exceeds the limit of ' . formatFileSize(MAX_UPLOAD_SIZE)];
    }
    
    // Check available storage
    $storage = getAvailableStorage($userId);
    if ($file['size'] > $storage['available']) {
        return ['success' => false, 'message' => 'Not enough storage space available'];
    }
    
    // Create secure filename
    $filename = basename($file['name']);
    $filepath = getUserDirectory($userId) . $directory . $filename;
    
    // Check if file already exists
    $stmt = $conn->prepare("SELECT id FROM files WHERE owner_id = ? AND parent_dir = ? AND filename = ?");
    $stmt->bind_param("iss", $userId, $directory, $filename);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Generate unique filename
        $pathInfo = pathinfo($filename);
        $filename = $pathInfo['filename'] . '_' . time() . '.' . $pathInfo['extension'];
        $filepath = getUserDirectory($userId) . $directory . $filename;
    }
    
    // Create directory if it doesn't exist
    $uploadDir = getUserDirectory($userId) . $directory;
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        return ['success' => false, 'message' => 'Failed to move uploaded file'];
    }
    
    // Record file in database
    $stmt = $conn->prepare("INSERT INTO files (filename, filepath, mimetype, size, owner_id, parent_dir) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssis", $filename, $filepath, $file['type'], $file['size'], $userId, $directory);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        return [
            'success' => true,
            'message' => 'File uploaded successfully',
            'file_id' => $stmt->insert_id,
            'filename' => $filename,
            'size' => formatFileSize($file['size'])
        ];
    } else {
        // Delete the file if database insertion fails
        unlink($filepath);
        return ['success' => false, 'message' => 'Failed to record file in database'];
    }
}

function createDirectory($name, $parent = '/', $userId = null) {
    global $conn;
    
    if (!isLoggedIn() && $userId === null) {
        return ['success' => false, 'message' => 'User not logged in'];
    }
    
    $userId = $userId ?? $_SESSION['user_id'];
    $parent = sanitizePath($parent);
    
    // Validate directory name
    if (empty($name) || strpbrk($name, "\\/?%*:|\"<>") !== false) {
        return ['success' => false, 'message' => 'Invalid directory name'];
    }
    
    // Check if directory already exists
    $stmt = $conn->prepare("SELECT id FROM files WHERE owner_id = ? AND parent_dir = ? AND filename = ? AND is_directory = 1");
    $stmt->bind_param("iss", $userId, $parent, $name);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return ['success' => false, 'message' => 'Directory already exists'];
    }
    
    // Create physical directory
    $dirPath = getUserDirectory($userId) . $parent . $name;
    if (!file_exists($dirPath)) {
        if (!mkdir($dirPath, 0755, true)) {
            return ['success' => false, 'message' => 'Failed to create directory'];
        }
    }
    
    // Record directory in database
    $stmt = $conn->prepare("INSERT INTO files (filename, filepath, owner_id, parent_dir, is_directory) VALUES (?, ?, ?, ?, 1)");
    $stmt->bind_param("ssis", $name, $dirPath, $userId, $parent);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        return [
            'success' => true,
            'message' => 'Directory created successfully',
            'directory_id' => $stmt->insert_id,
            'directory_name' => $name
        ];
    } else {
        // Remove physical directory if database insertion fails
        rmdir($dirPath);
        return ['success' => false, 'message' => 'Failed to record directory in database'];
    }
}

function downloadFile($fileId, $userId = null) {
    global $conn;
    
    if (!isLoggedIn() && $userId === null) {
        return ['success' => false, 'message' => 'User not logged in'];
    }
    
    $userId = $userId ?? $_SESSION['user_id'];
    
    // Check file ownership or sharing permissions
    $stmt = $conn->prepare("SELECT f.* FROM files f 
                           LEFT JOIN shares s ON f.id = s.file_id AND s.user_id = ?
                           WHERE f.id = ? AND (f.owner_id = ? OR s.id IS NOT NULL)");
    $stmt->bind_param("iii", $userId, $fileId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return ['success' => false, 'message' => 'File not found or access denied'];
    }
    
    $file = $result->fetch_assoc();
    
    if ($file['is_directory']) {
        return ['success' => false, 'message' => 'Cannot download a directory'];
    }
    
    if (!file_exists($file['filepath'])) {
        return ['success' => false, 'message' => 'File not found on disk'];
    }
    
    // Return file information for download
    return [
        'success' => true,
        'filename' => $file['filename'],
        'filepath' => $file['filepath'],
        'mimetype' => $file['mimetype'],
        'size' => $file['size']
    ];
}

function deleteFile($fileId, $userId = null) {
    global $conn;
    
    if (!isLoggedIn() && $userId === null) {
        return ['success' => false, 'message' => 'User not logged in'];
    }
    
    $userId = $userId ?? $_SESSION['user_id'];
    
    // Check file ownership or write permissions
    $stmt = $conn->prepare("SELECT f.* FROM files f 
                           LEFT JOIN shares s ON f.id = s.file_id AND s.user_id = ? AND (s.permissions = 2 OR s.permissions = 3)
                           WHERE f.id = ? AND (f.owner_id = ? OR s.id IS NOT NULL)");
    $stmt->bind_param("iii", $userId, $fileId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return ['success' => false, 'message' => 'File not found or access denied'];
    }
    
    $file = $result->fetch_assoc();
    
    // Delete physical file/directory
    if ($file['is_directory']) {
        // Recursively delete directory contents
        $success = deleteDirectoryRecursive($file['filepath'], $file['id']);
        if (!$success) {
            return ['success' => false, 'message' => 'Failed to delete directory contents'];
        }
    } elseif (file_exists($file['filepath'])) {
        unlink($file['filepath']);
    }
    
    // Delete from database
    $stmt = $conn->prepare("DELETE FROM files WHERE id = ?");
    $stmt->bind_param("i", $fileId);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        return ['success' => true, 'message' => ($file['is_directory'] ? 'Directory' : 'File') . ' deleted successfully'];
    } else {
        return ['success' => false, 'message' => 'Failed to delete from database'];
    }
}

function deleteDirectoryRecursive($dirPath, $dirId) {
    global $conn;
    
    // Get all files in this directory
    $stmt = $conn->prepare("SELECT id, filepath, is_directory FROM files WHERE parent_dir LIKE CONCAT('%', ?, '%')");
    $stmt->bind_param("s", $dirId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($file = $result->fetch_assoc()) {
        if ($file['is_directory']) {
            deleteDirectoryRecursive($file['filepath'], $file['id']);
        } elseif (file_exists($file['filepath'])) {
            unlink($file['filepath']);
        }
        
        // Delete from database
        $stmt2 = $conn->prepare("DELETE FROM files WHERE id = ?");
        $stmt2->bind_param("i", $file['id']);
        $stmt2->execute();
    }
    
    // Finally remove the empty directory
    if (file_exists($dirPath) && is_dir($dirPath)) {
        return rmdir($dirPath);
    }
    
    return true;
}

function renameFile($fileId, $newName, $userId = null) {
    global $conn;
    
    if (!isLoggedIn() && $userId === null) {
        return ['success' => false, 'message' => 'User not logged in'];
    }
    
    $userId = $userId ?? $_SESSION['user_id'];
    
    // Validate new name
    if (empty($newName) || strpbrk($newName, "\\/?%*:|\"<>") !== false) {
        return ['success' => false, 'message' => 'Invalid file name'];
    }
    
    // Check file ownership or write permissions
    $stmt = $conn->prepare("SELECT f.* FROM files f 
                           LEFT JOIN shares s ON f.id = s.file_id AND s.user_id = ? AND (s.permissions = 2 OR s.permissions = 3)
                           WHERE f.id = ? AND (f.owner_id = ? OR s.id IS NOT NULL)");
    $stmt->bind_param("iii", $userId, $fileId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return ['success' => false, 'message' => 'File not found or access denied'];
    }
    
    $file = $result->fetch_assoc();
    
    // Check if a file with new name already exists in the same directory
    $stmt = $conn->prepare("SELECT id FROM files WHERE owner_id = ? AND parent_dir = ? AND filename = ? AND id != ?");
    $stmt->bind_param("issi", $userId, $file['parent_dir'], $newName, $fileId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return ['success' => false, 'message' => ($file['is_directory'] ? 'Directory' : 'File') . ' with this name already exists'];
    }
    
    // Rename physical file/directory
    $newPath = dirname($file['filepath']) . '/' . $newName;
    
    if (file_exists($file['filepath'])) {
        if (!rename($file['filepath'], $newPath)) {
            return ['success' => false, 'message' => 'Failed to rename on disk'];
        }
    }
    
    // Update database
    $stmt = $conn->prepare("UPDATE files SET filename = ?, filepath = ? WHERE id = ?");
    $stmt->bind_param("ssi", $newName, $newPath, $fileId);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        return [
            'success' => true, 
            'message' => ($file['is_directory'] ? 'Directory' : 'File') . ' renamed successfully',
            'new_name' => $newName
        ];
    } else {
        // Revert physical rename if database update fails
        rename($newPath, $file['filepath']);
        return ['success' => false, 'message' => 'Failed to update name in database'];
    }
}

// Sharing Functions
function shareFile($fileId, $username, $permissions = 1, $userId = null) {
    global $conn;
    
    if (!isLoggedIn() && $userId === null) {
        return ['success' => false, 'message' => 'User not logged in'];
    }
    
    $userId = $userId ?? $_SESSION['user_id'];
    
    // Validate permissions (1=read, 2=write, 3=both)
    $permissions = (int)$permissions;
    if ($permissions < 1 || $permissions > 3) {
        return ['success' => false, 'message' => 'Invalid permissions value'];
    }
    
    // Get file info and check ownership
    $stmt = $conn->prepare("SELECT id FROM files WHERE id = ? AND owner_id = ?");
    $stmt->bind_param("ii", $fileId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return ['success' => false, 'message' => 'File not found or you are not the owner'];
    }
    
    // Get user ID from username
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return ['success' => false, 'message' => 'User not found'];
    }
    
    $targetUser = $result->fetch_assoc();
    $targetUserId = $targetUser['id'];
    
    // Check if already shared
    $stmt = $conn->prepare("SELECT id FROM shares WHERE file_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $fileId, $targetUserId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Update existing share permissions
        $shareId = $result->fetch_assoc()['id'];
        $stmt = $conn->prepare("UPDATE shares SET permissions = ? WHERE id = ?");
        $stmt->bind_param("ii", $permissions, $shareId);
        $stmt->execute();
        
        if ($stmt->affected_rows > 0) {
            return ['success' => true, 'message' => 'Sharing permissions updated successfully'];
        } else {
            return ['success' => false, 'message' => 'Failed to update sharing permissions'];
        }
    } else {
        // Create new share
        $stmt = $conn->prepare("INSERT INTO shares (file_id, user_id, shared_by, permissions) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiii", $fileId, $targetUserId, $userId, $permissions);
        $stmt->execute();
        
        if ($stmt->affected_rows > 0) {
            return ['success' => true, 'message' => 'File shared successfully with ' . $username];
        } else {
            return ['success' => false, 'message' => 'Failed to share file'];
        }
    }
}

function removeShare($fileId, $userId, $sharingUserId = null) {
    global $conn;
    
    if (!isLoggedIn() && $sharingUserId === null) {
        return ['success' => false, 'message' => 'User not logged in'];
    }
    
    $sharingUserId = $sharingUserId ?? $_SESSION['user_id'];
    
    // Check if user is the file owner or the share recipient
    $stmt = $conn->prepare("SELECT f.owner_id FROM files f WHERE f.id = ?");
    $stmt->bind_param("i", $fileId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return ['success' => false, 'message' => 'File not found'];
    }
    
    $file = $result->fetch_assoc();
    
    // Delete the share
    if ($file['owner_id'] == $sharingUserId) {
        // File owner can remove any share
        $stmt = $conn->prepare("DELETE FROM shares WHERE file_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $fileId, $userId);
    } else if ($sharingUserId == $userId) {
        // User can remove shares to themselves
        $stmt = $conn->prepare("DELETE FROM shares WHERE file_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $fileId, $sharingUserId);
    } else {
        return ['success' => false, 'message' => 'You do not have permission to remove this share'];
    }
    
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        return ['success' => true, 'message' => 'Sharing access removed successfully'];
    } else {
        return ['success' => false, 'message' => 'Failed to remove sharing access'];
    }
}

function listSharedFiles($userId = null) {
    global $conn;
    
    if (!isLoggedIn() && $userId === null) {
        return ['success' => false, 'message' => 'User not logged in'];
    }
    
    $userId = $userId ?? $_SESSION['user_id'];
    
    // Get files shared by this user
    $stmt = $conn->prepare("SELECT s.id as share_id, s.file_id, s.user_id, s.permissions, s.created_at, 
                           f.filename, f.is_directory, u.username 
                           FROM shares s 
                           JOIN files f ON s.file_id = f.id 
                           JOIN users u ON s.user_id = u.id 
                           WHERE s.shared_by = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $sharedByMe = [];
    while ($row = $result->fetch_assoc()) {
        $sharedByMe[] = $row;
    }
    
    // Get files shared with this user
    $stmt = $conn->prepare("SELECT s.id as share_id, s.file_id, s.shared_by, s.permissions, s.created_at, 
                           f.filename, f.is_directory, u.username 
                           FROM shares s 
                           JOIN files f ON s.file_id = f.id 
                           JOIN users u ON s.shared_by = u.id 
                           WHERE s.user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $sharedWithMe = [];
    while ($row = $result->fetch_assoc()) {
        $sharedWithMe[] = $row;
    }
    
    return [
        'success' => true,
        'shared_by_me' => $sharedByMe,
        'shared_with_me' => $sharedWithMe
    ];
}

// User Management Functions
function getUserInfo($userId = null) {
    global $conn;
    
    if (!isLoggedIn() && $userId === null) {
return ['success' => false, 'message' => 'User not logged in'];
    }
    
    $userId = $userId ?? $_SESSION['user_id'];
    
    $stmt = $conn->prepare("SELECT id, username, email, storage_limit, created_at FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return ['success' => false, 'message' => 'User not found'];
    }
    
    $user = $result->fetch_assoc();
    $storage = getAvailableStorage($userId);
    
    $user['storage'] = $storage;
    
    return [
        'success' => true,
        'user' => $user
    ];
}

function updateUserPassword($currentPassword, $newPassword, $userId = null) {
    global $conn;
    
    if (!isLoggedIn() && $userId === null) {
        return ['success' => false, 'message' => 'User not logged in'];
    }
    
    $userId = $userId ?? $_SESSION['user_id'];
    
    // Validate new password
    if (strlen($newPassword) < 8) {
        return ['success' => false, 'message' => 'New password must be at least 8 characters long'];
    }
    
    // Get current user information
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return ['success' => false, 'message' => 'User not found'];
    }
    
    $user = $result->fetch_assoc();
    
    // Verify current password
    if (!password_verify($currentPassword, $user['password'])) {
        return ['success' => false, 'message' => 'Current password is incorrect'];
    }
    
    // Hash new password
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    
    // Update password
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $hashedPassword, $userId);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        return ['success' => true, 'message' => 'Password updated successfully'];
    } else {
        return ['success' => false, 'message' => 'Failed to update password'];
    }
}

function updateUserEmail($newEmail, $password, $userId = null) {
    global $conn;
    
    if (!isLoggedIn() && $userId === null) {
        return ['success' => false, 'message' => 'User not logged in'];
    }
    
    $userId = $userId ?? $_SESSION['user_id'];
    
    // Validate email
    if (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
        return ['success' => false, 'message' => 'Invalid email format'];
    }
    
    // Check if email already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
    $stmt->bind_param("si", $newEmail, $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return ['success' => false, 'message' => 'Email already in use by another account'];
    }
    
    // Get current user information
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return ['success' => false, 'message' => 'User not found'];
    }
    
    $user = $result->fetch_assoc();
    
    // Verify password
    if (!password_verify($password, $user['password'])) {
        return ['success' => false, 'message' => 'Password is incorrect'];
    }
    
    // Update email
    $stmt = $conn->prepare("UPDATE users SET email = ? WHERE id = ?");
    $stmt->bind_param("si", $newEmail, $userId);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        return ['success' => true, 'message' => 'Email updated successfully'];
    } else {
        return ['success' => false, 'message' => 'Failed to update email'];
    }
}

// API Endpoint Handler
function handleRequest() {
    // Setup database tables if needed
    setupDatabase();
    
    $action = $_GET['action'] ?? $_POST['action'] ?? '';
    $response = ['success' => false, 'message' => 'Invalid action'];
    
    switch ($action) {
        case 'register':
            $username = $_POST['username'] ?? '';
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            $response = registerUser($username, $email, $password);
            break;
            
        case 'login':
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            $response = loginUser($username, $password);
            break;
            
        case 'logout':
            $response = logoutUser();
            break;
            
        case 'list_files':
            $directory = $_GET['directory'] ?? '/';
            $response = listFiles($directory);
            break;
            
        case 'upload':
            $response = uploadFile();
            break;
            
        case 'create_directory':
            $name = $_POST['name'] ?? '';
            $parent = $_POST['parent'] ?? '/';
            $response = createDirectory($name, $parent);
            break;
            
        case 'download':
            $fileId = $_GET['id'] ?? 0;
            $response = downloadFile($fileId);
            
            if ($response['success']) {
                // Set headers for download
                header('Content-Type: ' . $response['mimetype']);
                header('Content-Disposition: attachment; filename="' . $response['filename'] . '"');
                header('Content-Length: ' . $response['size']);
                
                // Output file content
                readfile($response['filepath']);
                exit;
            }
            break;
            
        case 'delete':
            $fileId = $_POST['id'] ?? 0;
            $response = deleteFile($fileId);
            break;
            
        case 'rename':
            $fileId = $_POST['id'] ?? 0;
            $newName = $_POST['name'] ?? '';
            $response = renameFile($fileId, $newName);
            break;
            
        case 'share':
            $fileId = $_POST['file_id'] ?? 0;
            $username = $_POST['username'] ?? '';
            $permissions = $_POST['permissions'] ?? 1;
            $response = shareFile($fileId, $username, $permissions);
            break;
            
        case 'remove_share':
            $fileId = $_POST['file_id'] ?? 0;
            $userId = $_POST['user_id'] ?? 0;
            $response = removeShare($fileId, $userId);
            break;
            
        case 'list_shares':
            $response = listSharedFiles();
            break;
            
        case 'user_info':
            $response = getUserInfo();
            break;
            
        case 'update_password':
            $currentPassword = $_POST['current_password'] ?? '';
            $newPassword = $_POST['new_password'] ?? '';
            $response = updateUserPassword($currentPassword, $newPassword);
            break;
            
        case 'update_email':
            $newEmail = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            $response = updateUserEmail($newEmail, $password);
            break;
    }
    
    return $response;
}

// Process request if accessed directly
if (basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
    $response = handleRequest();
    
    // Send JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
