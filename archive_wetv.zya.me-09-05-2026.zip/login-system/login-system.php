<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title>SecureAuth | Modern Login & Registration</title>
  <!-- Google Fonts & Font Awesome -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Inter', sans-serif;
    }

    body {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1.5rem;
    }

    /* Main container */
    .auth-container {
      background: rgba(255,255,255,0.98);
      border-radius: 2rem;
      box-shadow: 0 25px 45px rgba(0,0,0,0.2), 0 0 0 1px rgba(255,255,255,0.2);
      width: 100%;
      max-width: 460px;
      overflow: hidden;
      transition: all 0.3s ease;
    }

    /* Tabs */
    .tabs {
      display: flex;
      background: #f8fafc;
      border-bottom: 1px solid #e2e8f0;
    }

    .tab-btn {
      flex: 1;
      background: transparent;
      border: none;
      padding: 1.2rem;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: 0.2s;
      color: #64748b;
      letter-spacing: -0.2px;
    }

    .tab-btn i {
      margin-right: 8px;
    }

    .tab-btn.active {
      color: #4f46e5;
      background: white;
      border-bottom: 3px solid #4f46e5;
    }

    /* Forms */
    .form-panel {
      padding: 2rem 1.8rem 2rem 1.8rem;
      display: none;
      animation: fade 0.25s ease;
    }

    .form-panel.active {
      display: block;
    }

    @keyframes fade {
      from { opacity: 0; transform: translateY(8px);}
      to { opacity: 1; transform: translateY(0);}
    }

    .input-group {
      margin-bottom: 1.4rem;
      position: relative;
    }

    .input-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
      color: #1e293b;
      font-size: 0.85rem;
    }

    .input-group i {
      position: absolute;
      left: 14px;
      top: 42px;
      color: #94a3b8;
      font-size: 1rem;
    }

    .input-group input {
      width: 100%;
      padding: 0.85rem 0.85rem 0.85rem 2.5rem;
      border: 1.5px solid #e2e8f0;
      border-radius: 1rem;
      font-size: 0.95rem;
      transition: all 0.2s;
      background: #fff;
    }

    .input-group input:focus {
      outline: none;
      border-color: #4f46e5;
      box-shadow: 0 0 0 3px rgba(79,70,229,0.2);
    }

    /* Checkbox row */
    .checkbox-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 1rem 0 1.4rem;
      font-size: 0.85rem;
    }

    .checkbox-row label {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      color: #334155;
    }

    .btn-submit {
      width: 100%;
      background: linear-gradient(100deg, #4f46e5, #6366f1);
      border: none;
      padding: 0.9rem;
      border-radius: 2rem;
      font-weight: 700;
      font-size: 1rem;
      color: white;
      cursor: pointer;
      transition: 0.2s;
      box-shadow: 0 8px 20px -8px #4f46e5;
    }

    .btn-submit:hover {
      transform: translateY(-2px);
      background: linear-gradient(100deg, #4338ca, #4f46e5);
      box-shadow: 0 12px 24px -10px #4f46e5;
    }

    /* Message alerts */
    .message {
      padding: 0.9rem;
      border-radius: 1rem;
      margin-bottom: 1.5rem;
      font-size: 0.85rem;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .message.error {
      background: #fee2e2;
      color: #b91c1c;
      border-left: 4px solid #ef4444;
    }

    .message.success {
      background: #dcfce7;
      color: #166534;
      border-left: 4px solid #22c55e;
    }

    .info-note {
      font-size: 0.7rem;
      text-align: center;
      margin-top: 1rem;
      color: #6c757d;
    }

    /* Dashboard specific (post-login) */
    .dashboard {
      max-width: 560px;
    }
    .dashboard-header {
      background: white;
      padding: 1.5rem;
      text-align: center;
      border-bottom: 1px solid #eef2ff;
    }
    .user-greeting {
      font-size: 1.5rem;
      font-weight: 700;
      color: #1e293b;
    }
    .dashboard-actions {
      padding: 2rem;
      display: flex;
      justify-content: center;
    }
    .logout-btn {
      background: #ef4444;
      border: none;
      padding: 0.8rem 1.8rem;
      border-radius: 2rem;
      font-weight: 600;
      color: white;
      cursor: pointer;
      transition: 0.2s;
      font-size: 1rem;
    }
    .logout-btn:hover {
      background: #dc2626;
      transform: scale(0.98);
    }
    hr {
      margin: 1rem 0;
    }

    @media (max-width: 500px) {
      .auth-container {
        max-width: 100%;
      }
      .form-panel {
        padding: 1.5rem;
      }
    }
  </style>
</head>
<body>

<?php
session_start();

// ---------- CONFIGURATION ----------
define('USER_DATA_FILE', 'users.txt');
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCK_TIMEOUT_SECONDS', 2);     // file lock max wait

// ---------- HELPER: secure file write with flock (atomic + locking) ----------
function secure_file_write($filepath, $data, $mode = 'w') {
    $dir = dirname($filepath);
    if (!is_dir($dir)) {
        // create if missing (for edge cases)
        mkdir($dir, 0755, true);
    }
    $fp = fopen($filepath, $mode);
    if (!$fp) return false;
    
    // acquire exclusive lock (blocking up to LOCK_TIMEOUT_SECONDS)
    $locked = flock($fp, LOCK_EX);
    if (!$locked) {
        fclose($fp);
        return false;
    }
    
    // truncate if writing whole content
    if ($mode === 'w') {
        ftruncate($fp, 0);
        rewind($fp);
    }
    $writeResult = fwrite($fp, $data);
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return ($writeResult !== false);
}

// ---------- HELPER: read users safely with shared lock ----------
function read_users_safe() {
    if (!file_exists(USER_DATA_FILE)) {
        return [];
    }
    $fp = fopen(USER_DATA_FILE, 'r');
    if (!$fp) return [];
    flock($fp, LOCK_SH);
    $content = stream_get_contents($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    
    $users = [];
    if ($content) {
        $lines = explode("\n", trim($content));
        foreach ($lines as $line) {
            if (trim($line) === '') continue;
            $parts = explode('|', $line, 5);
            if (count($parts) === 5) {
                list($username, $email, $hashedPwd, $failedAttempts, $lockUntil) = $parts;
                $users[$email] = [
                    'username' => $username,
                    'password' => $hashedPwd,
                    'failed_attempts' => (int)$failedAttempts,
                    'lock_until' => (int)$lockUntil
                ];
            }
        }
    }
    return $users;
}

// ---------- HELPER: write entire users array to file (atomic) ----------
function write_users_safe($users) {
    $lines = [];
    foreach ($users as $email => $data) {
        $lines[] = implode('|', [
            $data['username'],
            $email,
            $data['password'],
            $data['failed_attempts'],
            $data['lock_until']
        ]);
    }
    $content = implode("\n", $lines) . (count($lines) ? "\n" : '');
    return secure_file_write(USER_DATA_FILE, $content, 'w');
}

// ---------- BRUTE FORCE PROTECTION: check if account is temporarily locked ----------
function is_account_locked($userData) {
    if ($userData['lock_until'] > time()) {
        return true;
    }
    return false;
}

// ---------- REGISTER LOGIC ----------
$register_error = null;
$register_success = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    // server-side validation
    if (empty($username) || empty($email) || empty($password) || empty($confirm)) {
        $register_error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $register_error = "Invalid email format.";
    } elseif (strlen($username) < 3 || strlen($username) > 30) {
        $register_error = "Username must be 3-30 characters.";
    } elseif (strlen($password) < 6) {
        $register_error = "Password must be at least 6 characters.";
    } elseif ($password !== $confirm) {
        $register_error = "Passwords do not match.";
    } else {
        $users = read_users_safe();
        // check duplicate email or username
        $emailExists = isset($users[$email]);
        $usernameExists = false;
        foreach ($users as $user) {
            if (strtolower($user['username']) === strtolower($username)) {
                $usernameExists = true;
                break;
            }
        }
        if ($emailExists) {
            $register_error = "Email already registered.";
        } elseif ($usernameExists) {
            $register_error = "Username already taken.";
        } else {
            // hash password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $users[$email] = [
                'username' => $username,
                'password' => $hashedPassword,
                'failed_attempts' => 0,
                'lock_until' => 0
            ];
            if (write_users_safe($users)) {
                $register_success = "Registration successful! Please login.";
            } else {
                $register_error = "Server error: could not save data. Try again.";
            }
        }
    }
}

// ---------- LOGIN LOGIC ----------
$login_error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = trim($_POST['login_email'] ?? '');
    $password = $_POST['login_password'] ?? '';
    $remember = isset($_POST['remember_me']);
    
    if (empty($email) || empty($password)) {
        $login_error = "Email and password required.";
    } else {
        $users = read_users_safe();
        if (!isset($users[$email])) {
            $login_error = "Invalid credentials.";
        } else {
            $user = $users[$email];
            // brute force: check lock
            if (is_account_locked($user)) {
                $remaining = $user['lock_until'] - time();
                $login_error = "Account temporarily locked. Try again in $remaining seconds.";
            } else {
                if (password_verify($password, $user['password'])) {
                    // successful login -> reset failed attempts
                    $user['failed_attempts'] = 0;
                    $user['lock_until'] = 0;
                    $users[$email] = $user;
                    write_users_safe($users);
                    
                    // session management
                    $_SESSION['user_email'] = $email;
                    $_SESSION['user_name'] = $user['username'];
                    if ($remember) {
                        // set cookie for 30 days
                        $token = bin2hex(random_bytes(32));
                        $expiry = time() + (86400 * 30);
                        setcookie('remember_token', $token, $expiry, '/', '', false, true);
                        // store token in separate file (simple token storage)
                        $tokenFile = 'remember_tokens.txt';
                        $tokenData = [];
                        if (file_exists($tokenFile)) {
                            $fp = fopen($tokenFile, 'r');
                            flock($fp, LOCK_SH);
                            $content = stream_get_contents($fp);
                            flock($fp, LOCK_UN);
                            fclose($fp);
                            if ($content) {
                                $lines = explode("\n", trim($content));
                                foreach ($lines as $line) {
                                    if (trim($line)) {
                                        list($tok, $em) = explode('|', $line);
                                        $tokenData[$tok] = $em;
                                    }
                                }
                            }
                        }
                        $tokenData[$token] = $email;
                        $tokenLines = [];
                        foreach ($tokenData as $tok => $em) {
                            $tokenLines[] = "$tok|$em";
                        }
                        secure_file_write($tokenFile, implode("\n", $tokenLines) . "\n", 'w');
                    }
                    // redirect to dashboard
                    header("Location: " . $_SERVER['PHP_SELF'] . "?dashboard=1");
                    exit;
                } else {
                    // wrong password: increment failed attempts
                    $user['failed_attempts'] = $user['failed_attempts'] + 1;
                    if ($user['failed_attempts'] >= MAX_LOGIN_ATTEMPTS) {
                        $user['lock_until'] = time() + 300; // 5 minutes lockout
                        $login_error = "Too many failed attempts. Account locked for 5 minutes.";
                    } else {
                        $login_error = "Invalid credentials.";
                    }
                    $users[$email] = $user;
                    write_users_safe($users);
                }
            }
        }
    }
}

// ---------- LOGOUT ----------
if (isset($_GET['logout'])) {
    session_destroy();
    if (isset($_COOKIE['remember_token'])) {
        $token = $_COOKIE['remember_token'];
        setcookie('remember_token', '', time() - 3600, '/');
        // remove token from file
        $tokenFile = 'remember_tokens.txt';
        if (file_exists($tokenFile)) {
            $fp = fopen($tokenFile, 'r');
            flock($fp, LOCK_SH);
            $content = stream_get_contents($fp);
            flock($fp, LOCK_UN);
            fclose($fp);
            $newTokens = [];
            if ($content) {
                $lines = explode("\n", trim($content));
                foreach ($lines as $line) {
                    if (trim($line)) {
                        list($tok, $em) = explode('|', $line);
                        if ($tok !== $token) {
                            $newTokens[] = "$tok|$em";
                        }
                    }
                }
            }
            secure_file_write($tokenFile, implode("\n", $newTokens) . "\n", 'w');
        }
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ---------- AUTO LOGIN VIA REMEMBER ME COOKIE ----------
if (!isset($_SESSION['user_email']) && isset($_COOKIE['remember_token'])) {
    $token = $_COOKIE['remember_token'];
    $tokenFile = 'remember_tokens.txt';
    if (file_exists($tokenFile)) {
        $fp = fopen($tokenFile, 'r');
        flock($fp, LOCK_SH);
        $content = stream_get_contents($fp);
        flock($fp, LOCK_UN);
        fclose($fp);
        if ($content) {
            $lines = explode("\n", trim($content));
            foreach ($lines as $line) {
                if (trim($line)) {
                    list($tok, $email) = explode('|', $line);
                    if ($tok === $token) {
                        $users = read_users_safe();
                        if (isset($users[$email])) {
                            $_SESSION['user_email'] = $email;
                            $_SESSION['user_name'] = $users[$email]['username'];
                        }
                        break;
                    }
                }
            }
        }
    }
}

// ---------- DASHBOARD VIEW ----------
if (isset($_SESSION['user_email']) && !isset($_GET['dashboard'])) {
    header("Location: " . $_SERVER['PHP_SELF'] . "?dashboard=1");
    exit;
}

$showDashboard = isset($_GET['dashboard']) && isset($_SESSION['user_email']);
?>

<?php if ($showDashboard): ?>
    <!-- DASHBOARD UI -->
    <div class="auth-container dashboard">
        <div class="dashboard-header">
            <i class="fas fa-shield-alt" style="font-size: 2rem; color:#4f46e5; margin-bottom: 0.5rem;"></i>
            <div class="user-greeting">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</div>
            <p style="color:#475569; margin-top: 0.3rem;">You are securely logged in.</p>
        </div>
        <div class="dashboard-actions">
            <a href="?logout=1" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
        <div class="info-note" style="padding: 0 1rem 1.5rem;">
            <i class="fas fa-database"></i> All user data stored securely in plain text with hashing & file locking
        </div>
    </div>
<?php else: ?>
    <!-- LOGIN / REGISTRATION INTERFACE -->
    <div class="auth-container">
        <div class="tabs">
            <button class="tab-btn active" id="tabLoginBtn"><i class="fas fa-key"></i> Sign In</button>
            <button class="tab-btn" id="tabRegisterBtn"><i class="fas fa-user-plus"></i> Sign Up</button>
        </div>

        <!-- LOGIN FORM -->
        <div id="loginPanel" class="form-panel active">
            <?php if ($login_error): ?>
                <div class="message error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($login_error); ?></div>
            <?php endif; ?>
            <form method="POST" action="" id="loginForm">
                <div class="input-group">
                    <label>Email Address</label>
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="login_email" id="loginEmail" placeholder="hello@example.com" required>
                </div>
                <div class="input-group">
                    <label>Password</label>
                    <i class="fas fa-lock"></i>
                    <input type="password" name="login_password" id="loginPassword" placeholder="••••••" required>
                </div>
                <div class="checkbox-row">
                    <label><input type="checkbox" name="remember_me"> <span>Remember me</span></label>
                </div>
                <button type="submit" name="login" class="btn-submit"><i class="fas fa-arrow-right-to-bracket"></i> Sign In</button>
            </form>
        </div>

        <!-- REGISTRATION FORM -->
        <div id="registerPanel" class="form-panel">
            <?php if ($register_error): ?>
                <div class="message error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($register_error); ?></div>
            <?php endif; ?>
            <?php if ($register_success): ?>
                <div class="message success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($register_success); ?></div>
            <?php endif; ?>
            <form method="POST" action="" id="registerForm">
                <div class="input-group">
                    <label>Username</label>
                    <i class="fas fa-user"></i>
                    <input type="text" name="username" id="regUsername" placeholder="john_doe" required>
                </div>
                <div class="input-group">
                    <label>Email</label>
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="email" id="regEmail" placeholder="user@example.com" required>
                </div>
                <div class="input-group">
                    <label>Password (min 6 chars)</label>
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" id="regPassword" required>
                </div>
                <div class="input-group">
                    <label>Confirm Password</label>
                    <i class="fas fa-check-circle"></i>
                    <input type="password" name="confirm_password" id="regConfirmPassword" required>
                </div>
                <button type="submit" name="register" class="btn-submit"><i class="fas fa-user-check"></i> Create Account</button>
                <div class="info-note"><i class="fas fa-shield-alt"></i> Passwords are hashed securely.</div>
            </form>
        </div>
    </div>

    <script>
        // Client-side validation + tab switching
        const tabLogin = document.getElementById('tabLoginBtn');
        const tabRegister = document.getElementById('tabRegisterBtn');
        const loginPanel = document.getElementById('loginPanel');
        const registerPanel = document.getElementById('registerPanel');

        function activateTab(tab) {
            if (tab === 'login') {
                tabLogin.classList.add('active');
                tabRegister.classList.remove('active');
                loginPanel.classList.add('active');
                registerPanel.classList.remove('active');
            } else {
                tabRegister.classList.add('active');
                tabLogin.classList.remove('active');
                registerPanel.classList.add('active');
                loginPanel.classList.remove('active');
            }
        }

        tabLogin.addEventListener('click', () => activateTab('login'));
        tabRegister.addEventListener('click', () => activateTab('register'));

        // Live client validation for registration
        const regForm = document.getElementById('registerForm');
        if (regForm) {
            regForm.addEventListener('submit', function(e) {
                const username = document.getElementById('regUsername').value.trim();
                const email = document.getElementById('regEmail').value.trim();
                const pwd = document.getElementById('regPassword').value;
                const confirm = document.getElementById('regConfirmPassword').value;
                let errMsg = '';
                if (!username || username.length < 3 || username.length > 30) {
                    errMsg = 'Username must be 3-30 characters.';
                } else if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
                    errMsg = 'Enter a valid email address.';
                } else if (!pwd || pwd.length < 6) {
                    errMsg = 'Password must be at least 6 characters.';
                } else if (pwd !== confirm) {
                    errMsg = 'Passwords do not match.';
                }
                if (errMsg) {
                    e.preventDefault();
                    // show dynamic inline message (simple alert or create message div)
                    let existing = document.querySelector('#registerPanel .message');
                    if (existing && existing.classList.contains('error')) existing.remove();
                    const msgDiv = document.createElement('div');
                    msgDiv.className = 'message error';
                    msgDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + errMsg;
                    const panel = document.getElementById('registerPanel');
                    const firstChild = panel.querySelector('form');
                    panel.insertBefore(msgDiv, firstChild);
                    setTimeout(() => msgDiv.remove(), 3000);
                }
            });
        }

        // client validation login (basic)
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', function(e) {
                const email = document.getElementById('loginEmail').value.trim();
                const pwd = document.getElementById('loginPassword').value;
                if (!email || !pwd) {
                    e.preventDefault();
                    let existing = document.querySelector('#loginPanel .message');
                    if (existing && existing.classList.contains('error')) existing.remove();
                    const msgDiv = document.createElement('div');
                    msgDiv.className = 'message error';
                    msgDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> Both fields required.';
                    const panel = document.getElementById('loginPanel');
                    panel.insertBefore(msgDiv, panel.querySelector('form'));
                    setTimeout(() => msgDiv.remove(), 3000);
                }
            });
        }
    </script>
<?php endif; ?>
</body>
</html>