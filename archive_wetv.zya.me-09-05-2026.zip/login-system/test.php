<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title>SecureAuth | Modern Login & Registration</title>
  <!-- Google Fonts & Font Awesome -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Inter', sans-serif;
    }

    body {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1.5rem;
    }

    /* Main container */
    .auth-container {
      background: rgba(255,255,255,0.98);
      border-radius: 2rem;
      box-shadow: 0 25px 45px rgba(0,0,0,0.2), 0 0 0 1px rgba(255,255,255,0.2);
      width: 100%;
      max-width: 460px;
      overflow: hidden;
      transition: all 0.3s ease;
    }

    /* Dashboard/Welcome container - larger for welcome page */
    .dashboard-container {
      max-width: 800px;
      background: rgba(255,255,255,0.98);
      border-radius: 2rem;
      box-shadow: 0 25px 45px rgba(0,0,0,0.2);
      overflow: hidden;
      animation: slideUp 0.5s ease;
    }

    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    /* Tabs */
    .tabs {
      display: flex;
      background: #f8fafc;
      border-bottom: 1px solid #e2e8f0;
    }

    .tab-btn {
      flex: 1;
      background: transparent;
      border: none;
      padding: 1.2rem;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: 0.2s;
      color: #64748b;
      letter-spacing: -0.2px;
    }

    .tab-btn i {
      margin-right: 8px;
    }

    .tab-btn.active {
      color: #4f46e5;
      background: white;
      border-bottom: 3px solid #4f46e5;
    }

    /* Forms */
    .form-panel {
      padding: 2rem 1.8rem 2rem 1.8rem;
      display: none;
      animation: fade 0.25s ease;
    }

    .form-panel.active {
      display: block;
    }

    @keyframes fade {
      from { opacity: 0; transform: translateY(8px);}
      to { opacity: 1; transform: translateY(0);}
    }

    .input-group {
      margin-bottom: 1.4rem;
      position: relative;
    }

    .input-group label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
      color: #1e293b;
      font-size: 0.85rem;
    }

    .input-group i {
      position: absolute;
      left: 14px;
      top: 42px;
      color: #94a3b8;
      font-size: 1rem;
    }

    .input-group input {
      width: 100%;
      padding: 0.85rem 0.85rem 0.85rem 2.5rem;
      border: 1.5px solid #e2e8f0;
      border-radius: 1rem;
      font-size: 0.95rem;
      transition: all 0.2s;
      background: #fff;
    }

    .input-group input:focus {
      outline: none;
      border-color: #4f46e5;
      box-shadow: 0 0 0 3px rgba(79,70,229,0.2);
    }

    /* Checkbox row */
    .checkbox-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 1rem 0 1.4rem;
      font-size: 0.85rem;
    }

    .checkbox-row label {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      color: #334155;
    }

    .btn-submit {
      width: 100%;
      background: linear-gradient(100deg, #4f46e5, #6366f1);
      border: none;
      padding: 0.9rem;
      border-radius: 2rem;
      font-weight: 700;
      font-size: 1rem;
      color: white;
      cursor: pointer;
      transition: 0.2s;
      box-shadow: 0 8px 20px -8px #4f46e5;
    }

    .btn-submit:hover {
      transform: translateY(-2px);
      background: linear-gradient(100deg, #4338ca, #4f46e5);
      box-shadow: 0 12px 24px -10px #4f46e5;
    }

    /* Message alerts */
    .message {
      padding: 0.9rem;
      border-radius: 1rem;
      margin-bottom: 1.5rem;
      font-size: 0.85rem;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .message.error {
      background: #fee2e2;
      color: #b91c1c;
      border-left: 4px solid #ef4444;
    }

    .message.success {
      background: #dcfce7;
      color: #166534;
      border-left: 4px solid #22c55e;
    }

    .info-note {
      font-size: 0.7rem;
      text-align: center;
      margin-top: 1rem;
      color: #6c757d;
    }

    /* Welcome/Dashboard Styles */
    .welcome-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 2rem;
      text-align: center;
      color: white;
    }

    .welcome-avatar {
      width: 80px;
      height: 80px;
      background: white;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 1rem;
      font-size: 2.5rem;
      color: #4f46e5;
      box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    }

    .welcome-header h1 {
      font-size: 1.8rem;
      margin-bottom: 0.5rem;
    }

    .welcome-header p {
      opacity: 0.95;
      font-size: 0.95rem;
    }

    .welcome-content {
      padding: 2rem;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1.5rem;
      margin-bottom: 2rem;
    }

    .stat-card {
      background: #f8fafc;
      padding: 1.5rem;
      border-radius: 1rem;
      text-align: center;
      transition: transform 0.2s;
      border: 1px solid #e2e8f0;
    }

    .stat-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    }

    .stat-icon {
      font-size: 2rem;
      color: #4f46e5;
      margin-bottom: 0.5rem;
    }

    .stat-value {
      font-size: 1.5rem;
      font-weight: 700;
      color: #1e293b;
      margin-bottom: 0.25rem;
    }

    .stat-label {
      font-size: 0.85rem;
      color: #64748b;
    }

    .user-info-card {
      background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
      border-radius: 1rem;
      padding: 1.5rem;
      margin-bottom: 2rem;
      border-left: 4px solid #4f46e5;
    }

    .user-info-card h3 {
      color: #1e293b;
      margin-bottom: 1rem;
      font-size: 1.2rem;
    }

    .info-row {
      display: flex;
      justify-content: space-between;
      padding: 0.75rem 0;
      border-bottom: 1px solid #e2e8f0;
    }

    .info-row:last-child {
      border-bottom: none;
    }

    .info-label {
      font-weight: 600;
      color: #475569;
    }

    .info-value {
      color: #1e293b;
      font-family: monospace;
    }

    .action-buttons {
      display: flex;
      gap: 1rem;
      justify-content: center;
      margin-top: 1.5rem;
    }

    .btn-logout {
      background: #ef4444;
      border: none;
      padding: 0.8rem 2rem;
      border-radius: 2rem;
      font-weight: 600;
      color: white;
      cursor: pointer;
      transition: 0.2s;
      font-size: 1rem;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
    }

    .btn-logout:hover {
      background: #dc2626;
      transform: scale(0.98);
    }

    .btn-home {
      background: #10b981;
      border: none;
      padding: 0.8rem 2rem;
      border-radius: 2rem;
      font-weight: 600;
      color: white;
      cursor: pointer;
      transition: 0.2s;
      font-size: 1rem;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      text-decoration: none;
    }

    .btn-home:hover {
      background: #059669;
      transform: translateY(-2px);
    }

    @media (max-width: 640px) {
      .dashboard-container {
        max-width: 95%;
      }
      .stats-grid {
        grid-template-columns: 1fr;
      }
      .action-buttons {
        flex-direction: column;
      }
      .welcome-header h1 {
        font-size: 1.3rem;
      }
    }
  </style>
</head>
<body>

<?php
session_start();

// ---------- CONFIGURATION ----------
define('USER_DATA_FILE', 'users.txt');
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCK_TIMEOUT_SECONDS', 2);

// ---------- HELPER: secure file write with flock ----------
function secure_file_write($filepath, $data, $mode = 'w') {
    $dir = dirname($filepath);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $fp = fopen($filepath, $mode);
    if (!$fp) return false;
    
    $locked = flock($fp, LOCK_EX);
    if (!$locked) {
        fclose($fp);
        return false;
    }
    
    if ($mode === 'w') {
        ftruncate($fp, 0);
        rewind($fp);
    }
    $writeResult = fwrite($fp, $data);
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    return ($writeResult !== false);
}

// ---------- HELPER: read users safely ----------
function read_users_safe() {
    if (!file_exists(USER_DATA_FILE)) {
        return [];
    }
    $fp = fopen(USER_DATA_FILE, 'r');
    if (!$fp) return [];
    flock($fp, LOCK_SH);
    $content = stream_get_contents($fp);
    flock($fp, LOCK_UN);
    fclose($fp);
    
    $users = [];
    if ($content) {
        $lines = explode("\n", trim($content));
        foreach ($lines as $line) {
            if (trim($line) === '') continue;
            $parts = explode('|', $line, 5);
            if (count($parts) === 5) {
                list($username, $email, $hashedPwd, $failedAttempts, $lockUntil) = $parts;
                $users[$email] = [
                    'username' => $username,
                    'password' => $hashedPwd,
                    'failed_attempts' => (int)$failedAttempts,
                    'lock_until' => (int)$lockUntil,
                    'registration_date' => $parts[4] ?? time() // fallback
                ];
            }
        }
    }
    return $users;
}

// ---------- HELPER: write entire users array ----------
function write_users_safe($users) {
    $lines = [];
    foreach ($users as $email => $data) {
        $lines[] = implode('|', [
            $data['username'],
            $email,
            $data['password'],
            $data['failed_attempts'],
            $data['lock_until']
        ]);
    }
    $content = implode("\n", $lines) . (count($lines) ? "\n" : '');
    return secure_file_write(USER_DATA_FILE, $content, 'w');
}

// ---------- BRUTE FORCE PROTECTION ----------
function is_account_locked($userData) {
    if ($userData['lock_until'] > time()) {
        return true;
    }
    return false;
}

// ---------- REGISTER LOGIC ----------
$register_error = null;
$register_success = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (empty($username) || empty($email) || empty($password) || empty($confirm)) {
        $register_error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $register_error = "Invalid email format.";
    } elseif (strlen($username) < 3 || strlen($username) > 30) {
        $register_error = "Username must be 3-30 characters.";
    } elseif (strlen($password) < 6) {
        $register_error = "Password must be at least 6 characters.";
    } elseif ($password !== $confirm) {
        $register_error = "Passwords do not match.";
    } else {
        $users = read_users_safe();
        $emailExists = isset($users[$email]);
        $usernameExists = false;
        foreach ($users as $user) {
            if (strtolower($user['username']) === strtolower($username)) {
                $usernameExists = true;
                break;
            }
        }
        if ($emailExists) {
            $register_error = "Email already registered.";
        } elseif ($usernameExists) {
            $register_error = "Username already taken.";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $users[$email] = [
                'username' => $username,
                'password' => $hashedPassword,
                'failed_attempts' => 0,
                'lock_until' => 0
            ];
            if (write_users_safe($users)) {
                $register_success = "Registration successful! Please login.";
            } else {
                $register_error = "Server error: could not save data. Try again.";
            }
        }
    }
}

// ---------- LOGIN LOGIC ----------
$login_error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = trim($_POST['login_email'] ?? '');
    $password = $_POST['login_password'] ?? '';
    $remember = isset($_POST['remember_me']);
    
    if (empty($email) || empty($password)) {
        $login_error = "Email and password required.";
    } else {
        $users = read_users_safe();
        if (!isset($users[$email])) {
            $login_error = "Invalid credentials.";
        } else {
            $user = $users[$email];
            if (is_account_locked($user)) {
                $remaining = $user['lock_until'] - time();
                $login_error = "Account temporarily locked. Try again in $remaining seconds.";
            } else {
                if (password_verify($password, $user['password'])) {
                    $user['failed_attempts'] = 0;
                    $user['lock_until'] = 0;
                    $users[$email] = $user;
                    write_users_safe($users);
                    
                    $_SESSION['user_email'] = $email;
                    $_SESSION['user_name'] = $user['username'];
                    $_SESSION['login_time'] = time();
                    
                    if ($remember) {
                        $token = bin2hex(random_bytes(32));
                        $expiry = time() + (86400 * 30);
                        setcookie('remember_token', $token, $expiry, '/', '', false, true);
                        $tokenFile = 'remember_tokens.txt';
                        $tokenData = [];
                        if (file_exists($tokenFile)) {
                            $fp = fopen($tokenFile, 'r');
                            flock($fp, LOCK_SH);
                            $content = stream_get_contents($fp);
                            flock($fp, LOCK_UN);
                            fclose($fp);
                            if ($content) {
                                $lines = explode("\n", trim($content));
                                foreach ($lines as $line) {
                                    if (trim($line)) {
                                        list($tok, $em) = explode('|', $line);
                                        $tokenData[$tok] = $em;
                                    }
                                }
                            }
                        }
                        $tokenData[$token] = $email;
                        $tokenLines = [];
                        foreach ($tokenData as $tok => $em) {
                            $tokenLines[] = "$tok|$em";
                        }
                        secure_file_write($tokenFile, implode("\n", $tokenLines) . "\n", 'w');
                    }
                    header("Location: " . $_SERVER['PHP_SELF'] . "?welcome=1");
                    exit;
                } else {
                    $user['failed_attempts'] = $user['failed_attempts'] + 1;
                    if ($user['failed_attempts'] >= MAX_LOGIN_ATTEMPTS) {
                        $user['lock_until'] = time() + 300;
                        $login_error = "Too many failed attempts. Account locked for 5 minutes.";
                    } else {
                        $login_error = "Invalid credentials.";
                    }
                    $users[$email] = $user;
                    write_users_safe($users);
                }
            }
        }
    }
}

// ---------- LOGOUT ----------
if (isset($_GET['logout'])) {
    session_destroy();
    if (isset($_COOKIE['remember_token'])) {
        $token = $_COOKIE['remember_token'];
        setcookie('remember_token', '', time() - 3600, '/');
        $tokenFile = 'remember_tokens.txt';
        if (file_exists($tokenFile)) {
            $fp = fopen($tokenFile, 'r');
            flock($fp, LOCK_SH);
            $content = stream_get_contents($fp);
            flock($fp, LOCK_UN);
            fclose($fp);
            $newTokens = [];
            if ($content) {
                $lines = explode("\n", trim($content));
                foreach ($lines as $line) {
                    if (trim($line)) {
                        list($tok, $em) = explode('|', $line);
                        if ($tok !== $token) {
                            $newTokens[] = "$tok|$em";
                        }
                    }
                }
            }
            secure_file_write($tokenFile, implode("\n", $newTokens) . "\n", 'w');
        }
    }
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ---------- AUTO LOGIN VIA REMEMBER ME ----------
if (!isset($_SESSION['user_email']) && isset($_COOKIE['remember_token'])) {
    $token = $_COOKIE['remember_token'];
    $tokenFile = 'remember_tokens.txt';
    if (file_exists($tokenFile)) {
        $fp = fopen($tokenFile, 'r');
        flock($fp, LOCK_SH);
        $content = stream_get_contents($fp);
        flock($fp, LOCK_UN);
        fclose($fp);
        if ($content) {
            $lines = explode("\n", trim($content));
            foreach ($lines as $line) {
                if (trim($line)) {
                    list($tok, $email) = explode('|', $line);
                    if ($tok === $token) {
                        $users = read_users_safe();
                        if (isset($users[$email])) {
                            $_SESSION['user_email'] = $email;
                            $_SESSION['user_name'] = $users[$email]['username'];
                            $_SESSION['login_time'] = time();
                        }
                        break;
                    }
                }
            }
        }
    }
}

// ---------- CHECK IF USER IS LOGGED IN FOR WELCOME PAGE ----------
$showWelcome = isset($_GET['welcome']) && isset($_SESSION['user_email']);
?>

<?php if ($showWelcome): ?>
    <!-- WELCOME / DASHBOARD PAGE -->
    <div class="dashboard-container">
        <div class="welcome-header">
            <div class="welcome-avatar">
                <i class="fas fa-user-circle"></i>
            </div>
            <h1>Welcome back, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h1>
            <p>We're glad to see you again</p>
        </div>
        
        <div class="welcome-content">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="stat-value">
                        <?php echo date('F j, Y'); ?>
                    </div>
                    <div class="stat-label">Current Date</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-value">
                        <?php echo date('h:i A'); ?>
                    </div>
                    <div class="stat-label">Current Time</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-sign-in-alt"></i>
                    </div>
                    <div class="stat-value">
                        <?php 
                        if (isset($_SESSION['login_time'])) {
                            echo date('M j, g:i A', $_SESSION['login_time']);
                        } else {
                            echo "Today";
                        }
                        ?>
                    </div>
                    <div class="stat-label">Login Time</div>
                </div>
            </div>
            
            <div class="user-info-card">
                <h3><i class="fas fa-user"></i> Account Information</h3>
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-user"></i> Username:</span>
                    <span class="info-value"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-envelope"></i> Email:</span>
                    <span class="info-value"><?php echo htmlspecialchars($_SESSION['user_email']); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-shield-alt"></i> Status:</span>
                    <span class="info-value" style="color: #10b981;">Active & Secure</span>
                </div>
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-fingerprint"></i> Session ID:</span>
                    <span class="info-value"><?php echo substr(session_id(), 0, 15) . '...'; ?></span>
                </div>
            </div>
            
            <div class="action-buttons">
                <a href="?logout=1" class="btn-logout">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
                <a href="<?php echo $_SERVER['PHP_SELF']; ?>" class="btn-home">
                    <i class="fas fa-home"></i> Home
                </a>
            </div>
            
            <div class="info-note" style="margin-top: 2rem;">
                <i class="fas fa-lock"></i> Your account is protected with password hashing and brute force protection
            </div>
        </div>
    </div>
<?php else: ?>
    <!-- LOGIN / REGISTRATION INTERFACE -->
    <div class="auth-container">
        <div class="tabs">
            <button class="tab-btn active" id="tabLoginBtn"><i class="fas fa-key"></i> Sign In</button>
            <button class="tab-btn" id="tabRegisterBtn"><i class="fas fa-user-plus"></i> Sign Up</button>
        </div>

        <!-- LOGIN FORM -->
        <div id="loginPanel" class="form-panel active">
            <?php if ($login_error): ?>
                <div class="message error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($login_error); ?></div>
            <?php endif; ?>
            <form method="POST" action="" id="loginForm">
                <div class="input-group">
                    <label>Email Address</label>
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="login_email" id="loginEmail" placeholder="hello@example.com" required>
                </div>
                <div class="input-group">
                    <label>Password</label>
                    <i class="fas fa-lock"></i>
                    <input type="password" name="login_password" id="loginPassword" placeholder="••••••" required>
                </div>
                <div class="checkbox-row">
                    <label><input type="checkbox" name="remember_me"> <span>Remember me for 30 days</span></label>
                </div>
                <button type="submit" name="login" class="btn-submit"><i class="fas fa-arrow-right-to-bracket"></i> Sign In</button>
                <div class="info-note">
                    <i class="fas fa-shield-alt"></i> Secure login with brute force protection
                </div>
            </form>
        </div>

        <!-- REGISTRATION FORM -->
        <div id="registerPanel" class="form-panel">
            <?php if ($register_error): ?>
                <div class="message error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($register_error); ?></div>
            <?php endif; ?>
            <?php if ($register_success): ?>
                <div class="message success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($register_success); ?></div>
            <?php endif; ?>
            <form method="POST" action="" id="registerForm">
                <div class="input-group">
                    <label>Username</label>
                    <i class="fas fa-user"></i>
                    <input type="text" name="username" id="regUsername" placeholder="john_doe" required>
                </div>
                <div class="input-group">
                    <label>Email</label>
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="email" id="regEmail" placeholder="user@example.com" required>
                </div>
                <div class="input-group">
                    <label>Password (min 6 characters)</label>
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" id="regPassword" required>
                </div>
                <div class="input-group">
                    <label>Confirm Password</label>
                    <i class="fas fa-check-circle"></i>
                    <input type="password" name="confirm_password" id="regConfirmPassword" required>
                </div>
                <button type="submit" name="register" class="btn-submit"><i class="fas fa-user-check"></i> Create Account</button>
                <div class="info-note">
                    <i class="fas fa-shield-alt"></i> Passwords are securely hashed before storage
                </div>
            </form>
        </div>
    </div>

    <script>
        // Client-side validation + tab switching
        const tabLogin = document.getElementById('tabLoginBtn');
        const tabRegister = document.getElementById('tabRegisterBtn');
        const loginPanel = document.getElementById('loginPanel');
        const registerPanel = document.getElementById('registerPanel');

        function activateTab(tab) {
            if (tab === 'login') {
                tabLogin.classList.add('active');
                tabRegister.classList.remove('active');
                loginPanel.classList.add('active');
                registerPanel.classList.remove('active');
            } else {
                tabRegister.classList.add('active');
                tabLogin.classList.remove('active');
                registerPanel.classList.add('active');
                loginPanel.classList.remove('active');
            }
        }

        tabLogin.addEventListener('click', () => activateTab('login'));
        tabRegister.addEventListener('click', () => activateTab('register'));

        // Live client validation for registration
        const regForm = document.getElementById('registerForm');
        if (regForm) {
            regForm.addEventListener('submit', function(e) {
                const username = document.getElementById('regUsername').value.trim();
                const email = document.getElementById('regEmail').value.trim();
                const pwd = document.getElementById('regPassword').value;
                const confirm = document.getElementById('regConfirmPassword').value;
                let errMsg = '';
                if (!username || username.length < 3 || username.length > 30) {
                    errMsg = 'Username must be 3-30 characters.';
                } else if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
                    errMsg = 'Enter a valid email address.';
                } else if (!pwd || pwd.length < 6) {
                    errMsg = 'Password must be at least 6 characters.';
                } else if (pwd !== confirm) {
                    errMsg = 'Passwords do not match.';
                }
                if (errMsg) {
                    e.preventDefault();
                    let existing = document.querySelector('#registerPanel .message');
                    if (existing && existing.classList.contains('error')) existing.remove();
                    const msgDiv = document.createElement('div');
                    msgDiv.className = 'message error';
                    msgDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + errMsg;
                    const panel = document.getElementById('registerPanel');
                    const firstChild = panel.querySelector('form');
                    panel.insertBefore(msgDiv, firstChild);
                    setTimeout(() => msgDiv.remove(), 3000);
                }
            });
        }

        // Client validation for login
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', function(e) {
                const email = document.getElementById('loginEmail').value.trim();
                const pwd = document.getElementById('loginPassword').value;
                if (!email || !pwd) {
                    e.preventDefault();
                    let existing = document.querySelector('#loginPanel .message');
                    if (existing && existing.classList.contains('error')) existing.remove();
                    const msgDiv = document.createElement('div');
                    msgDiv.className = 'message error';
                    msgDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> Both fields are required.';
                    const panel = document.getElementById('loginPanel');
                    panel.insertBefore(msgDiv, panel.querySelector('form'));
                    setTimeout(() => msgDiv.remove(), 3000);
                }
            });
        }
    </script>
<?php endif; ?>
</body>
</html>